## ---------------------------------------------------------------------------
## Building a blocking vector from spatial coordinates.
## ---------------------------------------------------------------------------

#' Group samples into spatial blocks for blocked resampling
#'
#' Clusters samples by geographic proximity into a given number of blocks, to be
#' passed as the \code{sites} argument of \code{\link{rdaf_randomForest}},
#' \code{\link{makeGF}}, \code{\link{mtrySelJack}} or
#' \code{\link{ordinationJackknife}} together with
#' \code{site.repeats = "blocked.resampling"}.
#'
#' This is for data that have no natural sites: samples spread continuously over
#' a landscape, where the concern is spatial autocorrelation rather than
#' repeated sampling of the same place. When the data do have real sites, with
#' several individuals sharing one set of predictor values, pass those sites
#' directly instead; \code{site.repeats = "genetic.median"} is then usually the
#' better treatment. Note that spatial blocks force the model to extrapolate
#' into withheld regions, which legitimately lowers \eqn{R^2}: a drop is not by
#' itself evidence of a problem, but it does mean the two numbers are not
#' comparable with an unblocked run.
#'
#' Samples are clustered by Ward's method on great circle distances between
#' their coordinates, cut into \code{nblocks} groups. Because a plain cut can
#' leave one or two isolated samples in a block of their own, which makes for a
#' useless hold-out set, blocks smaller than \code{min.size} are then merged
#' into their nearest neighbouring block, and the largest block that can afford
#' it is split in two to restore the count. This repeats until every block holds
#' at least \code{min.size} samples, so the blocks end up deliberately uneven in
#' size.
#'
#' How many blocks to ask for is a trade-off. Few large blocks make the strictest
#' test but leave little training data and can withhold a whole region, so the
#' model is asked to extrapolate rather than interpolate; many small blocks are
#' gentler but, once a block is smaller than the scale over which samples are
#' correlated, stop protecting against the autocorrelation you were worried
#' about. Blocks somewhat larger than the range of spatial autocorrelation in
#' the data, with enough of them that no single one dominates, is the usual
#' advice.
#'
#' @param latlon two-column data frame of coordinates, longitude then latitude,
#'   as accepted by \code{\link{gcd.dist}}. Ignored if \code{distances} is given.
#' @param nblocks number of blocks to aim for.
#' @param min.size smallest acceptable number of samples in a block.
#' @param distances optional pre-computed \code{dist} object of distances
#'   between samples, used in place of great circle distances from
#'   \code{latlon}. Supply this to block on something other than geography
#'   (family, batch or year), or to reuse the distances from a previous call to
#'   \code{\link{gcd.dist}}.
#' @param method agglomeration method for \code{\link[stats]{hclust}}.
#' @return A factor of length \code{nrow(latlon)} giving the block of each
#'   sample, with levels ordered by block size (largest first).
#' @seealso \code{\link{site_repeats_summary}}, \code{\link{gcd.dist}},
#'   \code{\link{rdaf_randomForest}}
#' @examples
#' latlon <- data.frame(lon = c(rnorm(20, -100), rnorm(20, -80)),
#'                      lat = c(rnorm(20, 50), rnorm(20, 40)))
#' blocks <- spatial_blocks(latlon, nblocks = 4, min.size = 4)
#' table(blocks)
#' @export
spatial_blocks <- function(latlon, nblocks = 10, min.size = 4,
                           distances = NULL, method = "ward.D2") {
  if (is.null(distances)) {
    if (missing(latlon))
      stop("supply either latlon or distances")
    distances <- gcd.dist(latlon)$gcd.distances
  }
  D <- as.matrix(distances)
  n <- nrow(D)
  if (nblocks < 2) stop("nblocks must be at least 2")
  if (nblocks * min.size > n)
    stop("cannot make ", nblocks, " blocks of at least ", min.size,
         " samples from ", n, " samples")

  hc <- stats::hclust(stats::as.dist(D), method = method)
  cl <- stats::cutree(hc, nblocks)

  split_one <- function(cl, idx) {
    ## split cluster `idx` in two, but only if both halves are big enough.
    ## A block too small to halve cannot be split at all, and hclust refuses
    ## fewer than two objects, so rule those out before asking.
    if (length(idx) < max(2L, 2L * min.size)) return(NULL)
    sub <- stats::cutree(
      stats::hclust(stats::as.dist(D[idx, idx, drop = FALSE]), method = method), 2)
    if (min(table(sub)) < min.size) return(NULL)
    cl[idx[sub == 2]] <- max(cl) + 1L
    cl
  }

  for (iter in seq_len(100L)) {
    tab <- table(cl)
    small <- as.integer(names(tab)[tab < min.size])
    if (!length(small)) break

    ## merge the smallest undersized block into its nearest neighbour
    s <- small[which.min(tab[as.character(small)])]
    members <- which(cl == s)
    others <- setdiff(unique(cl), s)
    if (!length(others)) break
    nearest <- others[which.min(vapply(others, function(o)
      mean(D[members, cl == o]), numeric(1)))]
    cl[members] <- nearest

    ## split the largest block that can spare the samples, to keep the count
    if (length(unique(cl)) < nblocks) {
      tab2 <- sort(table(cl), decreasing = TRUE)
      done <- FALSE
      for (cand in as.integer(names(tab2))) {
        newcl <- split_one(cl, which(cl == cand))
        if (!is.null(newcl)) { cl <- newcl; done <- TRUE; break }
      }
      if (!done) {
        warning("could only make ", length(unique(cl)), " blocks of at least ",
                min.size, " samples, not ", nblocks)
        break
      }
    }
  }

  ## renumber so that block 1 is the largest
  ord <- names(sort(table(cl), decreasing = TRUE))
  out <- factor(match(as.character(cl), ord))
  levels(out) <- paste0("block", seq_len(nlevels(out)))
  out
}
