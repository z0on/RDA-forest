## ---------------------------------------------------------------------------
## Vendored from gradientForest 0.1-37.
##
## Original authors: S.J. Smith, N. Ellis and P. Dyer
## Licence: GPL (>= 2).
##
## Incorporated into RDAforest so that the package is self-contained and so
## that the random forest engine could be extended with blocked (grouped)
## out-of-bag sampling.  Every function has been renamed with an `rdaf_`
## prefix; apart from that, and the changes noted inline, the code is the
## original.
## ---------------------------------------------------------------------------


#' Plot a gradient forest
#'
#' Four diagnostic displays of a fitted gradient forest. Vendored from
#' \pkg{gradientForest}.
#'
#' @param x an object of class \code{rdaf_gradientForest}.
#' @param plot.type one of \code{"Overall.Importance"} (barplots of accuracy
#'   and \eqn{R^2}-weighted importance), \code{"Split.Density"} (where along
#'   each predictor the splits fall, against the density of the data),
#'   \code{"Cumulative.Importance"} (the turnover curves) or
#'   \code{"Performance"} (\eqn{R^2} per response column). Partial matching
#'   is allowed, so \code{"C"} selects the turnover curves.
#' @param par.args list of graphical parameters set with \code{\link{par}}
#'   before plotting.
#' @param plot.args list of arguments for the individual plot.
#' @param ... further arguments merged into \code{plot.args}.
#' @return \code{NULL}, invisibly; called for its plots.
#' @seealso \code{\link{plot_gf_turnovers}},
#'   \code{\link{rdaf_gradientForest}}
#' @method plot rdaf_gradientForest
#' @export
`plot.rdaf_gradientForest` <-
function(x,	plot.type=c("Overall.Importance","Split.Density","Cumulative.Importance","Performance")[1], 
par.args=NULL, plot.args=NULL, ...) 
{
  if (!inherits(x,"rdaf_gradientForest"))
    stop(paste("'x' must be a rdaf_gradientForest object"))
  plot.options <- c("Overall.Importance","Split.Density","Cumulative.Importance","Performance")
  if (is.na(plot.option <- pmatch(plot.type,plot.options)))
    stop(paste('Unmatched plot.type "',plot.type,'". Expecting one of "Overall.Importance", "Split.Density", "Cumulative.Importance" or "Performance"',sep=""))

  old.par<-par(no.readonly=TRUE)
  on.exit(par(old.par))

  amend.args <- function(default.args, new.args) {
    # replace those that match
    for(arg in intersect(names(default.args), names(new.args))) 
      default.args[[arg]] <- new.args[[arg]]
    # append those that don't match
    extra <- new.args[is.na(match(names(new.args),names(default.args)))]
    c(default.args,extra)
  }
  
	if(plot.options[plot.option]=="Overall.Importance"){	
    plot.args.def <- amend.args(list(cex.axis = 0.7, cex.names = 0.7, las=1, horiz = TRUE), plot.args)
    plot.args.def<- amend.args(plot.args.def,list(...))     
    par.args.def <- amend.args(list(mfrow = c(1, 2), mar = c(4, 6, 2, 1)), par.args)
    par(par.args.def)    
    do.call(".rdaf_overall_importance_plot",c(list(obj=quote(x)),plot.args.def))
	}
	  
  if(plot.options[plot.option]=="Split.Density"){      
    plot.args.def <- amend.args(list(leg.posn="topright",bin=F, nbin=101, leg.panel=1, barwidth=1, cex.legend=0.8, line.ylab=1.5), plot.args)
    plot.args.def<- amend.args(plot.args.def,list(...))     
    par.args.def <- amend.args(list(mar =c(4.5, 1.5, 0.5, 4.5), omi = c(0.1, 0.25, 0.1, 0.1)), par.args)
    par(par.args.def)    
    do.call(".rdaf_split_density_plot",c(list(obj=quote(x)),plot.args.def))
  }
  
  if(plot.options[plot.option]=="Cumulative.Importance") {
    plot.args.def <- amend.args(list(leg.posn="topleft",legend=TRUE, common.scale=F, line.ylab=1.0, cex.legend=0.75, show.species=TRUE, show.overall=TRUE, leg.nspecies=10), plot.args)
    plot.args.def<- amend.args(plot.args.def,list(...))     
    par.args.def <- amend.args(list(mar=c(0.0,2.1,1.1,0), omi=c(0.75, 0.75, 0.1, 0.1)), par.args)
    par(par.args.def)    
    do.call(".rdaf_species_cumulative_plot",c(list(obj=quote(x)),plot.args.def))
  }
    
  if(plot.options[plot.option]=="Performance")  {                               
    plot.args.def <- amend.args(list(horizontal = FALSE, show.names = FALSE, las=2, cex.axis = 0.7,cex.labels=0.7,line=2), plot.args)
    plot.args.def<- amend.args(plot.args.def,list(...))     
    par.args.def <- amend.args(list(mfrow=c(1,1)), par.args)
    par(par.args.def)    
    do.call(".rdaf_performance_plot",c(list(obj=quote(x)),plot.args.def))   
	}

  invisible()	

  }


`.rdaf_overall_importance_plot` <-
function (obj, ..., las = 1, cex.axis = 0.7, cex.names = cex.axis, horiz = TRUE)
{
    imp.a <- rdaf_importance(obj,"Accuracy")
    imp.w <- rdaf_importance(obj,"Weighted")
    o.a <- order(imp.a)
    o.w <- order(imp.w)
    barplot(imp.a[o.a], names = names(imp.a[o.a]),
        horiz = horiz, main = "Accuracy importance",
        las = las, cex.axis = cex.axis, cex.names = cex.names, ...)
    barplot(imp.w[o.w], names = names(imp.w[o.w]),
        horiz = horiz, las = 1, main = expression(paste(R^2, " weighted importance")),
        las = las, cex.axis = cex.axis, cex.names = cex.names, ...)
}


`.rdaf_performance_plot` <-
function(obj,filename="rf_overall_performance_GOM.pdf",figure.dir="FiguresGF",
plottofile=FALSE, horizontal = FALSE, show.names = FALSE, las = 2, cex.axis = 0.7, cex.labels = 0.7, line=2, ...)
{
    old.mar<-par()$mar
    par(mfrow=c(1,1),mar=old.mar+c(0,0,0,0))
    if(plottofile) dir.create(figure.dir)
    if(plottofile) pdf(file.path(figure.dir,filename))
    if(obj$ranForest.type=="regression") Ylab <- expression(R^2)
    if(obj$ranForest.type=="classification")  Ylab <- "1-Relative error rate"  #Modified 04/12/2009 S.J. Smith 
    
    perf <- rdaf_importance(obj, type="Species") 
    n <- length(perf)
    if (horizontal) 
      plot(perf, 1:n, las = las, pch=19, axes=F, xlab="", ylab="", ...)
    else plot(1:n, perf, las = las, pch=19, axes=F, xlab="", ylab="", ...) 
    axis(labels=if (show.names) names(perf) else 1:n,side=1+horizontal,at=1:n, cex.axis=cex.labels, padj=0,las=las) 
    axis(side=2-horizontal, cex.axis=cex.axis)
    if (!show.names)
      mtext("Species performance rank",side=1+horizontal,line=line)   
    mtext(Ylab,side=2-horizontal,line=line)
    title("Overall performance of random forests over species")
    abline(h = 0, lty = 2)
    box()
    if(plottofile) dev.off()
    par(mar=old.mar)
}


`.rdaf_species_cumulative_plot` <-
function(obj,imp.vars=NULL, imp.vars.names=imp.vars,
    leg.posn="topleft",leg.nspecies=10,legend=TRUE,
    mfrow=rev(.rdaf_n2mfrow(length(imp.vars)*(show.species+show.overall))),
    show.species=TRUE,show.overall=TRUE, mar=c(0.0,2.1,1.1,0), omi=c(0.75, 0.75, 0.1, 0.1), 
    common.scale=F, line.ylab=1.0, cex.legend=0.75, ...)
{
    # May want to allow for transformations
 	  if(is.null(imp.vars)) imp.vars<-imp.var.names <- names(rdaf_importance(obj))[1:2]
   
    par(mfrow=mfrow)
    cols <- rainbow(length(names(obj$result)))
    names(cols) <- names(obj$result)
 	  
    xaxt <- if(show.overall) "n" else "s"
    if (show.species) {
      for (varX in imp.vars) {
          CU <- rdaf_cumimp(obj, varX, "Species")
          xlim <- range(sapply(CU, "[[", "x"))
          ylim <- range(sapply(CU, "[[", "y"))
          plot(xlim,ylim,type='n',xlab=if(show.overall) "" else imp.vars.names[imp.vars==varX],ylab="",xaxt=xaxt,...)
          for(species in names(CU)) {
              isub <- seq(1,length(CU[[species]]$x),len=pmin(500,length(CU[[species]]$x)))
              lines(CU[[species]]$x[isub],CU[[species]]$y[isub],type='s',col=cols[species])
          }
          #added SJS 08/10/2009
          no.species<-length(names(cols))
          # only label most important species
          imp.sp <- sapply(CU, function(cu) max(cu$y))
          best <- order(-imp.sp)[1:min(leg.nspecies,length(imp.sp))]
          if(legend)
              legend(x=leg.posn,legend=names(cols)[best],pch=rep(1,no.species)[best],col=cols[best],bty="n",cex=cex.legend, pt.lwd=2)
      }
    }
    #
    # Combine species
    #
    if (show.overall) {
      for (varX in imp.vars) {
          CU <- rdaf_cumimp(obj, varX)
          ymax <- max(CU$y)
          if (varX == imp.vars[1]) 
            ymax1 <- ymax
          isub <- seq(1,length(CU$x),len=pmin(500,length(CU$x)))
          plot(CU$x[isub], CU$y[isub], type='s', ylab="",
            xlab=imp.vars.names[imp.vars==varX], 
            ylim=c(0, if(common.scale) ymax1 else ymax), ...)
      }
    }
    mtext("Cumulative importance",side=2,line=line.ylab,outer=TRUE)
}


`.rdaf_split_density_plot` <-
function(obj,imp.vars=NULL, imp.vars.names=imp.vars,
  leg.posn="topright", mfrow=.rdaf_n2mfrow(length(imp.vars)), 
  mar = c(4.5, 1.5, 0.5, 4.5), omi = c(0.1, 0.25, 0.1, 0.1), bin=F, nbin=101, leg.panel=1, barwidth=1,  
  cex.legend=0.8, line.ylab=1.5, ...)
{
if(is.null(imp.vars)) imp.vars<-imp.var.names <- names(sort(rowMeans(obj$imp.rsq),decreasing=T))[1:2]

is.binned <- function(obj) {
  compact <- obj$call$compact
  if (is.null(compact)) 
    FALSE
  else
    eval(compact)
}
  

normalize.histogram <- function(ci,integral=1,bin=F,nbin=101) {
# scale y values so that histogram integrates to integral
# optionally aggregate the y's into binned x ranges 
  if (bin) {
    brks <- seq(min(ci$x),max(ci$x),len=nbin)
    xx <- cut(ci$x,breaks=brks,inc=T)
    yy <- tapply(ci$y,xx,sum)
    yy[is.na(yy)] <- 0
    ci <- list(x=0.5*(brks[-1]+brks[-nbin]),y=yy)
  }
  dx <- min(diff(ci$x)); 
  Id <- sum(ci$y*dx); 
  ci$y <- ci$y/Id*integral; 
  ci
}

normalize.density <- function(d,integral=1,integrate=T) {
# scale y values so that density integrates to integral
  Id <- if(integrate) integrate.density(d) else 1; 
  d$y <- d$y/Id*integral; 
  d
}

integrate.density <- function(d) {
  integrate(approxfun(d,rule=2),lower=min(d$x),upper=max(d$x))$value
}

scale.density <- function(d,scale=1/mean(d$y)) {
  d$y <- d$y*scale
  d
}

par(mfrow=mfrow)
nice.names <- structure(as.list(imp.vars.names),names=imp.vars)
for (i in imp.vars) {
    imp <- rdaf_importance(obj)[i]
    resA <- obj$res[obj$res$var == i, ]
    splits <- resA$split
    w <- pmax(resA$improve.norm, 0)
    X <- na.omit(obj$X[,i])
    rX <- range(X)
    dX <- diff(rX)
    
    # importance density I(x)
    dImp <- density(splits, weight = w/sum(w), from = rX[1], to = rX[2])
    if((dX/dImp$bw) > 50)  
      dImp <- density(splits, weight = w/sum(w), from = rX[1], to = rX[2], bw=dX/50)
    dImpNorm <- normalize.density(dImp,imp,integrate=T)
    
    # data density d(x)
    dObs <- density(X, from = rX[1], to = rX[2])
    if((dX/dObs$bw) > 50)  
      dObs <- density(X, from = rX[1], to = rX[2], bw=dX/50)
    dObs <- .rdaf_whiten(dObs,lambda=0.9)
    dObsNorm <- normalize.density(dObs,imp,integrate=T)
    
    # raw importances I
    ci <- rdaf_cumimp(obj,i,standardize=F)   
    ci$y <- diff(c(0,ci$y))
    ci <- normalize.histogram(ci, imp, bin=bin | !is.binned(obj), nbin=nbin)
    
    # standardized density f(x) = I(x)/d(x)
    dStd <- dImp
    dStd$y <- dImp$y/dObs$y
    dStdNorm <- try(normalize.density(dStd,imp,integrate=T)) # this sometimes does not converge
    if (class(dStdNorm) == "try-error")
      dStdNorm <- normalize.histogram(dStd,imp)
    
    # plot them on same scale
    plot(ci, type='h', col="grey60", xlim=range(splits), lwd=barwidth,
      #ylim = c(0, max(dImpNorm$y, dObsNorm$y, dStdNorm$y, ci$y)), lend=2,
      ylim = c(0, max(dImpNorm$y, dObsNorm$y, dStdNorm$y)*1.1), lend=2,
      xlab = nice.names[[i]], ylab = "", ...)
    lines(dImpNorm, col = "black", lwd = 2)
    lines(dObsNorm, col = "red", lwd = 2)
    lines(dStdNorm, col = "blue", lwd = 2)
    abline(h = mean(dStdNorm$y)/mean(dStd$y), lty = 2, col = "blue")
    if (i == imp.vars[leg.panel])
        legend(leg.posn, legend = c("Density of splits", "Density of data", "Ratio of densities", "Ratio=1"),
        lty = c(1, 1, 1, 2), col = c("black", "red", "blue", "blue"), cex = cex.legend, bty = "n", lwd = 1)
  }
  mtext("Density", side = 2, line=line.ylab, outer=T) 

}



#' Map predicted turnover as colour
#'
#' Reduces predicted turnover to its first two principal components and plots
#' them as a two-colour scale over supplied coordinates. Vendored from
#' \pkg{gradientForest}. Within RDAforest, \code{\link{plot_adaptation}} is
#' usually the more capable alternative.
#'
#' @param x a \code{predict.rdaf_gradientForest} object.
#' @param X,Y coordinates at which to plot.
#' @param palette which two colour channels to use: one of \code{"rg"},
#'   \code{"rb"}, \code{"gr"}, \code{"gb"}, \code{"br"}, \code{"bg"}.
#' @param col3 constant value for the remaining channel.
#' @param ... further graphical parameters.
#' @return \code{NULL}, invisibly; called for its plot.
#' @seealso \code{\link{plot_adaptation}}
#' @method plot predict.rdaf_gradientForest
#' @export
`plot.predict.rdaf_gradientForest` <-
function (x, X, Y, palette="rg", col3=127, ...)
{
    palettes <- c("rg","rb","gr","gb","br","bg")
    if (!(palette %in% palettes)) stop(paste("Unknown palette",palette))    
    
    pc <- prcomp(x)
    
    # set up a colour palette 
    col1 <- pc$x[,1]
    col2 <- pc$x[,2]
    col1 <- (col1-min(col1)) / (max(col1)-min(col1)) * 255
    col2 <- (col2-min(col2)) / (max(col2)-min(col2)) * 255
    
    # plot predicted PC scores
    col <- switch(palette,
    rg=rgb(red=col1, green=col2, blue=col3, maxColorValue=255),
    rb=rgb(red=col1, blue=col2, green=col3, maxColorValue=255),
    gb=rgb(green=col1, blue=col2, red=col3, maxColorValue=255),
    gr=rgb(green=col1, red=col2, blue=col3, maxColorValue=255),
    br=rgb(blue=col1, red=col2, green=col3, maxColorValue=255),
    bg=rgb(blue=col1, green=col2, red=col3, maxColorValue=255)    
    )
    plot(X, Y, col=col, ...)
    invisible()
}
