## ---------------------------------------------------------------------------
## Variable-importance generic for RDAforest.
##
## `importance` is defined by both extendedForest and gradientForest.  Here the
## two are merged into a single generic, `rdaf_importance`, with methods for
## `rdaf_randomForest` and `rdaf_gradientForest` objects, so that RDAforest does
## not mask either original package.
##
## The randomForest method is vendored from extendedForest 1.6.2.1
## (Breiman/Cutler; R port by Liaw and Wiener), the gradientForest method from
## gradientForest 0.1-37 (Smith, Ellis and Dyer).  Licence: GPL (>= 2).
## ---------------------------------------------------------------------------

#' Variable importance
#'
#' Generic extracting variable importance from the forest objects built by
#' RDAforest. It replaces the \code{importance()} generics of
#' \pkg{extendedForest} and \pkg{gradientForest}, which are otherwise in
#' conflict, so that RDAforest masks neither package.
#'
#' @param x a \code{rdaf_randomForest} or \code{rdaf_gradientForest} object.
#' @param ... arguments passed to the method; see
#'   \code{\link{rdaf_importance.rdaf_randomForest}} and
#'   \code{\link{rdaf_importance.rdaf_gradientForest}}.
#' @return A named vector or matrix of importances; see the methods.
#' @seealso \code{\link{importance_RDAforest}} for the RDAforest-scale
#'   importance that accounts for the variance carried by each ordination axis.
#' @export
rdaf_importance <- function(x, ...) UseMethod("rdaf_importance")

#' @rdname rdaf_importance
#' @method rdaf_importance default
#' @export
rdaf_importance.default <- function(x, ...)
  stop("No method implemented for this class of object")

#' Variable importance of a random forest
#'
#' Extracts the permutation ("%IncMSE" / mean decrease in accuracy) and impurity
#' ("IncNodePurity" / mean decrease in Gini) importance measures from a forest
#' fitted by \code{\link{rdaf_randomForest}}.
#'
#' When the forest was fitted with an OOB blocks vector, the permutation measure
#' is computed on the withheld blocks rather than on a bootstrap out-of-bag
#' sample, which is what makes it robust to within-block autocorrelation.
#'
#' @param x an object of class \code{rdaf_randomForest}.
#' @param type either 1 (mean decrease in accuracy) or 2 (mean decrease in node
#'   impurity). \code{NULL} (the default) returns all columns.
#' @param class for classification forests, return the measure for this class
#'   only.
#' @param scale whether to divide the raw importance by its standard error.
#' @param ... not used.
#' @return A matrix of importance measures, one row per predictor.
#' @method rdaf_importance rdaf_randomForest
#' @export
rdaf_importance.rdaf_randomForest <- function(x, type=NULL, class=NULL,
                                              scale=TRUE, ...) {
    if (!inherits(x, "rdaf_randomForest"))
        stop("x is not of class rdaf_randomForest")
    classRF <- x$type != "regression"
    hasImp <- !is.null(dim(x$importance)) || ncol(x$importance) == 1
    hasType <- !is.null(type)
    if (hasType && type == 1 && !hasImp)
        stop("That measure has not been computed")
    allImp <- is.null(type) && hasImp
    if (hasType) {
        if (!(type %in% 1:2)) stop("Wrong type specified")
        if (type == 2 && !is.null(class))
            stop("No class-specific measure for that type")
    }

    imp <- x$importance
    if (hasType && type == 2) {
        if (hasImp) imp <- imp[, ncol(imp), drop=FALSE]
    } else {
        if (scale) {
            SD <- x$importanceSD
            imp[, -ncol(imp)] <-
                imp[, -ncol(imp), drop=FALSE] /
                    ifelse(SD < .Machine$double.eps, 1, SD)
        }
        if (!allImp) {
            if (is.null(class)) {
                ## The average decrease in accuracy measure:
                imp <- imp[, ncol(imp) - 1, drop=FALSE]
            } else {
                whichCol <- if (classRF) match(class, colnames(imp)) else 1
                if (is.na(whichCol)) stop(paste("Class", class, "not found."))
                imp <- imp[, whichCol, drop=FALSE]
            }
        }
    }
    imp
}
