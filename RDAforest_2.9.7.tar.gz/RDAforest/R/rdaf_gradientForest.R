## ---------------------------------------------------------------------------
## Vendored from gradientForest 0.1-37.
##
## Original authors: S.J. Smith, N. Ellis and P. Dyer
## Licence: GPL (>= 2).
##
## Incorporated into RDAforest so that the package is self-contained and so
## that the random forest engine could be extended with blocked (grouped)
## out-of-bag sampling.  Every function has been renamed with an `rdaf_`
## prefix; apart from that, and the changes noted inline, the code is the
## original.
## ---------------------------------------------------------------------------


#' Gradient forest, with optional handling of repeated samples per site
#'
#' Fits a random forest to each response column in turn, collects the
#' split-point improvements in impurity across all of them, and converts them
#' into a biologically informed importance scale: the cumulative importance, or
#' turnover, curve of each predictor. Vendored from \pkg{gradientForest} and
#' renamed so that it does not mask \code{gradientForest::gradientForest}; with
#' the same seed and \code{sites = NULL} it reproduces that function exactly.
#'
#' Within RDAforest the response columns are the leading principal components of
#' a genetic distance matrix, and this function is normally reached through
#' \code{\link{makeGF}} or \code{\link{makeGF_simple}} rather than called
#' directly.
#'
#' When several individuals are sampled at the same site they share exactly the
#' same predictor values, and \code{site.repeats} says what to do about that:
#'
#' \describe{
#'   \item{\code{"genetic.median"} (the default)}{Each site is collapsed, before
#'     any forest is grown, to a single synthetic individual at the geometric
#'     median of its members. The median is taken in the space of \strong{all}
#'     the response columns at once, that is, across all the principal
#'     coordinates supplied here, by Weiszfeld's iteration; see
#'     \code{\link{genetic_medians}}. All the forests are then fitted to the
#'     same one-row-per-site data, and \code{X} and \code{Y} in the returned
#'     object are the collapsed ones.}
#'   \item{\code{"blocked.resampling"}}{Every individual is kept, and each tree
#'     withholds a random \code{block.holdout} fraction of whole sites, drawing
#'     its training sample from the rows of the sites that remain.}
#'   \item{\code{"direct.use"}}{The site structure is ignored.}
#' }
#'
#' Response columns whose forest achieves a non-positive \eqn{R^2} are dropped,
#' as in the original. Under \code{"genetic.median"} and
#' \code{"blocked.resampling"} that test is a stricter one, since the site
#' structure can no longer flatter the fit, so expect fewer components to
#' survive than in a \code{"direct.use"} run.
#'
#' @param data data frame holding both the predictors and the responses.
#' @param predictor.vars names of the predictor columns.
#' @param response.vars names of the response columns.
#' @param ntree number of trees per response.
#' @param mtry number of predictors tried at each split; \code{NULL} uses the
#'   \code{\link{rdaf_randomForest}} default.
#' @param transform optional function applied to each response column.
#' @param maxLevel depth at which correlated predictors are permuted
#'   conditionally; 0 turns conditional permutation off. Note that under
#'   \code{"genetic.median"} the data are collapsed to one row per site, so a
#'   \code{maxLevel} computed from the number of individuals will be too large;
#'   \code{\link{makeGF}} and \code{\link{makeGF_simple}} take care of this.
#' @param corr.threshold correlation above which predictors are treated as
#'   correlated for conditional permutation.
#' @param compact whether to bin the split points, which saves a lot of memory
#'   on large problems.
#' @param nbin number of bins used when \code{compact = TRUE}.
#' @param trace whether to report progress across response columns.
#' @param check.names whether to insist that predictor and response names are
#'   syntactically valid column names.
#' @param sites optional categorical vector giving the site membership of each
#'   sample, one entry per row of \code{data} (a factor, character, integer or
#'   numeric vector). Supply it when several individuals were sampled at the
#'   same site, reef, population, family, sequencing batch or year, so that they
#'   share predictor values. \code{NULL} (the default) means no repeated
#'   sampling. See \code{\link{site_repeats_summary}}.
#' @param site.repeats how repeated samples within a site are handled, one of
#'   \code{"genetic.median"} (the default), \code{"blocked.resampling"} or
#'   \code{"direct.use"}. Ignored when \code{sites} is \code{NULL}. See
#'   Details.
#' @param block.holdout fraction of sites withheld from each tree under
#'   \code{site.repeats = "blocked.resampling"} (default \code{1/3}). It is
#'   rounded to a whole number of sites, clamped to at least one and at most all
#'   but one; a warning is issued if the rounding changes the fraction.
#' @param coords optional coordinates used when detecting repeated sampling
#'   automatically: either the names of the coordinate columns among
#'   \code{predictor.vars}, or a separate two-column object with one row per
#'   sample. \code{NULL} looks for coordinate columns by name. Ignored when
#'   \code{sites} is supplied.
#' @param auto.sites whether to look for repeated sampling when \code{sites} is
#'   not supplied (default \code{TRUE}). Samples that share a location and all
#'   their environmental values are taken to be one site, and are then handled
#'   according to \code{site.repeats}, with a message saying which mode was
#'   used; if \code{site.repeats} was left at its default that is
#'   \code{"genetic.median"}, but naming a mode overrides it. Samples that share
#'   a location but disagree on the environment draw a warning and are used
#'   directly; data with no shared locations are used directly and silently. See
#'   \code{\link{detect_sites}}. Set \code{FALSE} to switch the check off.
#' @param oob.blocks deprecated; use \code{sites} with
#'   \code{site.repeats = "blocked.resampling"}.
#' @param oob.block.holdout deprecated; use \code{block.holdout}.
#' @return An object of class \code{rdaf_gradientForest}: a list whose main
#'   components are \code{X} and \code{Y} (the data actually fitted, collapsed
#'   to one row per site under \code{"genetic.median"}), \code{result} (the
#'   \eqn{R^2} of each retained response), \code{imp.rsq} (predictor by
#'   response importance), \code{overall.imp} and \code{overall.imp2}
#'   (accuracy and impurity importance), \code{res} and \code{res.u} (the
#'   split tables), and \code{dens} (predictor densities). When \code{sites}
#'   was supplied it also carries \code{sites} and \code{site.repeats}, plus
#'   \code{block.holdout} under blocked resampling.
#' @seealso \code{\link{makeGF}}, \code{\link{rdaf_importance}},
#'   \code{\link{rdaf_cumimp}}, \code{\link{predict.rdaf_gradientForest}},
#'   \code{\link{site_repeats_summary}}, \code{\link{genetic_medians}}
#' @references Ellis N., Smith S.J. and Pitcher C.R. (2012) Gradient forests:
#'   calculating importance gradients on physical predictors. \emph{Ecology}
#'   93: 156-168.
#' @examples
#' set.seed(1)
#' n <- 60
#' site <- rep(paste0("site", 1:6), each = 10)
#' X <- data.frame(temp = rnorm(n), depth = runif(n), noise = rnorm(n))
#' Y <- data.frame(pc1 = 2 * X$temp + rnorm(n), pc2 = X$depth + rnorm(n))
#' gf <- rdaf_gradientForest(cbind(X, Y), names(X), names(Y), ntree = 100,
#'                           sites = site, site.repeats = "blocked.resampling")
#' rdaf_importance(gf, type = "Weighted")
#' @export
`rdaf_gradientForest` <-
function(data,predictor.vars,response.vars,ntree=10,mtry=NULL, transform=NULL,maxLevel=0,corr.threshold=0.5,compact=FALSE,nbin=101,trace=FALSE, check.names=TRUE,
         sites=NULL, site.repeats=c("genetic.median","blocked.resampling","direct.use"),
         block.holdout=1/3, coords=NULL, auto.sites=TRUE,
         oob.blocks=NULL, oob.block.holdout=NULL)
{
  #Modified 07/10/2009 by S.J. Smith for Nick Ellis' version for either
  #regression or classification trees.

  if(!inherits(data, "data.frame"))
    stop("'data' must be a data.frame")
  if (check.names) {
    validated_pred_names <- make.names(predictor.vars)
    if(any(validated_pred_names != predictor.vars)) {
      invalid_names <- predictor.vars[validated_pred_names != predictor.vars]
      stop(paste0("Some predictor names are not valid column names, consider renaming with make.names(). Force use of invalid col names with check.names=FALSE. Invalid Col names: [", paste0(invalid_names, collapse = "], ["), "]. "))
    }
    validated_resp_names <- make.names(response.vars)
    if(any(validated_resp_names != response.vars)) {
      invalid_names <- response.vars[validated_resp_names != response.vars]
      stop(paste0("Some response names are not valid column names, consider renaming with make.names().Force use of invalid col names with check.names=FALSE. Invalid Col names: [", paste0(invalid_names, collapse = "], ["), "]. "))
    }
  }
  X <- data[predictor.vars]
  Y <- data[response.vars]

  validate_pred_vals <- sapply(predictor.vars, function(pred,x){length(unique(x[[pred]])) > 1}, x=X)
  if (!all(validate_pred_vals)) {
    stop(paste0("One of the predictors is constant across all sites. Please remove [", predictor.vars[!validate_pred_vals], "]"))
  }
  ## --- repeated samples within sites (RDAforest addition) -----------------
  ## Resolve `site.repeats` once, before any forest is grown, so that a bad
  ## `sites` vector is reported immediately.  Under "genetic.median" the data
  ## are collapsed here, to one synthetic individual per site placed at the
  ## geometric median of its members in the space of ALL the response columns
  ## (all the principal coordinates supplied), so every response is then fitted
  ## to the same collapsed data.
  ## did the caller name a mode of their own?  Must be asked before anything
  ## reassigns `site.repeats`.
  .explicit <- !missing(site.repeats)
  dep <- .rdaf_deprecate_oob_blocks(sites, site.repeats, block.holdout,
                                    oob.blocks, oob.block.holdout)
  sites <- dep$sites; site.repeats <- dep$site.repeats
  block.holdout <- dep$block.holdout
  ## With no `sites` given, look for repeated sampling in the predictors
  ## themselves; see detect_sites().
  res <- .rdaf_resolve_sites(X, sites, site.repeats, coords, auto.sites,
                             .explicit)
  sites <- res$sites; site.repeats <- res$site.repeats
  srep <- .rdaf_check_site_repeats(sites, nrow(X), site.repeats, block.holdout)
  if (srep$mode == "genetic.median") {
    coll <- .rdaf_collapse_sites(X, Y, srep$factor)
    X <- coll$X
    Y <- coll$Y
  }
  ## The blocking vector handed to each forest: only blocked resampling uses it.
  fit.sites <- if (srep$mode == "blocked.resampling") srep$factor else NULL
  ## ------------------------------------------------------------------------

  if (compact) {
    bins <- do.call("cbind",lapply(X, function(x) bin(x,nbin=nbin))) #Nick Ellis 9/12/2009
  }
  
  if(!is.null(transform))
  {
    Y<-apply(Y,2,transform)  #S.J. Smith 18/01/2010
  } 
  imp <- matrix(0,0,2,dimnames=list(NULL,c("%IncMSE","IncNodePurity")))
  #  fitcmd <- quote(rdaf_randomForest(Species ~ rhs, data=cbind(Y,X), keep.forest=T, importance=TRUE, na.action=na.omit, keep.inbag=FALSE, ntree=ntree))
  #Conditional permutation version of rF.  Nick Ellis 22/12/2009
  ## Convert to x, y format
  if(is.null(mtry)) {
    ## makes use of closures
    fitfunc <- function(spec_vec) {
      rdaf_randomForest(x = X, y = spec_vec,  maxLevel=maxLevel, keep.forest=TRUE, importance=TRUE, ntree=ntree, keep.group=TRUE, keep.inbag=TRUE, corr.threshold=corr.threshold, sites=fit.sites, site.repeats="blocked.resampling", block.holdout=block.holdout, auto.sites=FALSE)
    }
  } else {
    fitfunc <- function(spec_vec) {
      rdaf_randomForest(x = X, y = spec_vec,  maxLevel=maxLevel, keep.forest=TRUE, importance=TRUE, ntree=ntree, mtry=mtry, keep.group=TRUE, keep.inbag=TRUE, corr.threshold=corr.threshold, sites=fit.sites, site.repeats="blocked.resampling", block.holdout=block.holdout, auto.sites=FALSE)
    }
  }
  ## if(is.null(mtry)) fitcmd <- quote(rdaf_randomForest(Species ~ rhs, data=cbind(Y,X), maxLevel=maxLevel, keep.forest=TRUE, importance=TRUE, ntree=ntree, keep.group=TRUE, keep.inbag=TRUE, corr.threshold=corr.threshold, na.action=na.omit))
  ## else fitcmd <- quote(rdaf_randomForest(Species ~ rhs, data=cbind(Y,X), maxLevel=maxLevel, keep.forest=TRUE, importance=TRUE, ntree=ntree, mtry=mtry, keep.group=TRUE, keep.inbag=TRUE, corr.threshold=corr.threshold, na.action=na.omit))
  result <- list()
  species.pos.rsq<-0
  #form.rhs<-as.formula(paste("Y ~ ", paste(predictor.vars,collapse = "+"))) #added to replace functions makeForms and plus.  SJ Smith 25/06/2009
  if (trace) {spcount <- 0; cat("Calculating forests for",length(response.vars),"species\n")}
  for (spec in response.vars) {
    if (trace) cat(if((spcount <- spcount+1) %% options("width")$width == 0) "\n." else ".")
    try({
      #thisfitcmd <- do.call("substitute",list(fitcmd,list(Species=as.name(spec),SpeciesName=spec,ntree=ntree,rhs=form.rhs[[3]])))
      fit <- fitfunc(Y[[spec]])#eval(thisfitcmd)
      if (fit$type == "regression") {
        if(!is.na(fit$rsq[fit$ntree])) { 
          if(fit$rsq[fit$ntree] > 0) {
            species.pos.rsq<-species.pos.rsq+1
            if (compact) {
              result[[spec]] <- .rdaf_getSplitImproveCompact(fit,bins)   #added by Nick 06/12/2009
            } else {
              result[[spec]] <- .rdaf_getSplitImprove(fit,X)   #added by Nick 12/05/2009
            }
            imp <- rbind(imp,fit$importance)
          }
        }
      } 
      else if (fit$type == "classification") {
      if(!is.na(fit$err.rate[fit$ntree,"OOB"])){
        # p is proportion of Y on first level (e.g. absent)
        p <- sum(Y[[spec]] == levels(Y[[spec]])[1])/ length(Y[[spec]])
        err0 <-  2*p*(1-p)
        if(fit$err.rate[fit$ntree,"OOB"] < 2*p*(1-p)) {
          species.pos.rsq<-species.pos.rsq+1
          if (compact) {
            result[[spec]] <- .rdaf_getSplitImproveClassCompact(fit,bins,err0)   #added by Nick 10/12/2009
          } else {
            result[[spec]] <- .rdaf_getSplitImproveClass(fit,X,err0)   #added by Nick 24/05/2009
          }
          nclass <- length(levels(Y[[spec]]))
          imp <- rbind(imp,fit$importance[,-(1:nclass)])
        }
        }
      } 
      else stop(paste("unknown rdaf_randomForest type:",fit$type))
    },silent=FALSE)
  }

  if (!length(result)) {
    stop("No species models provided a positive R^2. \nThe gradient forest is empty")
    return(NULL)
  }
  
  rsq <- sapply(result,function(x) x$rsq[1])
  imp.rsq <- matrix(imp[,1],length(predictor.vars),dimnames=list(predictor.vars,names(result)))
  imp.rsq[imp.rsq<0] <- 0
  imp.rsq <- sweep(imp.rsq,2,colSums(imp.rsq,na.rm=T),"/")
  imp.rsq <- sweep(imp.rsq,2,rsq,"*")
  overall.imp  <- tapply(imp[,1],dimnames(imp)[[1]],mean,na.rm=T)
  overall.imp2 <- tapply(imp[,2],dimnames(imp)[[1]],mean,na.rm=T)  
  out1 <- list(
    X=X,Y=Y,result=result,overall.imp=overall.imp,overall.imp2=overall.imp2,ntree=ntree,
    imp.rsq=imp.rsq,species.pos.rsq=species.pos.rsq,ranForest.type=fit$type,
    sites=if (srep$mode == "none") NULL else srep$factor,
    site.repeats=if (srep$mode == "none") NULL else srep$mode,
    block.holdout=if (srep$mode == "blocked.resampling") block.holdout else NULL
    )
  out2 <- .rdaf_impurity_measures(out1)    
  out1$result <- rsq #modified November 2009, S.J. Smith
  out <- c(out1,out2,call=match.call())
  class(out) <- c("rdaf_gradientForest","list")
  out
}



`.rdaf_impurity_measures` <-function(obj)
{
    #becomes an internal function not usually used by users
    #Modified 07/10/2009 by SJS re: NE changes for classification trees.
    dens <- lapply(names(obj$X), function(i) density(na.omit(obj$X[,i]),from=min(na.omit(obj$X[,i])),to=max(na.omit(obj$X[,i]))))
    dens <- lapply(dens,.rdaf_whiten,lambda=0.90) # hard-coded whitening
    names(dens) <- names(obj$X)
    res <- do.call("rbind", lapply(names(obj$result), function(spec) cbind(spec=spec,obj$result[[spec]]))) #added by Smith 13/05/2009
    res$spec <- as.factor(res$spec)
    res$improve <- pmax(0,res$improve)
    res$rsq <- pmax(0,res$rsq)   #added by Ellis 12/05/2009
    res$improve.tot <- tapply(res$improve,res$spec,sum)[res$spec]
    res$improve.tot.var <- tapply(res$improve,interaction(res$spec,res$var),sum)[interaction(res$spec,res$var)]
    res$improve.norm <- with(res,improve/improve.tot*rsq)
    nodup <- !duplicated(res[,1:2])
    res.u <- res[nodup, c("spec","var","rsq","improve.tot","improve.tot.var")]
    res.u$rsq <- with(res.u, ifelse(is.na(rsq), 0, rsq))
    res.u$rsq.var <- with(res.u,rsq*improve.tot.var/improve.tot)
    list(res=res,res.u=res.u,dens=dens)
  }


`.rdaf_agg_sum` <- function(x, by, sort.it = F)
{
	if(!is.data.frame(by))
		by <- data.frame(by)
	if(sort.it) {
		ord <- do.call("order", unname(by))
		x <- x[ord]
		by <- by[ord,  , drop=F]
	}
	logical.diff <- function(group)
	group[-1] != group[ - length(group)]
	change <- logical.diff(by[[1]])
	for(i in seq(along = by)[-1])
		change <- change | logical.diff(by[[i]])
  by <- by[c(T, change),  , drop = F]
	by$x <- diff(c(0, cumsum(x)[c(change, T)]))
	by
}


#
# Functions for binning
# R function density tends to spread bins out too far and can be negative
#
midpoints <- function(x) {
# points between equally spaced points
  0.5*(x[-1]+x[-length(x)])
}
spread <- function(x) {
# output y satisfies midpoints(y) == x
  n <- length(x)
  c(x[1]-(x[2]-x[1])/2,midpoints(x),x[n]+(x[n]-x[n-1])/2)
}
bin <- function(x,nbin) {
  r <- range(x,na.rm=T)
  midbins <- seq(r[1],r[2],len=nbin)
  spread(midbins)
}
#

`.rdaf_whiten` <-
function(dens, lambda=0.9)
{
    # add a small uniform value to the density to avoid zeroes when taking inverse
    dens$y <- lambda*dens$y + (1-lambda)/diff(range(dens$x))
    dens
}

#
# Simple utility to add duplicate string values in the names
# Useful with lapply to force the names into the names of the resulting list
#
.rdaf_namenames <- function(x) structure(x,names=x)


.rdaf_n2mfrow <- function(n) {
  # choose plotting array shape for n panels
  if (length(n) != 1) stop(paste("n must be a single number"))
  if (n==1) return(c(1,1))
  if (n==2) return(c(1,2))
  if (n==3) return(c(2,2))
  n1 <- floor(sqrt(n))
  n2 <- ceiling(n/n1)
  c(n1,n2)
}


`.rdaf_getSplitImprove` <-function(fit, X) {
#   return a data-frame: var name, rsq, var number, split value, improvement
    trees <- lapply(1:fit$ntree, function(k) try(rdaf_getTree(fit, k),silent=TRUE)) #Nick Ellis 10/12/2009
    ok <- sapply(trees, class) != "try-error"
    if(!is.vector(ok)){
      ok <- apply(ok, 2, all)
    }
    tmp <- do.call("rbind", lapply((1:fit$ntree)[ok], function(k) cbind(tree =
                                                                          k, trees[[k]])))
    tmp <- tmp[tmp[,"status"]==-3 & zapsmall(tmp[,"improve"]) > 0,c("split var","split point","improve"), drop = FALSE]
    colnames(tmp) <- c("var_n","split","improve")
    rownames(tmp)<-NULL     #S.J. Smith 11/05/2009
    res <- cbind(data.frame(var=factor(names(X)[tmp[,"var_n"]], levels = names(X)),rsq=rep(fit$rsq[fit$ntree],nrow(tmp))),tmp)
    ok <- zapsmall(res[,"improve"]) > 0
    res[ok,] 
  }


`.rdaf_getSplitImproveClass` <- 
 function(fit, X, err0)
{
#   return a data-frame: var name, rsq, var number, split value, improvement
  	trees <- lapply(1:fit$ntree, function(k) try(rdaf_getTree(fit, k),silent=TRUE)) #Nick Ellis 10/12/2009
    ok <- sapply(trees, class) != "try-error"
    if(!is.vector(ok)){
      ok <- apply(ok, 2, all)
    }
 	tmp <- do.call("rbind", lapply((1:fit$ntree)[ok], function(k) cbind(tree = k, trees[[k]])))
    tmp <- tmp[tmp[,"status"]==1,c("split var","split point","improve"), drop = FALSE]
    dimnames(tmp) <- list(NULL,c("var_n","split","improve"))
    res<-cbind(data.frame(var=factor(names(X)[tmp[,"var_n"]], levels = names(X)),rsq=rep((err0-fit$err.rate[fit$ntree,"OOB"])/err0,nrow(tmp))),tmp)
    res
}


`.rdaf_getSplitImproveCompact` <- function(fit, bins) {
#   Return a data-frame: var name, rsq, split value, improvement
#   Compact the splits into bins defined by bins matrix
#   The i'th bin for predictor p is the interval (bin[i,p],bin[i+1,p])
#   Every predictor is split into the same number of bins (nrow(bins)-1)

#   extract all trees to a matrix and select for splits with some improvement
  	trees <- lapply(1:fit$ntree, function(k) try(rdaf_getTree(fit, k),silent=TRUE)) #Nick Ellis 10/12/2009
    ok <- sapply(trees, class) != "try-error"
    if(!is.vector(ok)){
      ok <- apply(ok, 2, all)
    }
  	tmp <- do.call("rbind", lapply((1:fit$ntree)[ok], function(k) cbind(tree = k, trees[[k]])))
    tmp <- tmp[tmp[,"status"]==-3 & zapsmall(tmp[,"improve"]) > 0,c("split var","split point","improve"), drop = FALSE]
    colnames(tmp) <- c("var_n","split","improve")
    rownames(tmp) <- NULL

#   assign the split to the appropriate bin and aggregate importance in each bin
    Xnames <- colnames(bins)
    tmp <- data.frame(var=factor(Xnames[tmp[,"var_n"]], levels = Xnames), tmp, bin=rep(0,nrow(tmp)))
    for(p in Xnames) {
        if(any(sub <- with(tmp,var==p)))
          tmp$bin[sub] <- as.numeric(cut(tmp$split[sub], bins[,p], include=TRUE, ordered=TRUE))
    }
    tmp <- with(tmp[tmp$bin>0,],.rdaf_agg_sum(improve,list(var,bin),sort.it=TRUE))
    names(tmp) <- c("var","bin","improve")
    
#   Set the split value to the bin centre, but retain the bin number in case
#   the bin centre is not appropriate value
    tmp <- cbind(tmp,split=rep(NA,nrow(tmp)),rsq=fit$rsq[fit$ntree])
    midpoints <- function(x) 0.5*(x[-1]+x[-length(x)]) # points between equally spaced points
    for(p in Xnames) {
        if(any(sub <- with(tmp,var==p)))
          tmp$split[sub] <- midpoints(bins[,p])[tmp$bin[sub]]
    }
    tmp[,c("var","rsq","split","improve","bin")]
}


`.rdaf_getSplitImproveClassCompact` <- function(fit, bins, err0) {
#   Return a data-frame: var name, rsq, split value, improvement
#   Compact the splits into bins defined by bins matrix
#   The i'th bin for predictor p is the interval (bin[i,p],bin[i+1,p])
#   Every predictor is split into the same number of bins (nrow(bins)-1)

#   extract all trees to a matrix and select for splits with some improvement
  	trees <- lapply(1:fit$ntree, function(k) try(rdaf_getTree(fit, k),silent=TRUE)) #Nick Ellis 10/12/2009
    ok <- sapply(trees, class) != "try-error"
    if(!is.vector(ok)){
      ok <- apply(ok, 2, all)
    }
  	tmp <- do.call("rbind", lapply((1:fit$ntree)[ok], function(k) cbind(tree = k, trees[[k]])))
    tmp <- tmp[tmp[,"status"]== 1 & zapsmall(tmp[,"improve"]) > 0,c("split var","split point","improve"), drop = FALSE]
    colnames(tmp) <- c("var_n","split","improve")
    rownames(tmp) <- NULL

#   assign the split to the appropriate bin and aggregate importance in each bin
    Xnames <- colnames(bins)
    tmp <- data.frame(var=factor(Xnames[tmp[,"var_n"]], levels = Xnames), tmp, bin=rep(0,nrow(tmp)))
    for(p in Xnames) {
        if(any(sub <- with(tmp,var==p)))
          tmp$bin[sub] <- as.numeric(cut(tmp$split[sub], bins[,p], include=TRUE, ordered=TRUE))
    }
    tmp <- with(tmp[tmp$bin>0,],.rdaf_agg_sum(improve,list(var,bin),sort.it=TRUE))
    names(tmp) <- c("var","bin","improve")
    
#   Set the split value to the bin centre, but retain the bin number in case
#   the bin centre is not appropriate value
    tmp <- cbind(tmp,split=rep(NA,nrow(tmp)),rsq=rep((err0-fit$err.rate[fit$ntree, "OOB"])/err0, nrow(tmp)))
    for(p in Xnames) {
        if(any(sub <- with(tmp,var==p)))
          tmp$split[sub] <- midpoints(bins[,p])[tmp$bin[sub]]
    }
    tmp[,c("var","rsq","split","improve","bin")]
}
