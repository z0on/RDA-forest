## ---------------------------------------------------------------------------
## Vendored from extendedForest 1.6.2.1.
##
## Original authors: Fortran original by Leo Breiman and Adele Cutler; R port by Andy Liaw and
##   Matthew Wiener; split-improvement modifications by Nick Ellis
## Licence: GPL (>= 2).
##
## Incorporated into RDAforest so that the package is self-contained and so
## that the random forest engine could be extended with blocked (grouped)
## out-of-bag sampling.  Every function has been renamed with an `rdaf_`
## prefix; apart from that, and the changes noted inline, the code is the
## original.
## ---------------------------------------------------------------------------


#' Extract a single tree from a forest
#'
#' Returns one tree of a \code{\link{rdaf_randomForest}} object as a matrix,
#' one row per node. This is how \code{\link{rdaf_gradientForest}} harvests the
#' split points and impurity improvements that become turnover curves. Vendored
#' from \pkg{extendedForest}, which adds the \code{SS} and \code{improve}
#' columns to the original \pkg{randomForest} version.
#'
#' @param rfobj an object of class \code{rdaf_randomForest}, fitted with
#'   \code{keep.forest = TRUE}.
#' @param k which tree to extract.
#' @param labelVar whether to give the split variables and predicted classes
#'   their names rather than integer codes.
#' @return A matrix (or data frame when \code{labelVar = TRUE}) with columns
#'   \code{left daughter}, \code{right daughter}, \code{split var},
#'   \code{split point}, \code{status}, \code{prediction}, \code{improve},
#'   and for regression also \code{SS}.
#' @seealso \code{\link{rdaf_randomForest}}
#' @export
rdaf_getTree <- function(rfobj, k=1, labelVar=FALSE) {
  if (is.null(rfobj$forest)) {
    stop("No forest component in ", deparse(substitute(rfobj)))
  }
  if (k > rfobj$ntree) {
    stop("There are fewer than ", k, "trees in the forest")
  }
  if (rfobj$type == "regression") {
      tree <- cbind(rfobj$forest$leftDaughter[,k],
                    rfobj$forest$rightDaughter[,k],
                    rfobj$forest$bestvar[,k],
                    rfobj$forest$xbestsplit[,k],
                    rfobj$forest$nodestatus[,k],
                    rfobj$forest$nodepred[,k],
                    rfobj$forest$nodeSS[,k],
                    rfobj$forest$nodeImprove[,k])[1:rfobj$forest$ndbigtree[k],,drop=F]
      dimnames(tree) <- list(1:nrow(tree), c("left daughter", "right daughter",
                                         "split var", "split point", "status",
                                         "prediction", "SS", "improve"))
  } else {
      tree <- cbind(rfobj$forest$treemap[,,k],
                    rfobj$forest$rightDaughter[,k],
                    rfobj$forest$bestvar[,k],
                    rfobj$forest$xbestsplit[,k],
                    rfobj$forest$nodestatus[,k],
                    rfobj$forest$nodepred[,k],
                    rfobj$forest$nodeImprove[,k])[1:rfobj$forest$ndbigtree[k],,drop=F]
      dimnames(tree) <- list(1:nrow(tree), c("left daughter", "right daughter",
                                         "split var", "split point", "status",
                                         "prediction", "improve"))
  }


  if (labelVar) {
      tree <- as.data.frame(tree)
      v <- tree[[3]]
      v[v == 0] <- NA
      tree[[3]] <- factor(rownames(rfobj$importance)[v])
      if (rfobj$type == "classification") {
          v <- tree[[6]]
          v[! v %in% 1:nlevels(rfobj$y)] <- NA
          tree[[6]] <- levels(rfobj$y)[v]
      }
  }
  tree
}




#' How often each predictor was used for splitting
#'
#' Counts the splits made on each predictor across a forest. Vendored from
#' \pkg{extendedForest}.
#'
#' @param x an object of class \code{rdaf_randomForest} fitted with
#'   \code{keep.forest = TRUE}.
#' @param by.tree whether to tabulate separately for each tree.
#' @param count whether to count the splits (\code{TRUE}) or just list which
#'   predictors were used (\code{FALSE}).
#' @return A vector, or a matrix when \code{by.tree = TRUE}.
#' @seealso \code{\link{rdaf_randomForest}}, \code{\link{rdaf_importance}}
#' @export
rdaf_varUsed <- function(x, by.tree=FALSE, count=TRUE) {
    if (!inherits(x, "rdaf_randomForest"))
        stop(deparse(substitute(x)), "is not a rdaf_randomForest object")
    if (is.null(x$forest))
        stop(deparse(substitute(x)), "does not contain forest")
    
    p <- length(x$forest$ncat)  # Total number of variables.
    if (count) {
        if (by.tree) {
            v <- apply(x$forest$bestvar, 2, function(x) {
                xx <- numeric(p)
                y <- table(x[x>0])
                xx[as.numeric(names(y))] <- y
                xx
            })
        } else {
            v <- numeric(p)
            vv <- table(x$forest$bestvar[x$forest$bestvar > 0])
            v[as.numeric(names(vv))] <- vv
        }
    } else {
        v <- apply(x$forest$bestvar, 2, function(x) sort(unique(x[x>0])))
        if(!by.tree) v <- sort(unique(unlist(v)))
    }
    v
}



#' Sizes of the trees in a forest
#'
#' Vendored from \pkg{extendedForest}.
#'
#' @param x an object of class \code{rdaf_randomForest} fitted with
#'   \code{keep.forest = TRUE}.
#' @param terminal whether to count terminal nodes only (\code{TRUE}) or all
#'   nodes (\code{FALSE}).
#' @return A numeric vector of length \code{ntree}.
#' @seealso \code{\link{rdaf_randomForest}}
#' @export
rdaf_treesize <- function(x, terminal=TRUE) {
  if(!inherits(x, "rdaf_randomForest"))
    stop("This function only works for objects of class `rdaf_randomForest'")
  if(is.null(x$forest)) stop("The object must contain the forest component")
  if(terminal) return((x$forest$ndbigtree+1)/2) else return(x$forest$ndbigtree)
}



#' Print a random forest
#'
#' @param x an object of class \code{rdaf_randomForest}.
#' @param ... not used.
#' @return \code{x}, invisibly; called for the printed summary.
#' @seealso \code{\link{rdaf_randomForest}}
#' @method print rdaf_randomForest
#' @export
"print.rdaf_randomForest" <-
function(x, ...) {
  cat("\nCall:\n", deparse(x$call), "\n")
  cat("               Type of random forest: ", x$type, "\n", sep="")
  cat("                     Number of trees: ", x$ntree, "\n",sep="")
  cat("No. of variables tried at each split: ", x$mtry, "\n\n", sep="")
  if(x$type == "classification") {
    if(!is.null(x$confusion)) {
      cat("        OOB estimate of  error rate: ",
          round(x$err.rate[x$ntree, "OOB"]*100, digits=2), "%\n", sep="")
      cat("Confusion matrix:\n")
      print(x$confusion)
      if(!is.null(x$test$err.rate)) {
        cat("                Test set error rate: ",
            round(x$test$err.rate[x$ntree, "Test"]*100, digits=2), "%\n",
            sep="")
        cat("Confusion matrix:\n")
        print(x$test$confusion)
      }
    }
  }
  if(x$type == "regression") {
    if(!is.null(x$mse)) {
      cat("          Mean of squared residuals: ", x$mse[length(x$mse)],
          "\n", sep="")
      cat("                    % Var explained: ",
          round(100*x$rsq[length(x$rsq)], digits=2), "\n", sep="")
      if(!is.null(x$test$mse)) {
        cat("                       Test set MSE: ",
            round(x$test$mse[length(x$test$mse)], digits=2), "\n", sep="")
        cat("                    % Var explained: ",
            round(100*x$test$rsq[length(x$test$rsq)], digits=2), "\n", sep="")
      }      
    }
    if (!is.null(x$coefs)) {
      cat("  Bias correction applied:\n")
      cat("  Intercept: ", x$coefs[1], "\n")
      cat("      Slope: ", x$coefs[2], "\n")
    }
  }
}



#' Plot the error rate of a forest against the number of trees
#'
#' For a blocked forest the curve is the blocked out-of-bag error, which is
#' typically higher and flatter than the bootstrap version.
#'
#' @param x an object of class \code{rdaf_randomForest}.
#' @param type plot type passed to \code{\link[graphics]{matplot}}.
#' @param main plot title.
#' @param ... further graphical parameters.
#' @return The matrix of error rates, invisibly.
#' @seealso \code{\link{rdaf_randomForest}}
#' @method plot rdaf_randomForest
#' @export
plot.rdaf_randomForest <- function(x, type="l", main=deparse(substitute(x)), ...) {
  if(x$type == "unsupervised")
    stop("No plot for unsupervised randomForest.")
  test <- !(is.null(x$test$mse) || is.null(x$test$err.rate))
  if(x$type == "regression") {
    err <- x$mse
    if(test) err <- cbind(err, x$test$mse)
  } else {
    err <- x$err.rate
    if(test) err <- cbind(err, x$test$err.rate)
  }
  if(test) {
    colnames(err) <- c("OOB", "Test")
    matplot(1:x$ntree, err, type = type, xlab="trees", ylab="Error",
            main=main, ...)
  } else {
    matplot(1:x$ntree, err, type = type, xlab="trees", ylab="Error",
            main=main, ...)
  }
  invisible(err)
}

  
