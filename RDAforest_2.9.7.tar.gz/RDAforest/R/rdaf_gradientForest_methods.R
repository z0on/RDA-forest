## ---------------------------------------------------------------------------
## Vendored from gradientForest 0.1-37.
##
## Original authors: S.J. Smith, N. Ellis and P. Dyer
## Licence: GPL (>= 2).
##
## Incorporated into RDAforest so that the package is self-contained and so
## that the random forest engine could be extended with blocked (grouped)
## out-of-bag sampling.  Every function has been renamed with an `rdaf_`
## prefix; apart from that, and the changes noted inline, the code is the
## original.
## ---------------------------------------------------------------------------


#' Cumulative importance of a predictor
#'
#' Generic for the cumulative importance (turnover) curve of a predictor in a
#' gradient forest. Vendored from \pkg{gradientForest} and renamed so that it
#' does not mask \code{gradientForest::cumimp}.
#'
#' @param x an object of class \code{rdaf_gradientForest}.
#' @param ... passed to the method.
#' @return A list with components \code{x} (split positions) and \code{y}
#'   (cumulative importance), or a list of such lists when
#'   \code{type = "Species"}.
#' @seealso \code{\link{rdaf_cumimp.rdaf_gradientForest}}
#' @export
rdaf_cumimp <- function (x, ...)
UseMethod("rdaf_cumimp")



#' Cumulative importance curve of a gradient forest predictor
#'
#' Accumulates the impurity improvements of every split made on one predictor,
#' standardised by the density of the predictor's observed values, to give the
#' turnover curve that RDAforest plots and clusters on.
#'
#' @param x an object of class \code{rdaf_gradientForest}.
#' @param predictor name of the predictor, as a single string.
#' @param type \code{"Overall"} for the curve summed across response columns,
#'   or \code{"Species"} for one curve per response column.
#' @param standardize whether to divide by the density of the predictor values,
#'   so that importance is not merely a reflection of where the data are dense.
#' @param standardize_after whether the standardisation is applied after rather
#'   than before rescaling to \eqn{R^2}.
#' @param ... not used.
#' @return A list with \code{x} and \code{y}, or a named list of such lists
#'   when \code{type = "Species"}.
#' @seealso \code{\link{rdaf_gradientForest}}, \code{\link{plot_turnover}}
#' @method rdaf_cumimp rdaf_gradientForest
#' @export
`rdaf_cumimp.rdaf_gradientForest` <-
function (x, predictor, type=c("Overall","Species")[1], standardize=TRUE, standardize_after=FALSE,
    ...)
{
  if (!inherits(x,"rdaf_gradientForest"))
    stop(paste("'x' must be a rdaf_gradientForest object"))
  if (length(predictor) != 1)
    stop(paste("'predictor' must be a single string"))
  if (!is.element(predictor,levels(x$res$var)))
    stop(paste("Predictor",predictor,"does not belong to rdaf_gradientForest object"))
  if (is.na(option <- pmatch(type,c("Overall","Species"))))
    stop(paste('Unmatched type "',type,'". Expecting one of "Overall" or "Species"',sep=''))
    
  # convert density to its inverse
  inverse <- function(dens) {dens$y <- 1/dens$y; dens}
  
  # crude integral
  crude.integrate <- function(f) sum(f$y)*diff(f$x)[1]
  
  # normalize f(x) to f(x)/fbar
  normalize <- function(f) {
    integral <- try(integrate(approxfun(f,rule=2),lower=min(f$x),upper=max(f$x))$value)
    if (class(integral)=="try-error") integral <- crude.integrate(f)
    f$y <- f$y/integral*diff(range(f$x)); 
    f
  }
     
  getCU <- function(importance.df, Rsq) {
    if (nrow(importance.df) == 0) {
      return( list(x=0, y=0))
    }
    agg <- with(importance.df, .rdaf_agg_sum(improve.norm, list(split), sort.it=TRUE))
    cum.split <- agg[,1]
    height <- agg[,2] 
    if (standardize & standardize_after) # crucial to normalize this case
      dinv <- normalize(inverse(x$dens[[predictor]]))
    else dinv <- inverse(x$dens[[predictor]]) # 
    dinv.vals <- approx(dinv$x, dinv$y, cum.split, rule=2)$y
    if (any(bad <- is.na(height))) {
      cum.split <- cum.split[!bad]
      height <- height[!bad]
      dinv.vals <- dinv.vals[!bad]
    }
    if (standardize & !standardize_after) height <- height * dinv.vals
    height <- height/sum(height)*Rsq
    if (standardize & standardize_after) height <- height * dinv.vals
    res <- list(x=cum.split, y=cumsum(height))
  }
  
  importance.df <- x$res[x$res$var==predictor,]
  if (option==1) {
    res <- getCU(importance.df, rdaf_importance(x, "Weighted")[predictor])
  } else {
    species <- names(x$result)
    res <- lapply(.rdaf_namenames(species), function(sp)  
      getCU(subset(importance.df, spec==sp), x$imp.rsq[predictor,sp]))
  }
  res
}



#' Variable importance of a gradient forest
#'
#' Importance of each predictor in a \code{\link{rdaf_gradientForest}} object,
#' on one of several scales. Vendored from \pkg{gradientForest}.
#'
#' With a blocked forest these are out-of-block importances: they say how much a
#' predictor helps on groups the trees never saw, which is usually a good deal
#' less flattering than the bootstrap version, especially for predictors that
#' effectively encode group identity.
#'
#' @param x an object of class \code{rdaf_gradientForest}.
#' @param type one of \code{"Accuracy"} (mean decrease in accuracy),
#'   \code{"Impurity"} (mean decrease in node impurity), \code{"Weighted"}
#'   (the default: mean \eqn{R^2}-weighted importance across response columns),
#'   \code{"Raw"}, or \code{"Species"} (the \eqn{R^2} of each response
#'   column rather than of each predictor).
#' @param sort whether to sort in decreasing order.
#' @param ... not used.
#' @return A named numeric vector.
#' @seealso \code{\link{rdaf_importance}},
#'   \code{\link{importance_RDAforest}}
#' @method rdaf_importance rdaf_gradientForest
#' @export
`rdaf_importance.rdaf_gradientForest` <-
function (x, type=c("Accuracy","Impurity","Weighted","Raw","Species")[3], sort=TRUE, ...)
{
    if (!inherits(x,"rdaf_gradientForest"))
      stop(paste("'x' must be a rdaf_gradientForest object"))
    weighted <- rowSums(x$imp.rsq, na.rm=TRUE)/ncol(x$imp.rsq)
    if (sort)
      o <- order(-weighted)
    else o <- 1:length(weighted)
    nam <- rownames(x$imp.rsq)
    res <- switch(pmatch(type,c("Accuracy","Impurity","Weighted","Raw","Species")),
      x$overall.imp[nam][o],
      x$overall.imp2[nam][o],
      weighted[o],
      rowSums(sweep(x$imp.rsq,2,x$result,"/"), na.rm=TRUE)[o]/ncol(x$imp.rsq),
      if (sort) sort(x$result,decreasing=TRUE) else x$result
    )
    if (is.null(res))
      stop(paste('Unmatched type "',type,'". Expecting one of "Accuracy", "Impurity", "Weighted", "Raw" or "Species"',sep=""))
    else res
}



#' Density of a predictor in a gradient forest
#'
#' Returns the stored kernel density of one predictor's observed values, as used
#' to standardise its cumulative importance curve.
#'
#' @param x an object of class \code{rdaf_gradientForest}.
#' @param predictor name of the predictor.
#' @param ... not used.
#' @return A \code{\link[stats]{density}} object.
#' @seealso \code{\link{rdaf_cumimp}}
#' @method density rdaf_gradientForest
#' @export
`density.rdaf_gradientForest` <-
function(x,predictor,...)
{
    if (!inherits(x,"rdaf_gradientForest"))
      stop(paste("'x' must be a rdaf_gradientForest object"))
    x$dens[[predictor]]
}



#' Print a gradient forest
#'
#' @param x an object of class \code{rdaf_gradientForest}.
#' @param ... not used.
#' @return \code{x}, invisibly; called for the printed summary.
#' @seealso \code{\link{rdaf_gradientForest}}
#' @method print rdaf_gradientForest
#' @export
`print.rdaf_gradientForest` <-
function(x,...)
{
    cat("A forest of ",x$ntree," ",x$ranForest.type," trees for each of ",x$species.pos.rsq," species\n", sep = "")
    cat("\nCall:\n", deparse(x$call), "\n\n", sep = "\n")
    cat("Important variables:\n")
    nam <- names(rdaf_importance.rdaf_gradientForest(x,sort=T))
    print.default(nam[1:min(5,length(nam))],sep=" ",quote=F)
    cat("\n")
    invisible(x)
}


.rdaf_compress_extrap <- function(x, p, a, b){

  if(!(p >= 0 & p<=1)) stop("rdaf_gradientForest prediction extrap param must be in range [0,1], got [", p,"]")
  if(!(a >= 0)) stop("rdaf_gradientForest prediction internal error: gradient 'a' must be positive. Got [", a,"]")
  if(!(all(x >= 0))) stop("rdaf_gradientForest prediction internal error: Not all 'x' are positive, but internal algorithm requires it. Got [", x,"]")

if(p == 1){
    ##linear extrapolation
    z <- a * x + b
} else if (a == 0 | p == 0){
    ##capping
    z <- b
} else {
    ##curve, x^p + b, with x and intercept shifted such that dz/dx = a at x = 0
    z <- (x + (a / p) ^ (1/(p-1)) ) ^ p + b - (a / p) ^ (p / (p-1))
}

return(z)
}



#' Predict turnover from a gradient forest
#'
#' Maps new predictor values onto the cumulative importance (turnover) scale of
#' a fitted gradient forest, one column per predictor. This is what RDAforest
#' uses to project predicted adaptation across a landscape. Vendored from
#' \pkg{gradientForest}.
#'
#' @param object an object of class \code{rdaf_gradientForest}.
#' @param newdata a data frame of predictor values. Defaults to the data the
#'   forest was fitted to.
#' @param extrap how to treat values outside the fitted range: \code{TRUE}
#'   extrapolates linearly, \code{FALSE} caps at the last fitted value,
#'   \code{NA} returns \code{NA}, and a number between 0 and 1 compresses the
#'   extrapolation by that power.
#' @param ... passed to \code{\link{rdaf_cumimp}}.
#' @return A data frame of class \code{predict.rdaf_gradientForest} with one
#'   column per predictor, on the cumulative importance scale.
#' @seealso \code{\link{rdaf_gradientForest}}, \code{\link{predict_gf}}
#' @method predict rdaf_gradientForest
#' @export
`predict.rdaf_gradientForest` <-
function (object, newdata, extrap=TRUE, ...)
{
  ## extrap can be
  ## NA - return NA's
  ## T - extrap linearly
  ## F - cap at max
  ## 0 <= x <= 1  extrapolate with power compression. T maps to 1, F maps to 0
  ## Keep test
    if (!inherits(object,"rdaf_gradientForest"))
      stop(paste("'object' must be a rdaf_gradientForest object"))
  #if it is na, ok, if it is between 0 and 1, ok, otherwise, error
  if (!(is.na(extrap) | (extrap >= 0 & extrap <= 1))){
    stop("extrap parameter must be 'NA', 'TRUE', 'FALSE', or between 0 and 1")
  }
    if (missing(newdata))
        newdata <- object$X
    if(!inherits(newdata,"data.frame"))
        stop("newdata must be a data.frame")
    newnames <- names(newdata)
    if(!all(ok <- newnames %in% as.character(levels(object$res$var)))) {
        badnames <- paste(newnames[!ok], collapse=", ")
        stop(paste("the following predictors are not in the rdaf_gradientForest:\n\t",badnames,sep=""))
    }
    #object, newdata and extrap are all acceptable
    out <-  newdata
    for (varX in newnames) {
      ##refactor

  ##Now, branch according to
  ## Number of elements in ci -
  ## NA -
  ## F,
  ## T or number
      ##Take the rdaf_cumimp over the observed range
        ci <- rdaf_cumimp(object, varX, ...)
      if(length(ci$x) == 1){
      ##If only one observation exists, assume varX is constant everywhere. The two points are used by approxfun
        if (is.na(extrap)){
          ##only newdata matching the known point are accepted
          known <- newdata[,varX] == ci$x
          out[known,varX] <- ci$y
          out[!known, varX] <- NA
        } else {
          ##only one observation, constant everywhere
          ## linear extrapolation and capping give the same result when gradient is 0,
          ##compression is bounded by linear extrapolation and capping, so will also be constant everywhere
          out[,varX] <- ci$y
        }
      } else {
        ##ci has a length > 1, so we can do extrapolation
        f <- approxfun(ci, rule = 1)
        out[,varX] <- f(newdata[,varX])
        if(!is.na(extrap)){
          ##NA case is simple, no need to extrapolate at all, just use rule = 1 in approxfun()
          ##other cases need more work
          ##refactor
          ##approxfun(rule = 2) will cap.
          ##old approach was to add a linear section to ci, then use approxfun anyway, and nothing would be outside.
          ##rather than fiddling with approxfun, caps and linear, just apply the compression function
          ##the compression function takes a gradient (which matches linear extrapolation)
          ##a compression power between 0 and 1 (given by extrap)
          ##a y offset (max(ci$y) or min(ci$y))
          ##and the distance of each x value from the known max/min
      ##get the range of x and y used in fitting
          xold <- range(ci$x)
          yold <- range(ci$y)
          if(xold[1] == xold[2]) stop(paste0("variable [", varX, "] has badly formed cumulative importance curve:\n ", ci))
          grad <- diff(yold) / diff(xold)
          ## xold_norm <- (xold - min(xold)) / max(xold - min(xold))
          grad_norm <- diff(yold)

          ##compression algorithm only works on one side at a time.
          upper_extrap <- newdata[,varX] > xold[2]
          if(length(upper_extrap) > 0){
            ## When extrapolating, normalise x st. min(xold) == 0 and max(xold) == 1

            upper_norm <- (newdata[upper_extrap, varX] - min(xold)) / (max(xold) - min(xold))

            extrap_norm <- .rdaf_compress_extrap(upper_norm - 1, as.numeric(extrap), grad_norm, yold[2])
            out[upper_extrap, varX] <- extrap_norm
          }

          lower_extrap <- newdata[,varX] < xold[1]
          if(length(lower_extrap) > 0){
            lower_norm <- (newdata[lower_extrap, varX] - min(xold)) / (max(xold) - min(xold))
            extrap_norm <- - .rdaf_compress_extrap(-lower_norm, as.numeric(extrap), grad_norm, -yold[1])
            out[lower_extrap, varX] <- extrap_norm
          }
        }
      }
      ##end the loop here
    }

    class(out) <- c("predict.rdaf_gradientForest", "data.frame")
    out
}

