## ---------------------------------------------------------------------------
## The engine behind ordinationJackknife().
##
## Each replicate fits its models, scores every environment it was given, and
## lets the models go, so the ensemble is never held in memory however many
## environments are scored, and all of them go through the same replicates.
## ---------------------------------------------------------------------------

## Validate extra.npred against the number of predictors.  Called early by
## ordinationJackknife() so that a typo is caught before the fitting, not after.
.rdaf_check_extra_npred <- function(extra.npred, np) {
  if (!is.numeric(extra.npred) || length(extra.npred) != 1 || is.na(extra.npred))
    stop("extra.npred must be a single number")
  extra.npred <- round(extra.npred)
  if (extra.npred < 0 || extra.npred > np)
    stop("extra.npred must be between 0 and the number of predictors (", np, ")")
  extra.npred
}

## Clamp newX into the range the model saw, dropping rows that reach further
## than their predictor's allowance.  `extra` applies to the first extra.npred
## predictors in the order they were supplied in X; the rest get Inf, so nothing
## is ever out of range for them and no row is dropped on their account.
.rdaf_filter_newX <- function(newX, X, extra = 0, extra.npred = ncol(X)) {
  if (is.null(newX))
    return(list(newX = X, goodrows = seq_len(nrow(X))))
  extra.npred <- .rdaf_check_extra_npred(extra.npred, ncol(X))
  extras <- stats::setNames(rep(Inf, ncol(X)), colnames(X))
  if (extra.npred > 0) extras[seq_len(extra.npred)] <- extra

  newX <- newX[, colnames(newX) %in% colnames(X)]
  ranges <- apply(X, 2, range)
  spans <- ranges[2, ] - ranges[1, ]
  ranges.s <- ranges
  ## spans * Inf would be NaN for a constant predictor, so set the unlimited
  ## ones straight to Inf
  pad <- spans * extras[colnames(ranges)]
  pad[!is.finite(extras[colnames(ranges)])] <- Inf
  ranges.s[2, ] <- ranges[2, ] + pad
  ranges.s[1, ] <- ranges[1, ] - pad
  for (v in colnames(newX)) {
    newX[, v][newX[, v] < ranges.s[1, v]] <- NA
    newX[, v][newX[, v] < ranges[1, v]] <- ranges[1, v]
    newX[, v][newX[, v] > ranges.s[2, v]] <- NA
    newX[, v][newX[, v] > ranges[2, v]] <- ranges[2, v]
  }
  goodrows <- apply(newX, 1, function(x) sum(is.na(x)) == 0)
  list(newX = newX[goodrows, ], goodrows = goodrows)
}



## The cumulative-importance (turnover) curve of every predictor in a
## gradient forest: all that turnover prediction reads.  Computed once per
## replicate and used for every environment.
.rdaf_oj_curves <- function(gf, vars)
  lapply(stats::setNames(vars, vars), function(v) rdaf_cumimp(gf, v))

## Turnover prediction from cumulative-importance curves: the body of
## predict.rdaf_gradientForest(object, newdata, extrap = TRUE), with the call
## to rdaf_cumimp() replaced by a curve computed once per replicate.
.rdaf_oj_turnover <- function(cis, newdata, extrap = TRUE) {
  out <- newdata
  for (varX in names(newdata)) {
    ci <- cis[[varX]]
    if (is.null(ci))
      stop("the following predictor is not in the fitted ensemble: ", varX)
    if (length(ci$x) == 1) {
      out[, varX] <- ci$y
    } else {
      f <- stats::approxfun(ci, rule = 1)
      out[, varX] <- f(newdata[, varX])
      xold <- range(ci$x)
      yold <- range(ci$y)
      if (xold[1] == xold[2])
        stop(paste0("variable [", varX, "] has badly formed cumulative importance curve:\n ", ci))
      grad_norm <- diff(yold)
      upper_extrap <- newdata[, varX] > xold[2]
      if (length(upper_extrap) > 0) {
        upper_norm <- (newdata[upper_extrap, varX] - min(xold)) / (max(xold) - min(xold))
        out[upper_extrap, varX] <- .rdaf_compress_extrap(upper_norm - 1, as.numeric(extrap), grad_norm, yold[2])
      }
      lower_extrap <- newdata[, varX] < xold[1]
      if (length(lower_extrap) > 0) {
        lower_norm <- (newdata[lower_extrap, varX] - min(xold)) / (max(xold) - min(xold))
        out[lower_extrap, varX] <- -.rdaf_compress_extrap(-lower_norm, as.numeric(extrap), grad_norm, -yold[1])
      }
    }
  }
  class(out) <- c("predict.rdaf_gradientForest", "data.frame")
  out
}

## Score one replicate's models on one environment.
.rdaf_oj_predict_one <- function(rf, curves, newX) {
  Yp <- list()
  for (j in seq_along(rf)) {
    message("predicting mds ", j)
    Yp[[j]] <- predict(rf[[j]], newX)
  }
  message("predicting turnover")
  list(d = data.frame(do.call(cbind, Yp)), t = .rdaf_oj_turnover(curves, newX))
}

## A token identifying one run's ensemble, carried by every prediction set it
## produced, so that gen_offset_oj() can tell whether two prediction sets came
## from the same replicates.  tempfile() gives a unique string without
## touching the random number stream.
.rdaf_fit_id <- function()
  paste0("oj.", format(Sys.time(), "%Y%m%d%H%M%S"), ".",
         sub("^file", "", basename(tempfile(pattern = "file"))))

## Rescale the averaged turnover curves and put the return value together.
.rdaf_oj_assemble <- function(pred.d, pred.t, fit, goodrows) {
  importances <- fit$median.importance
  for (m in colnames(pred.t))
    pred.t[, m] <- decostand(pred.t[, m], method = "range") * importances[m]
  list(sum.importances = fit$sum.importances, predictions.direct = pred.d,
       predictions.turnover = pred.t, median.importance = importances,
       all.importances = fit$all.importances, goodrows = goodrows,
       failed.reps = fit$failed.reps, ensemble.id = fit$ensemble.id)
}

## Run the jackknife.  `newXs` is a list of environments already filtered by
## .rdaf_filter_newX(); the result holds, for each of them, the direct and
## turnover predictions averaged over the successful replicates, plus the
## importances.  The random number stream is consumed exactly as in earlier
## versions of ordinationJackknife().
.rdaf_oj_run=function(Y,X,newXs,oob=0.2,covariates=NULL,nreps=25,top.pcs=15,rescale2npcs=FALSE,mtry=NULL,ntrees=1500,sites=NULL,site.repeats="genetic.median",explicit=FALSE,block.holdout=1/3,coords=NULL,auto.sites=TRUE,ncores=1) {
  ncores=.rdaf_check_ncores(ncores,nreps)
  # resolve and validate the site.repeats setting up front, once only
  .res=.rdaf_resolve_sites(X,sites,site.repeats,coords,auto.sites,explicit)
  sites=.res$sites; site.repeats=.res$site.repeats
  srep=.rdaf_check_site_repeats(sites,nrow(X),site.repeats,block.holdout)
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  if(rescale2npcs==TRUE){rescale2npcs=top.pcs } else {rescale2npcs=NULL }
  # setting mtry to N/3 or 2 (note: the default is N/3 or 1)
  if (is.null(mtry)){ mt=max(floor(ncol(X)/3),2) } else { mt=mtry }
  failed.reps=0;v.order=NULL
  # site handling for the direct-prediction forests, as in predict_rf()
  fit.sites=if(srep$mode=="blocked.resampling") srep$factor else NULL
  imps=c();replicate=c();impsum=c();n.models=0
  ng=length(newXs); sum.d=vector("list",ng); sum.t=vector("list",ng)

  ords.full=.rdaf_ord_full(Y,covariates)
  sc.full=scores(ords.full,scaling=1,display="sites",choices=c(1:length(ords.full$CA$eig)))

  # one replicate: fit, score every environment, return the predictions and
  # importances; the models go out of scope here.  It may run in a worker
  # process (ncores > 1), so it only reads from this frame.
  one.rep=function(i){
    message("\nreplicate ",i)
    ib.keep=sample(1:nrow(Y),round(nrow(Y)*(1-oob)))
    oo=.rdaf_ord_rep(Y,ib.keep,covariates); ords0=oo$ords0; ords=oo$ords
    # align projected ordinaton with full-model scores
    orr=data.frame(procrustes(sc.full,ords,scale = T)$Yrot)
    names(orr)[1:top.pcs]=colnames(sc.full)[1:top.pcs]
    gf1=makeGF_simple(orr[,1:top.pcs],X,ntrees=ntrees,mtry=mt,sites=sites,site.repeats=site.repeats,block.holdout=block.holdout,auto.sites=FALSE)
    if(is.null(gf1)) {
      message("   ... nothing is predictable. Moving to next rep")
      return(list(failed=TRUE))
    }
    # direct-prediction forests, fitted exactly as predict_rf() fits them
    Yf=orr[,1:top.pcs]; Xf=X
    if(srep$mode=="genetic.median"){
      coll=.rdaf_collapse_sites(X,Yf,srep$factor)
      Xf=coll$X; Yf=coll$Y
    }
    rf=list()
    for(j in 1:ncol(Yf)){
      pc=Yf[,j]
      rf[[j]]=rdaf_randomForest(x=Xf,y=pc,sites=fit.sites,site.repeats="blocked.resampling",block.holdout=block.holdout,auto.sites=FALSE,ntree=ntrees,mtry=mt)
    }
    # variable order is taken from the first successful replicate, so every
    # replicate reports it and the caller keeps the first
    vnames=names(importance_RDAforest(gf1,ords0))
    ii=importance_RDAforest(gf1,ords0,rescale2npcs=rescale2npcs)
    curves=.rdaf_oj_curves(gf1,colnames(X))
    preds=lapply(newXs,function(nx) .rdaf_oj_predict_one(rf,curves,nx))
    list(failed=FALSE,preds=preds,vnames=vnames,ii=ii)
  }
  # gather the replicates in order, as they come back, summing predictions
  collect=function(i,r){
    if(r$failed) { failed.reps<<-failed.reps+1; return(invisible()) }
    if(is.null(v.order)) { v.order<<-r$vnames }
    for(g in seq_len(ng)){
      p=r$preds[[g]]
      if(n.models==0){ sum.d[[g]]<<-p$d; sum.t[[g]]<<-p$t }
      else { sum.d[[g]]<<-sum.d[[g]]+p$d; sum.t[[g]]<<-sum.t[[g]]+p$t }
    }
    n.models<<-n.models+1
    ii=r$ii[v.order]
    imps<<-c(imps,ii)
    replicate<<-c(replicate,rep(i,length(v.order)))
    impsum<<-c(impsum,sum(ii))
  }
  # replicates are dispatched ncores at a time and summed as they arrive, so
  # memory stays bounded by one batch
  .rdaf_run_reps(nreps,one.rep,collect,ncores,batch=ncores)
  if(!n.models) { stop("every replicate failed: nothing is predictable") }

  # computing median importances of variables
  dimps=data.frame(imps)
  dimps$replicate=replicate
  dimps$variable=names(imps)
  names(dimps)[1]="importance"
  meds=dimps%>%
    group_by(variable)%>%
    summarise(median(importance))
  meds=as.data.frame(meds)
  importances=meds$`median(importance)`
  names(importances)=meds$variable

  # releveling variables according to median importance
  varorder=meds$variable[order(meds[,2],decreasing=T)]
  importances=importances[varorder]
  dimps$variable=factor(dimps$variable,levels=rev(varorder))
  list(pred=lapply(seq_len(ng),function(g) list(d=sum.d[[g]]/n.models,t=sum.t[[g]]/n.models)),
       n.models=n.models,ensemble.id=.rdaf_fit_id(),
       sum.importances=impsum,median.importance=importances,
       all.importances=dimps,failed.reps=failed.reps)
}
