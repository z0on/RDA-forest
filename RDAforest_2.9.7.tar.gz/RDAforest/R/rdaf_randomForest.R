## ---------------------------------------------------------------------------
## Vendored from extendedForest 1.6.2.1.
##
## Original authors: Fortran original by Leo Breiman and Adele Cutler; R port by Andy Liaw and
##   Matthew Wiener; split-improvement modifications by Nick Ellis
## Licence: GPL (>= 2).
##
## Incorporated into RDAforest so that the package is self-contained and so
## that the random forest engine could be extended with blocked (grouped)
## out-of-bag sampling.  Every function has been renamed with an `rdaf_`
## prefix; apart from that, and the changes noted inline, the code is the
## original.
## ---------------------------------------------------------------------------


#' Random forest, with optional handling of repeated samples per site
#'
#' Classification and regression with Breiman and Cutler's random forests, as
#' implemented in \pkg{extendedForest}: the \pkg{randomForest} algorithm plus
#' Nick Ellis' node-level split-improvement bookkeeping, which is what
#' \code{\link{rdaf_gradientForest}} turns into turnover curves. The code is
#' incorporated into RDAforest and renamed so that it does not mask
#' \code{extendedForest::randomForest}; with the same random seed and
#' \code{sites = NULL} it reproduces that function exactly.
#'
#' The addition is \code{sites} and \code{site.repeats}. Ordinarily each tree is
#' grown on a bootstrap sample of rows and scored on the rows it missed, which
#' assumes the rows are independent. When several individuals are sampled at the
#' same site they share exactly the same predictor values, that assumption
#' fails, and out-of-bag \eqn{R^2} and permutation importance come out
#' optimistic: a predictor that merely labels an unusual site looks like a
#' driver. \code{site.repeats} says what to do about it.
#'
#' \describe{
#'   \item{\code{"genetic.median"} (the default)}{Collapse each site to a single
#'     synthetic individual placed at the geometric median of its members, so
#'     the forest is fitted on one row per site. Called on
#'     \code{rdaf_randomForest} directly there is only one response, and the
#'     geometric median of a set of numbers is the ordinary median; the
#'     multidimensional version, computed across all supplied principal
#'     coordinates at once by Weiszfeld's iteration, is what
#'     \code{\link{makeGF}}, \code{\link{ordinationJackknife}} and
#'     \code{\link{predict_rf}} apply before they reach this function. See
#'     \code{\link{genetic_medians}}.}
#'   \item{\code{"blocked.resampling"}}{Keep every individual, but make the site
#'     the unit of hold-out: each tree withholds a random \code{block.holdout}
#'     fraction of whole sites, then draws its training sample from the rows of
#'     the sites that remain, in the ordinary way (with replacement by default,
#'     so roughly \eqn{1 - 1/e} of the eligible rows are drawn, honouring
#'     \code{replace} and \code{sampsize}, the latter scaled to the size of the
#'     pool). The out-of-bag set is the withheld sites and nothing else: a
#'     retained row that the draw happened to miss is not scored, because its
#'     site-mates are in the training sample. Because sites differ in size, the
#'     pool, and so the number of rows drawn, varies from tree to tree. Nothing
#'     else about the algorithm changes.}
#'   \item{\code{"direct.use"}}{Ignore the site structure and fit on the
#'     individuals as they are, which is the ordinary random forest and what
#'     earlier versions of RDAforest did.}
#' }
#'
#' @param x a data frame or matrix of predictors.
#' @param y response vector. A factor gives classification, numeric gives
#'   regression; \code{NULL} gives an unsupervised forest (not compatible with
#'   \code{sites}).
#' @param xtest,ytest optional test set of predictors and responses.
#' @param ntree number of trees to grow.
#' @param mtry number of predictors sampled as candidates at each split.
#' @param replace whether to draw the training sample with replacement. Under
#'   \code{"blocked.resampling"} the draw is made from the rows of the retained
#'   sites, but is otherwise unchanged.
#' @param classwt priors of the classes.
#' @param cutoff for classification, the vote fractions that decide the winning
#'   class.
#' @param strata a factor used for stratified sampling.
#' @param sampsize size of the sample to draw. Under
#'   \code{"blocked.resampling"} it is scaled to the size of the eligible pool,
#'   so the default still means "as many draws as there are eligible rows".
#' @param nodesize minimum size of terminal nodes.
#' @param importance whether to assess predictor importance by permutation.
#' @param localImp whether to compute casewise importance.
#' @param nPerm number of permutations per tree for the importance measure.
#' @param proximity whether to accumulate the proximity matrix.
#' @param oob.prox whether proximity is computed on out-of-bag samples only.
#' @param norm.votes whether class votes are returned as fractions.
#' @param do.trace if positive, report progress every \code{do.trace} trees.
#' @param keep.forest whether to retain the forest for prediction.
#' @param corr.bias whether to apply regression bias correction.
#' @param keep.inbag whether to return the in-bag matrix. Set this to
#'   \code{TRUE} to check that blocked resampling did what you expected.
#' @param maxLevel depth at which conditional permutation of correlated
#'   predictors kicks in (\pkg{extendedForest} extension); 0 turns it off.
#' @param keep.group whether to retain the conditional permutation groups.
#' @param corr.threshold correlation above which predictors are permuted
#'   conditionally on one another.
#' @param corr.method correlation method passed to \code{\link[stats]{cor}}.
#' @param sites optional categorical vector giving the site membership of each
#'   sample, one entry per row of \code{x} (a factor, character, integer or
#'   numeric vector). Supply it when several individuals were sampled at the
#'   same site, reef, population, family, sequencing batch or year, so that
#'   they share predictor values. \code{NULL} (the default) means no repeated
#'   sampling and gives the ordinary random forest. \code{site.repeats} decides
#'   what is done with it; see \code{\link{site_repeats_summary}}.
#' @param site.repeats how repeated samples within a site are handled, one of
#'   \code{"genetic.median"} (the default), \code{"blocked.resampling"} or
#'   \code{"direct.use"}. Ignored when \code{sites} is \code{NULL}. See
#'   Details.
#' @param block.holdout fraction of sites withheld from each tree under
#'   \code{site.repeats = "blocked.resampling"} (default \code{1/3}). It is
#'   rounded to a whole number of sites, clamped to at least one site and at
#'   most all but one; a warning is issued if the rounding changes the fraction.
#' @param coords optional coordinates used when detecting repeated sampling
#'   automatically: either the names of the coordinate columns of \code{x}, or
#'   a separate two-column object with one row per sample. \code{NULL} looks
#'   for coordinate columns by name. Ignored when \code{sites} is supplied.
#' @param auto.sites whether to look for repeated sampling when \code{sites} is
#'   not supplied (default \code{TRUE}). Samples that share a location and all
#'   their environmental values are taken to be one site, and are then handled
#'   according to \code{site.repeats}, with a message saying which mode was
#'   used; if \code{site.repeats} was left at its default that is
#'   \code{"genetic.median"}, but naming a mode overrides it. Samples that share
#'   a location but disagree on the environment draw a warning and are used
#'   directly; data with no shared locations are used directly and silently. See
#'   \code{\link{detect_sites}}. Set \code{FALSE} to switch the check off.
#' @param oob.blocks deprecated; use \code{sites} with
#'   \code{site.repeats = "blocked.resampling"}.
#' @param oob.block.holdout deprecated; use \code{block.holdout}.
#' @param formula a model formula, for the formula method.
#' @param data data frame in which to interpret \code{formula}.
#' @param subset optional subset of rows.
#' @param na.action how to handle missing values.
#' @param ... arguments passed between methods.
#' @return An object of class \code{rdaf_randomForest}: a list with the usual
#'   \code{randomForest} components (\code{predicted}, \code{mse},
#'   \code{rsq}, \code{importance}, \code{forest}, \code{inbag} and so on).
#'   When \code{sites} was supplied it also carries \code{sites} and
#'   \code{site.repeats}, and under blocked resampling \code{block.holdout} and
#'   \code{sites.withheld} (the number of sites actually held out per tree).
#' @seealso \code{\link{rdaf_gradientForest}}, \code{\link{rdaf_importance}},
#'   \code{\link{site_repeats_summary}}, \code{\link{genetic_medians}},
#'   \code{\link{predict.rdaf_randomForest}}
#' @references Breiman L. (2001) Random forests. \emph{Machine Learning}
#'   45: 5-32.
#' @examples
#' set.seed(1)
#' x <- data.frame(a = rnorm(60), b = rnorm(60), c = rnorm(60))
#' y <- 2 * x$a + rnorm(60)
#' site <- rep(paste0("site", 1:6), each = 10)
#'
#' ## no repeated sampling: the ordinary random forest
#' rf <- rdaf_randomForest(x = x, y = y, ntree = 200, importance = TRUE)
#'
#' ## six sites of ten samples; each tree withholds two whole sites
#' rfb <- rdaf_randomForest(x = x, y = y, ntree = 200, importance = TRUE,
#'                          sites = site, site.repeats = "blocked.resampling",
#'                          block.holdout = 1/3, keep.inbag = TRUE)
#' ## no drawn row ever comes from a withheld site: two of the six sites
#' ## contribute nothing to the first tree
#' sum(tapply(rfb$inbag[, 1], site, max) == 0)
#' ## and within the four retained sites the draw is the usual bootstrap
#' mean(colSums(rfb$inbag)) / 40
#' @export
"rdaf_randomForest" <-
function(x, ...)
  UseMethod("rdaf_randomForest")


## .rdaf_mylevels() returns levels if given a factor, otherwise 0.
.rdaf_mylevels <- function(x) if (is.factor(x)) levels(x) else 0


#' @rdname rdaf_randomForest
#' @method rdaf_randomForest default
#' @export
"rdaf_randomForest.default" <-
    function(x, y=NULL,  xtest=NULL, ytest=NULL, ntree=500,
             mtry=if (!is.null(y) && !is.factor(y)) 
             max(floor(ncol(x)/3), 1) else floor(sqrt(ncol(x))),
             replace=TRUE, classwt=NULL, cutoff, strata,
             sampsize = if (replace) nrow(x) else ceiling(.632*nrow(x)),
             nodesize = if (!is.null(y) && !is.factor(y)) 5 else 1, 
             importance=FALSE, localImp=FALSE, nPerm=1,
             proximity, oob.prox=proximity,
             norm.votes=TRUE, do.trace=FALSE,
             keep.forest=!is.null(y) && is.null(xtest), corr.bias=FALSE,
             keep.inbag=FALSE, maxLevel=0, keep.group=FALSE,
             corr.threshold=1, corr.method="pearson",
             sites=NULL, site.repeats=c("genetic.median",
             "blocked.resampling", "direct.use"), block.holdout=1/3,
             coords=NULL, auto.sites=TRUE,
             oob.blocks=NULL, oob.block.holdout=NULL, ...) {

    ## --- repeated samples within sites (RDAforest addition) ----------------
    ## `sites` assigns every row of `x` to a site and `site.repeats` says what
    ## to do about the repeats.
    ##   "genetic.median"     collapse each site to one synthetic row before
    ##                        anything else happens.  With the single response
    ##                        this function takes, the geometric median is the
    ##                        ordinary median; the multidimensional version,
    ##                        across all principal coordinates at once, is
    ##                        applied by the callers (makeGF, predict_rf, ...).
    ##   "blocked.resampling" keep every row, but make whole sites the unit of
    ##                        hold-out: each tree withholds a random
    ##                        `block.holdout` fraction of the sites and draws
    ##                        its training sample from the rows of the sites
    ##                        that remain.  The draw itself is the ordinary
    ##                        one, with replacement by default, and `sampsize`
    ##                        is scaled to the size of the pool.
    ##   "direct.use"         ignore the site structure entirely.
    ## did the caller name a mode of their own?  Must be asked before anything
    ## reassigns `site.repeats`.
    .explicit <- !missing(site.repeats)
    dep <- .rdaf_deprecate_oob_blocks(sites, site.repeats, block.holdout,
                                      oob.blocks, oob.block.holdout)
    sites <- dep$sites
    site.repeats <- dep$site.repeats
    block.holdout <- dep$block.holdout
    ## With no `sites` given, look for repeated sampling in the predictors
    ## themselves; see detect_sites().
    res <- .rdaf_resolve_sites(x, sites, site.repeats, coords, auto.sites,
                               .explicit)
    sites <- res$sites
    site.repeats <- res$site.repeats
    srep <- .rdaf_check_site_repeats(sites, nrow(x), site.repeats,
                                     block.holdout)
    if (srep$mode != "none" && is.null(y))
        stop("sites cannot be used with unsupervised random forests")
    if (srep$mode == "genetic.median") {
        if (is.factor(y))
            stop("site.repeats = \"genetic.median\" needs a numeric response; ",
                 "use \"blocked.resampling\" or \"direct.use\" for classification")
        if (!is.null(xtest))
            stop("site.repeats = \"genetic.median\" cannot be combined with xtest")
        was.matrix <- is.matrix(x)
        coll <- .rdaf_collapse_sites(x, data.frame(y = y), srep$factor)
        x <- if (was.matrix) as.matrix(coll$X) else coll$X
        y <- coll$Y$y
    }
    blocks <- srep$blocks
    ## ----------------------------------------------------------------------

    addclass <- is.null(y)
    classRF <- addclass || is.factor(y)
    if (!classRF && length(unique(y)) <= 5) {
        warning("The response has five or fewer unique values.  Are you sure you want to do regression?")
    }
    if (classRF && !addclass && length(unique(y)) < 2) 
        stop("Need at least two classes to do classification.")
    n <- nrow(x)
    p <- ncol(x)
    if (n == 0) stop("data (x) has 0 rows")

    x.row.names <- rownames(x)
    x.col.names <- if (is.null(colnames(x))) 1:ncol(x) else colnames(x)

    ## overcome R's lazy evaluation:
    keep.forest <- keep.forest
    
    testdat <- !is.null(xtest)
    if (testdat) {
        if (ncol(x) != ncol(xtest))
            stop("x and xtest must have same number of columns") 
        ntest <- nrow(xtest)
        xts.row.names <- rownames(xtest)
    }

    ## Make sure mtry is in reasonable range.
    if (mtry < 1 || mtry > p)
        stop("invalid mtry: reset to within valid range")
    mtry <- max(1, min(p, round(mtry)))
    if (!is.null(y)) {
        if (length(y) != n) stop("length of response must be the same as predictors")
        addclass <- FALSE
    } else {
        if (!addclass) addclass <- TRUE
        y <- factor(c(rep(1, n), rep(2, n)))
        x <- rbind(x, x)
    }

    ## Check for NAs.
    if (any(is.na(x))) stop("NA not permitted in predictors")
    if (testdat && any(is.na(xtest))) stop("NA not permitted in xtest")
    if (any(is.na(y))) stop("NA not permitted in response")
    if (!is.null(ytest) && any(is.na(ytest))) stop("NA not permitted in ytest")

    if (is.data.frame(x)) {
        # measure correlation between numeric and ordered factors
        xc <- as.data.frame(lapply(x, function(y) if(is.numeric(y)) y else 
          if(is.ordered(y)) as.numeric(y) else rep(NA,length(y))))
        corr <- cor(xc, method=corr.method)
        corr[is.na(corr)] <- 0
        xlevels <- lapply(x, .rdaf_mylevels)
        ncat <- sapply(xlevels, length)
        ## Treat ordered factors as numerics.
        ncat <- ifelse(sapply(x, is.ordered), 1, ncat)
        x <- data.matrix(x)
        if(testdat) {
            if(!is.data.frame(xtest))
                stop("xtest must be data frame if x is")
            xfactor <- which(sapply(xtest, is.factor))
            if (length(xfactor) > 0) {
                for (i in xfactor) {
                    if (any(! levels(xtest[[i]]) %in% xlevels[[i]]))
                        stop("New factor levels in xtest not present in x")
                    xtest[[i]] <-
                        factor(xlevels[[i]][match(xtest[[i]], xlevels[[i]])],
                               levels=xlevels[[i]])
                }
            }
            xtest <- data.matrix(xtest)
        }
    } else {
        corr <- cor(x, method=corr.method)
        ncat <- rep(1, p)
        xlevels <- as.list(rep(0, p))
    }
    maxcat <- max(ncat)
    if (maxcat > 32)
        stop("Can not handle categorical predictors with more than 32 categories.")
    
    if (classRF) {
        nclass <- length(levels(y))
        ## Check for empty classes:
        if (any(table(y) == 0)) stop("Can't have empty classes in y.")
        if (!is.null(ytest)) {
            if (!is.factor(ytest)) stop("ytest must be a factor")
            if (!all(levels(y) == levels(ytest)))
                stop("y and ytest must have the same levels")
        }
        if (missing(cutoff)) {
            cutoff <- rep(1 / nclass, nclass)
        } else {
            if (sum(cutoff) > 1 || sum(cutoff) < 0 || !all(cutoff > 0) ||
                length(cutoff) != nclass) {
                stop("Incorrect cutoff specified.")
            }
            if (!is.null(names(cutoff))) {
                if (!all(names(cutoff) %in% levels(y))) {
                    stop("Wrong name(s) for cutoff")
                }
                cutoff <- cutoff[levels(y)]
            }
        }
        if (!is.null(classwt)) {
            if (length(classwt) != nclass)
                stop("length of classwt not equal to number of classes")
            ## If classwt has names, match to class labels.
            if (!is.null(names(classwt))) {
                if (!all(names(classwt) %in% levels(y))) {
                    stop("Wrong name(s) for classwt")
                }
                classwt <- classwt[levels(y)]
            }
            if (any(classwt <= 0)) stop("classwt must be positive")
            ipi <- 1
        } else {
            classwt <- rep(1, nclass)
            ipi <- 0
        }
    } else addclass <- FALSE  

    if (missing(proximity)) proximity <- addclass
    if (proximity) {
        prox <- matrix(0.0, n, n)
        proxts <- if (testdat) matrix(0, ntest, ntest + n) else double(1)
    } else {
        prox <- proxts <- double(1)
    }

    if (localImp) {
        importance <- TRUE
        impmat <- matrix(0, p, n)
    } else impmat <- double(1)
    
    if (importance) {
        if (nPerm < 1) nPerm <- as.integer(1) else nPerm <- as.integer(nPerm)
        if (classRF) {
            impout <- matrix(0.0, p, nclass + 2)
            impSD <- matrix(0.0, p, nclass + 1)
        } else {
            impout <- matrix(0.0, p, 2)
            impSD <- double(p)
            names(impSD) <- x.col.names
        }
    } else {
        impout <- double(p)
        impSD <- double(1)
    }
    
    nsample <- if (addclass) 2 * n else n
    Stratify <- length(sampsize) > 1
    if ((!Stratify) && sampsize > nrow(x)) stop("sampsize too large")
    if (Stratify && (!classRF)) stop("sampsize should be of length one")
    if (classRF) {
        if (Stratify) {
            if (missing(strata)) strata <- y
            if (!is.factor(strata)) strata <- as.factor(strata)
            nsum <- sum(sampsize)
            if (length(sampsize) > nlevels(strata))
                stop("sampsize has too many elements.")
            if (any(sampsize <= 0) || nsum == 0)
                stop("Bad sampsize specification")
            ## If sampsize has names, match to class labels.
            if (!is.null(names(sampsize))) {
                sampsize <- sampsize[levels(strata)]
            }
            if (any(sampsize > table(strata)))
              stop("sampsize can not be larger than class frequency")
        } else {
            nsum <- sampsize
        }
        nrnodes <- 2 * trunc(nsum / nodesize) + 1
    } else {
        ## For regression trees, need to do this to get maximal trees.
        nrnodes <- 2 * trunc(sampsize/max(1, nodesize - 4)) + 1
    }
    
    ## Compiled code expects variables in rows and observations in columns.
    x <- t(x)
    storage.mode(x) <- "double"
    if (testdat) {
        xtest <- t(xtest)
        storage.mode(xtest) <- "double"
        if (is.null(ytest)) {
            ytest <- labelts <- 0
        } else {
            labelts <- TRUE
        }
    } else {
        xtest <- double(1)
        ytest <- double(1)
        ntest <- 1
        labelts <- FALSE
    }
    nt <- if (keep.forest) ntree else 1

    if (classRF) {
        error.test <- if (labelts) double((nclass+1) * ntree) else double(1)
        rfout <- .C("classRF",
                    x = x,
                    xdim = as.integer(c(p, n)),
                    y = as.integer(y),
                    nclass = as.integer(nclass),
                    ncat = as.integer(ncat), 
                    maxcat = as.integer(maxcat),
                    sampsize = as.integer(sampsize),
                    strata = if (Stratify) as.integer(strata) else integer(1),
                    Options = as.integer(c(addclass,
                    importance,
                    localImp,
                    proximity,
                    oob.prox,
                    do.trace,
                    keep.forest,
                    replace,
                    Stratify,
                    keep.inbag,
                    keep.group)),
                    ntree = as.integer(ntree),
                    mtry = as.integer(mtry),
                    ipi = as.integer(ipi),
                    classwt = as.double(classwt),
                    cutoff = as.double(cutoff),
                    nodesize = as.integer(nodesize),
                    outcl = integer(nsample),
                    counttr = integer(nclass * nsample),
                    prox = prox,
                    impout = impout,
                    impSD = impSD,
                    impmat = impmat,
                    nrnodes = as.integer(nrnodes),
                    ndbigtree = integer(ntree),
                    nodestatus = integer(nt * nrnodes),
                    bestvar = integer(nt * nrnodes),
                    treemap = integer(nt * 2 * nrnodes),
                    nodepred = integer(nt * nrnodes),
                    xbestsplit = double(nt * nrnodes),
                    errtr = double((nclass+1) * ntree),
                    testdat = as.integer(testdat),
                    xts = as.double(xtest),
                    clts = as.integer(ytest),
                    nts = as.integer(ntest),
                    countts = double(nclass * ntest),
                    outclts = as.integer(numeric(ntest)),
                    labelts = as.integer(labelts),
                    proxts = proxts,
                    errts = error.test,
                    inbag = if (keep.inbag) 
                    matrix(integer(n * ntree), n) else integer(n),
                    nodeImprove = double(nt * nrnodes),
                    as.integer(maxLevel),
                    group = if (keep.group)
                    matrix(integer(n * p), n) else integer(1),
                    permX = if (keep.group)
                    matrix(double(n * p), n) else double(1),
                    as.integer(abs(corr) > corr.threshold),
                    oobBlocks = as.integer(blocks$index),
                    nOobBlocks = as.integer(blocks$n),
                    oobBlockHoldout = as.double(blocks$holdout),
                    PACKAGE="RDAforest")[-1]
        if (keep.forest) {
            ## deal with the random forest outputs
            max.nodes <- max(rfout$ndbigtree)
            treemap <- aperm(array(rfout$treemap, dim = c(2, nrnodes, ntree)),
                             c(2, 1, 3))[1:max.nodes, , , drop=FALSE]
        }
        if (!addclass) {
            ## Turn the predicted class into a factor like y.
            out.class <- factor(rfout$outcl, levels=1:nclass,
                                labels=levels(y))
            names(out.class) <- x.row.names
            con <- table(observed = y,
                         predicted = out.class)[levels(y), levels(y)]
            con <- cbind(con, class.error = 1 - diag(con)/rowSums(con))
        }
        out.votes <- t(matrix(rfout$counttr, nclass, nsample))[1:n, ]
        oob.times <- rowSums(out.votes)
        if(norm.votes) 
            out.votes <- t(apply(out.votes, 1, function(x) x/sum(x)))
        dimnames(out.votes) <- list(x.row.names, levels(y))
        if(testdat) {
            out.class.ts <- factor(rfout$outclts, levels=1:nclass,
                                   labels=levels(y))
            names(out.class.ts) <- xts.row.names
            out.votes.ts <- t(matrix(rfout$countts, nclass, ntest))
            dimnames(out.votes.ts) <- list(xts.row.names, levels(y))
            if (norm.votes)
                out.votes.ts <- t(apply(out.votes.ts, 1,
                                        function(x) x/sum(x)))
            if (labelts) {
                testcon <- table(observed = ytest,
                                 predicted = out.class.ts)[levels(y), levels(y)]
                testcon <- cbind(testcon,
                                 class.error = 1 - diag(testcon)/rowSums(testcon))
            }
        }
        cl <- match.call()
        cl[[1]] <- as.name("rdaf_randomForest")
        out <- list(call = cl,
                    type = if (addclass) "unsupervised" else "classification",
                    predicted = if (addclass) NULL else out.class,
                    err.rate = if (addclass) NULL else t(matrix(rfout$errtr,
                    nclass+1, ntree,
                    dimnames=list(c("OOB", levels(y)), NULL))),
                    confusion = if (addclass) NULL else con,
                    votes = out.votes,
                    oob.times = oob.times,
                    classes = levels(y),
                    importance = if (importance) 
                    matrix(rfout$impout, p, nclass+2,
                           dimnames = list(x.col.names,
                           c(levels(y), "MeanDecreaseAccuracy",
                             "MeanDecreaseGini")))
                    else matrix(rfout$impout, ncol=1,
                                dimnames=list(x.col.names, "MeanDecreaseGini")),
                    importanceSD = if (importance)
                    matrix(rfout$impSD, p, nclass + 1,
                           dimnames = list(x.col.names,
                           c(levels(y), "MeanDecreaseAccuracy")))
                    else NULL,
                    localImportance = if (localImp)
                    matrix(rfout$impmat, p, n,
                           dimnames = list(x.col.names,x.row.names)) else NULL,
                    proximity = if (proximity) matrix(rfout$prox, n, n,
                    dimnames = list(x.row.names, x.row.names)) else NULL,
                    ntree = ntree,
                    mtry = mtry,
                    forest = if (!keep.forest) NULL else {
                        list(ndbigtree = rfout$ndbigtree, 
                             nodestatus = matrix(rfout$nodestatus,
                             ncol = ntree)[1:max.nodes,, drop=FALSE],
                             bestvar = matrix(rfout$bestvar, ncol = ntree)[1:max.nodes,, drop=FALSE],
                             treemap = treemap,
                             nodepred = matrix(rfout$nodepred,
                             ncol = ntree)[1:max.nodes,, drop=FALSE],
                             xbestsplit = matrix(rfout$xbestsplit,
                             ncol = ntree)[1:max.nodes,, drop=FALSE],
                             pid = rfout$classwt, cutoff=cutoff, ncat=ncat,
                             maxcat = maxcat, 
                             nrnodes = max.nodes, ntree = ntree,
                             nclass = nclass, xlevels=xlevels,
                             nodeImprove = matrix(rfout$nodeImprove,
                             ncol = ntree)[1:max.nodes,, drop=FALSE])
                    },
                    y = if (addclass) NULL else y,
                    test = if(!testdat) NULL else list(
                    predicted = out.class.ts,
                    err.rate = if (labelts) t(matrix(rfout$errts, nclass+1,
                    ntree,
                dimnames=list(c("Test", levels(y)), NULL))) else NULL,
                    confusion = if (labelts) testcon else NULL,
                    votes = out.votes.ts,
                    proximity = if(proximity) matrix(rfout$proxts, nrow=ntest,
                    dimnames = list(xts.row.names, c(xts.row.names,
                    x.row.names))) else NULL),
                    inbag = if (keep.inbag) rfout$inbag else NULL,
                    group = if (keep.group)
                    matrix(rfout$group, nrow(rfout$group),
                           dimnames=list(x.row.names, x.col.names)) else NULL,
                    permX = if (keep.group)
                    matrix(rfout$permX, nrow(rfout$permX),
                           dimnames=list(x.row.names, x.col.names)) else NULL)
    } else {
        rfout <- .C("regRF",
                    x,
                    as.double(y),
                    as.integer(c(n, p)),
                    as.integer(sampsize),
                    as.integer(nodesize),
                    as.integer(nrnodes),
                    as.integer(ntree),
                    as.integer(mtry),
                    as.integer(c(importance, localImp, nPerm)),
                    as.integer(ncat),
                    as.integer(maxcat),
                    as.integer(do.trace),
                    as.integer(proximity),
                    as.integer(oob.prox),
                    as.integer(corr.bias),
                    ypred = double(n),
                    impout = impout,
                    impmat = impmat,
                    impSD = impSD,
                    prox = prox,
                    ndbigtree = integer(ntree),
                    nodestatus = matrix(integer(nrnodes * nt), ncol=nt),
                    leftDaughter = matrix(integer(nrnodes * nt), ncol=nt),
                    rightDaughter = matrix(integer(nrnodes * nt), ncol=nt),
                    nodepred = matrix(double(nrnodes * nt), ncol=nt),
                    bestvar = matrix(integer(nrnodes * nt), ncol=nt),
                    xbestsplit = matrix(double(nrnodes * nt), ncol=nt),
                    mse = double(ntree),
                    keep = as.integer(c(keep.forest, keep.inbag, keep.group)),
                    replace = as.integer(replace),
                    testdat = as.integer(testdat),
                    xts = xtest,
                    ntest = as.integer(ntest),
                    yts = as.double(ytest),
                    labelts = as.integer(labelts),
                    ytestpred = double(ntest),
                    proxts = proxts,
                    msets = double(if (labelts) ntree else 1),
                    coef = double(2),
                    oob.times = integer(n),
                    inbag = if (keep.inbag) 
                    matrix(integer(n * ntree), n) else integer(1),
                    nodeSS = matrix(double(nrnodes * nt), ncol=nt),
                    nodeImprove = matrix(double(nrnodes * nt), ncol=nt),
                    as.integer(maxLevel),
                    group = if (keep.group)
                    matrix(integer(n * p), n) else integer(1),
                    permX = if (keep.group)
                    matrix(double(n * p), n) else double(1),
                    as.integer(abs(corr) > corr.threshold),
                    as.integer(blocks$index),
                    as.integer(blocks$n),
                    as.double(blocks$holdout),
                    PACKAGE="RDAforest")[c(16:28, 36:43, 45:46)]
        ## Format the forest component, if present.
        if (keep.forest) {
            max.nodes <- max(rfout$ndbigtree)
            rfout$nodestatus <-
                rfout$nodestatus[1:max.nodes, , drop=FALSE]
            rfout$bestvar <-
                rfout$bestvar[1:max.nodes, , drop=FALSE]
            rfout$nodepred <-
                rfout$nodepred[1:max.nodes, , drop=FALSE]
            rfout$nodeSS <-
                rfout$nodeSS[1:max.nodes, , drop=FALSE]
            rfout$nodeImprove <-
                rfout$nodeImprove[1:max.nodes, , drop=FALSE]
            rfout$xbestsplit <-
                rfout$xbestsplit[1:max.nodes, , drop=FALSE]
            rfout$leftDaughter <-
                rfout$leftDaughter[1:max.nodes, , drop=FALSE]
            rfout$rightDaughter <-
                rfout$rightDaughter[1:max.nodes, , drop=FALSE]
        }
        cl <- match.call()
        cl[[1]] <- as.name("rdaf_randomForest")
        out <- list(call = cl,
                    type = "regression",
                    predicted = structure(rfout$ypred, names=x.row.names),
                    mse = rfout$mse,
                    rsq = 1 - rfout$mse / (var(y) * (n-1) / n),
                    oob.times = rfout$oob.times,
                    importance = if (importance) matrix(rfout$impout, p, 2,
                    dimnames=list(x.col.names,
                                  c("%IncMSE","IncNodePurity"))) else
                        matrix(rfout$impout, ncol=1,
                               dimnames=list(x.col.names, "IncNodePurity")),
                    importanceSD=if (importance) rfout$impSD else NULL,
                    localImportance = if (localImp)
                    matrix(rfout$impmat, p, n, dimnames=list(x.col.names,
                                               x.row.names)) else NULL,
                    proximity = if (proximity) matrix(rfout$prox, n, n,
                    dimnames = list(x.row.names, x.row.names)) else NULL,
                    ntree = ntree,
                    mtry = mtry,
                    forest = if (keep.forest)
                    c(rfout[c("ndbigtree", "nodestatus", "leftDaughter",
                              "rightDaughter", "nodepred", "bestvar",
                              "xbestsplit", "nodeSS", "nodeImprove")],
                      list(ncat = ncat), list(nrnodes=max.nodes),
                      list(ntree=ntree), list(xlevels=xlevels)) else NULL,
                    coefs = if (corr.bias) rfout$coef else NULL,
                    y = y,
                    test = if(testdat) {
                        list(predicted = structure(rfout$ytestpred,
                             names=xts.row.names),
                             mse = if(labelts) rfout$msets else NULL,
                             rsq = if(labelts) 1 - rfout$msets /
                                        (var(ytest) * (n-1) / n) else NULL,
                             proximity = if (proximity) 
                             matrix(rfout$proxts / ntree, nrow = ntest,
                                    dimnames = list(xts.row.names,
                                    c(xts.row.names,
                                    x.row.names))) else NULL)
                    } else NULL,
                    inbag = if (keep.inbag)
                    matrix(rfout$inbag, nrow(rfout$inbag),
                           dimnames=list(x.row.names, NULL)) else NULL,
                    group = if (keep.group)
                    matrix(rfout$group, nrow(rfout$group),
                           dimnames=list(x.row.names, x.col.names)) else NULL,
                    permX = if (keep.group)
                    matrix(rfout$permX, nrow(rfout$permX),
                           dimnames=list(x.row.names, x.col.names)) else NULL)
    }
    ## Record how repeated samples were handled, so that it is visible in the
    ## fitted object.
    if (srep$mode != "none") {
        out$sites <- srep$factor
        out$site.repeats <- srep$mode
        if (blocks$n > 0) {
            out$block.holdout <- blocks$holdout
            out$sites.withheld <- blocks$nhold
        }
    }
    class(out) <- "rdaf_randomForest"
    return(out)
}



#' @rdname rdaf_randomForest
#' @method rdaf_randomForest formula
#' @export
"rdaf_randomForest.formula" <-
    function(formula, data = NULL, ..., subset, na.action = na.fail) {
### formula interface for randomForest.
### code gratefully stolen from svm.formula (package e1071).
###
    if (!inherits(formula, "formula"))
        stop("method is only for formula objects")
    m <- match.call(expand.dots = FALSE)
    ## Catch xtest and ytest in arguments.
    if (any(c("xtest", "ytest") %in% names(m)))
        stop("xtest/ytest not supported through the formula interface")
    names(m)[2] <- "formula"
    if (is.matrix(eval(m$data, parent.frame())))
        m$data <- as.data.frame(data)
    m$... <- NULL
    m$na.action <- na.action
    m[[1]] <- as.name("model.frame")
    m <- eval(m, parent.frame())
    y <- model.response(m)
    Terms <- attr(m, "terms")
    attr(Terms, "intercept") <- 0
    ## Drop any "negative" terms in the formula.
    ## test with:
    ## rdaf_randomForest(Fertility~.-Catholic+I(Catholic<50),data=swiss,mtry=2)
    m <- model.frame(terms(reformulate(attributes(Terms)$term.labels)),
                     data.frame(m))
    ## if (!is.null(y)) m <- m[, -1, drop=FALSE]
    for (i in seq(along=ncol(m))) {
        if (is.ordered(m[[i]])) m[[i]] <- as.numeric(m[[i]])
    }
    ret <- rdaf_randomForest(m, y, ...)
    cl <- match.call()
    cl[[1]] <- as.name("rdaf_randomForest")
    ret$call <- cl
    ret$terms <- Terms
    if (!is.null(attr(m, "na.action")))
        ret$na.action <- attr(m, "na.action")
    class(ret) <- c("rdaf_randomForest.formula", "rdaf_randomForest")
    return(ret)
}
