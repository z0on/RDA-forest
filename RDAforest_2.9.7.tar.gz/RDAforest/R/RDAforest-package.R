#' RDAforest: random forest analysis of large genomic matrices
#'
#' Identifies factors driving variation within large genomic datasets by
#' regressing the principal components of a genetic distance (or covariance)
#' matrix against environmental predictors with random forests, following the
#' gradient forest approach of Ellis, Smith and Pitcher (2012).
#'
#' @section A self-contained package:
#' From version 2.7.0 the random forest engine (\pkg{extendedForest}) and the
#' gradient forest machinery (\pkg{gradientForest}) are built into RDAforest
#' rather than loaded as dependencies. The incorporated functions are renamed
#' with an \code{rdaf_} prefix (\code{\link{rdaf_randomForest}},
#' \code{\link{rdaf_gradientForest}}, \code{\link{rdaf_importance}},
#' \code{\link{rdaf_cumimp}}, \code{\link{rdaf_getTree}}), so RDAforest can be
#' loaded alongside the original packages without masking anything. Apart from
#' the site.repeats option described below, they behave exactly as their
#' originals do, and reproduce their results given the same random seed.
#'
#' The random forest engine is C only: the Fortran classification tree builder
#' of the original was translated to C, so installing RDAforest from source
#' needs a C compiler but no Fortran compiler.
#'
#' @section Repeated samples within sites:
#' A random forest normally draws a bootstrap sample of individual rows to grow
#' each tree, and scores that tree on the rows it happened to miss. That assumes
#' the rows are independent. In most RDAforest datasets they are not: several
#' individuals are sampled at the same site (or reef, population, family,
#' sequencing batch, or year), and they therefore share exactly the same
#' predictor values. A held-out individual then has near-duplicates of itself in
#' the training set, so out-of-bag \eqn{R^2} and variable importance come out
#' inflated, and a predictor that merely tags an unusual site looks like a
#' driver of the genetics.
#'
#' Pass the site membership of each sample as \code{sites}, and choose what is
#' done about the repeats with \code{site.repeats}:
#'
#' \describe{
#'   \item{\code{"genetic.median"} (the default)}{Each site is collapsed to a
#'     single synthetic individual, a "false individual" placed at the geometric
#'     median of its members: the point with the smallest sum of distances to
#'     all of them, computed by Weiszfeld's iteration in the space of
#'     \strong{all} the principal coordinates being analysed (see
#'     \code{\link{genetic_medians}} and \code{\link{geometric_median}}).
#'     Unlike the medoid it is not one of the real samples, and unlike the
#'     centroid it is robust to an outlying individual. The forest is then
#'     fitted to one row per site, so there is no repeated sampling left to
#'     exploit and individual-level noise is averaged away. The cost is sample
#'     size: the model now has as many rows as there are sites.}
#'   \item{\code{"blocked.resampling"}}{Every individual is kept, but the unit
#'     of hold-out becomes the site rather than the row. Each tree withholds a
#'     random fraction of whole sites, set by \code{block.holdout} (default
#'     \code{1/3}); every sample of a withheld site is out-of-bag for that tree,
#'     and the samples of the retained sites are the pool from which the training
#'     sample is drawn in the ordinary way, with replacement by default. The only
#'     difference from an ordinary random forest is which samples are eligible to
#'     be drawn. Importance becomes a measure of how well a predictor generalises
#'     to sites the tree never saw. Use this when collapsing is unattractive, for
#'     instance when within-site genetic variation is itself of interest.}
#'   \item{\code{"direct.use"}}{The site structure is ignored and the
#'     individuals are used as they are. This is the ordinary random forest, and
#'     what RDAforest did before version 2.8.0; it is the fastest and the most
#'     optimistic.}
#' }
#'
#' You do not have to pass \code{sites} for this to happen. When it is left
#' \code{NULL}, RDAforest looks at the predictors themselves. Coordinate
#' columns are recognised by name (\code{lon}/\code{lat}, \code{x}/\code{y},
#' \code{easting}/\code{northing} and the like), or can be given with
#' \code{coords}; if none are found, a site is a set of rows whose predictor
#' values are identical throughout. Three things can happen:
#'
#' \itemize{
#'   \item No samples share a location: the individuals are analysed directly
#'     and nothing is reported.
#'   \item Samples share a location and agree on every environmental value:
#'     this is repeated sampling, and they are handled according to
#'     \code{site.repeats}, with a message naming the mode used. Detection
#'     supplies the sites, not the mode: naming \code{site.repeats} yourself
#'     overrides the \code{"genetic.median"} default.
#'   \item Samples share a location but disagree on the environment: something
#'     is off, since the environment was supposedly measured at the site, so a
#'     warning is issued and the individuals are analysed directly, leaving the
#'     decision to you.
#' }
#'
#' \code{\link{detect_sites}} runs that check on its own, and
#' \code{auto.sites = FALSE} switches it off. Passing \code{sites} explicitly
#' overrides it entirely.
#'
#' In practice the first two give very similar answers on the question they are
#' meant for, and both differ sharply from \code{"direct.use"}. In a simulation
#' of 40 sites with 10 individuals each, where two of four site-level predictors
#' truly drive the genetics, the importance wrongly assigned to the two noise
#' predictors was 57 percent of that assigned to the real ones under
#' \code{"direct.use"}, against 3 percent under \code{"genetic.median"} and
#' \code{"blocked.resampling"} alike. Cross-validation \eqn{R^2} tells the same
#' story from the other side: 0.76 under \code{"direct.use"} for a relationship
#' whose true \eqn{R^2} was 0.6, against 0.41 and 0.35 for the two honest
#' settings, which now under- rather than over-state it because they are working
#' from 40 effective observations.
#'
#' The option is available on \code{\link{rdaf_randomForest}},
#' \code{\link{rdaf_gradientForest}}, \code{\link{makeGF}},
#' \code{\link{makeGF_simple}}, \code{\link{predict_rf}},
#' \code{\link{predict_gf}}, \code{\link{mtrySelJack}} and
#' \code{\link{ordinationJackknife}}. Leaving \code{sites} at its default
#' \code{NULL} gives the ordinary random forest, so existing code is unaffected.
#' \code{\link{detect_sites}} reports what the automatic check finds,
#' \code{\link{site_repeats_summary}} reports what a given setting implies
#' before you commit to a long run, and \code{\link{spatial_blocks}} builds a
#' blocking vector by clustering samples on great circle distances, for data
#' that have no natural sites but are spatially autocorrelated.
#'
#' Note that in \code{\link{ordinationJackknife}} and \code{\link{mtrySelJack}}
#' the \code{oob} argument, which controls how many samples are withheld when
#' the ordination itself is rebuilt in each replicate, remains a plain random
#' draw over rows; \code{site.repeats} governs the random forest fitting only.
#'
#' @references
#' Ellis N., Smith S.J. and Pitcher C.R. (2012) Gradient forests: calculating
#' importance gradients on physical predictors. \emph{Ecology} 93: 156-168.
#'
#' Breiman L. (2001) Random forests. \emph{Machine Learning} 45: 5-32.
#'
#' Roberts D.R. et al. (2017) Cross-validation strategies for data with
#' temporal, spatial, hierarchical, or phylogenetic structure.
#' \emph{Ecography} 40: 913-929.
#'
#' @keywords internal
#' @useDynLib RDAforest, .registration = TRUE
#' @import ggplot2
#' @import sf
#' @import vegan
#' @import cluster
#' @rawNamespace import(raster, except = c(density, predict, quantile,
#'   aggregate, weighted.mean, update, barplot, lines, text, stack, extract,
#'   select, area, intersect, union, origin, shift, scale, trim, head, tail))
#' @importFrom dplyr %>% group_by summarise
#' @importFrom stats approx approxfun cor cutree density dist hclust integrate
#'   median model.frame model.matrix model.response na.omit napredict predict
#'   prcomp quantile reformulate terms var delete.response aggregate as.dist
#'   rnorm sd weighted.mean update
#' @importFrom graphics abline arrows axis barplot box legend lines matplot
#'   mtext par points text title
#' @importFrom grDevices col2rgb dev.off pdf rainbow rgb
#' @importFrom utils stack
"_PACKAGE"
