## ---------------------------------------------------------------------------
## Running jackknife replicates in parallel.
##
## mtrySelJack() and ordinationJackknife() spend nearly all their time in independent
## replicates, so they can be farmed out to several cores.  Two things have to
## be got right for that to be useful:
##
##  * reproducibility.  With one core the replicates share the caller's random
##    number stream, one after another, exactly as in every earlier version of
##    the package.  With several cores that cannot work, so each replicate gets
##    its own L'Ecuyer-CMRG stream, drawn up front from the caller's stream.
##    set.seed() then fixes the result, and it is the same whatever the number
##    of cores (2, 4 or 32), because replicate i always uses stream i.
##
##  * memory.  Replicates run in batches of `ncores`, and each batch is handed
##    back to the caller, in replicate order, before the next starts, so
##    anything that is reduced as it arrives (ordinationJackknife's running
##    sums) stays bounded by one batch.
## ---------------------------------------------------------------------------

## Validate ncores; cap it at the number of replicates.
.rdaf_check_ncores <- function(ncores, nreps) {
  if (!is.numeric(ncores) || length(ncores) != 1 || is.na(ncores) || ncores < 1)
    stop("ncores must be a single number, 1 or more")
  as.integer(min(floor(ncores), nreps))
}

## One independent L'Ecuyer-CMRG stream per replicate, seeded from the caller's
## stream (which advances by one draw) and leaving the caller's generator kind
## and state otherwise untouched.
.rdaf_rep_seeds <- function(n) {
  s <- sample.int(.Machine$integer.max, 1L)
  old.kind <- RNGkind()
  old.seed <- get(".Random.seed", envir = globalenv())
  on.exit({
    RNGkind(old.kind[1], old.kind[2], old.kind[3])
    assign(".Random.seed", old.seed, envir = globalenv())
  })
  RNGkind("L'Ecuyer-CMRG")
  set.seed(s)
  seeds <- vector("list", n)
  seeds[[1]] <- get(".Random.seed", envir = globalenv())
  for (i in seq_len(n)[-1]) seeds[[i]] <- parallel::nextRNGStream(seeds[[i - 1]])
  seeds
}

## Forking where the platform has it, socket clusters elsewhere (Windows).
## options(RDAforest.parallel = "psock") forces sockets, for the rare set-up
## in which forking misbehaves (some multithreaded BLAS libraries on macOS).
.rdaf_parallel_type <- function() {
  t <- getOption("RDAforest.parallel", NULL)
  if (!is.null(t)) return(match.arg(t, c("fork", "psock")))
  if (.Platform$OS.type == "windows") "psock" else "fork"
}

## Run FUN(i) for i in 1..nreps and pass each result, in replicate order, to
## collect(i, result).  FUN must never return NULL (return a marker for a
## failed replicate instead): NULL is how a killed worker shows up.  ncores == 1: plain serial loop on the caller's stream,
## bit-identical to earlier versions.  ncores > 1: batches of ncores
## replicates in parallel, replicate i on stream i.
.rdaf_run_reps <- function(nreps, FUN, collect, ncores = 1L, batch = nreps) {
  if (ncores <= 1L) {
    for (i in seq_len(nreps)) collect(i, FUN(i))
    return(invisible(NULL))
  }
  seeds <- .rdaf_rep_seeds(nreps)
  ## mclapply() runs a batch of one replicate in this process rather than a
  ## fork, and the task then sets .Random.seed here: put the caller's
  ## generator back afterwards, whatever happens
  saved.kind <- RNGkind()
  saved.seed <- get(".Random.seed", envir = globalenv())
  on.exit({
    RNGkind(saved.kind[1], saved.kind[2], saved.kind[3])
    assign(".Random.seed", saved.seed, envir = globalenv())
  }, add = TRUE)
  task <- .rdaf_make_task(FUN, seeds)
  type <- .rdaf_parallel_type()
  cl <- NULL
  if (type == "psock") {
    cl <- parallel::makeCluster(ncores)
    on.exit(parallel::stopCluster(cl), add = TRUE)
    ## the workers must find the same RDAforest as the session that called
    parallel::clusterCall(cl, .rdaf_set_libpaths, .libPaths())
  }
  message("running ", nreps, " replicates on ", ncores, " cores (", type, ")")
  ## `batch` replicates are dispatched at a time (all of them by default, which
  ## balances the load best); a caller that reduces results as they arrive
  ## passes a smaller batch to keep memory bounded
  batch <- max(ncores, as.integer(batch))
  batches <- split(seq_len(nreps), ceiling(seq_len(nreps) / batch))
  for (b in batches) {
    res <- if (type == "fork") {
      ## prescheduling forks ncores children once instead of one per
      ## replicate, which saves re-copying the session into each fork
      parallel::mclapply(b, task, mc.cores = ncores, mc.set.seed = FALSE,
                         mc.preschedule = TRUE)
    } else {
      parallel::parLapply(cl, b, task)
    }
    for (k in seq_along(b)) {
      r <- res[[k]]
      if (inherits(r, "try-error"))
        stop("replicate ", b[k], " failed: ", attr(r, "condition")$message %||% r,
             call. = FALSE)
      if (is.null(r))
        stop("replicate ", b[k], " returned nothing: a worker was probably ",
             "killed, most often for lack of memory. Try fewer cores.",
             call. = FALSE)
      collect(b[k], r)
    }
    if (length(batches) > 1)
      message("  replicates ", min(b), "-", max(b), " of ", nreps, " done")
  }
  invisible(NULL)
}

`%||%` <- function(a, b) if (is.null(a)) b else a

## Helpers defined at namespace level on purpose.  A function created inside
## another function carries that function's frame with it when it is sent to
## a socket-cluster worker, and those frames can hold large data: sending
## them would copy it to every worker.  These carry only what they need.
.rdaf_set_libpaths <- function(p) invisible(.libPaths(p))

.rdaf_make_task <- function(FUN, seeds) {
  force(FUN); force(seeds)
  function(i) {
    assign(".Random.seed", seeds[[i]], envir = globalenv())
    ## progress chatter from parallel workers would only interleave
    out <- NULL
    utils::capture.output(out <- suppressMessages(FUN(i)))
    out
  }
}
