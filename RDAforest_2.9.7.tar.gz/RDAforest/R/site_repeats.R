## ---------------------------------------------------------------------------
## Repeated sampling within sites: the `site.repeats` machinery.
##
## Many RDAforest datasets sample several individuals at each site, so all the
## individuals of a site share exactly the same predictor values.  Three ways of
## handling that are offered throughout the package, selected by `site.repeats`:
##
##   "genetic.median"     collapse each site to one synthetic individual, the
##                        geometric median of its members in the space of all
##                        supplied principal coordinates (Weiszfeld iteration)
##   "blocked.resampling" keep every individual, but make whole sites the unit
##                        of out-of-bag hold-out when fitting random forests
##   "direct.use"         keep every individual and ignore the site structure,
##                        which is the ordinary random forest
##
## This file holds the geometric median, the collapse, and the validators.
## ---------------------------------------------------------------------------

.RDAF_SITE_REPEATS <- c("genetic.median", "blocked.resampling", "direct.use")


#' Geometric median of a set of points
#'
#' The point minimising the sum of Euclidean distances to a set of points in any
#' number of dimensions, found by Weiszfeld's iteration. It is the
#' multidimensional generalisation of the ordinary median, and, like the median,
#' it is robust: an outlying point pulls it far less than it pulls the mean.
#'
#' Weiszfeld's iteration starts at the centroid and repeatedly replaces the
#' current estimate by the weighted mean of the points, each weighted by the
#' reciprocal of its distance to that estimate, so that near points count for
#' more than far ones. It converges to the geometric median from any starting
#' point except the degenerate case where the estimate lands exactly on one of
#' the data points, where the weight is undefined; that point is then returned,
#' as is standard.
#'
#' Note the distinction from two things it is easily confused with. The
#' \emph{centroid} (the ordinary mean) minimises the sum of \emph{squared}
#' distances, and is therefore not robust. The \emph{medoid} minimises the sum
#' of distances too, but only over the data points themselves, so it is always
#' one of the real samples. The geometric median is a computed location, a
#' "false individual" that need not coincide with any real one.
#'
#' @param P numeric matrix or data frame, one row per point, one column per
#'   dimension.
#' @param tol convergence tolerance on the movement of the estimate between
#'   iterations, also used to decide that the estimate has landed on a point.
#' @param maxit maximum number of Weiszfeld iterations.
#' @return A numeric vector of length \code{ncol(P)}: the coordinates of the
#'   geometric median.
#' @seealso \code{\link{genetic_medians}}, \code{\link{site_repeats_summary}}
#' @references Weiszfeld E. (1937) Sur le point pour lequel la somme des
#'   distances de n points donnes est minimum. \emph{Tohoku Mathematical
#'   Journal} 43: 355-386.
#' @examples
#' set.seed(1)
#' P <- matrix(rnorm(20), 10, 2)
#' geometric_median(P)
#' colMeans(P)   ## the centroid, which is pulled further by outliers
#' @export
geometric_median <- function(P, tol = 1e-10, maxit = 500) {
  P <- as.matrix(P)
  if (!is.numeric(P))
    stop("geometric_median() needs numeric coordinates")
  if (anyNA(P))
    stop("geometric_median() cannot handle missing coordinates")
  if (nrow(P) == 0L)
    stop("geometric_median() needs at least one point")
  if (nrow(P) == 1L)
    return(drop(P))
  ## In one dimension the geometric median is the ordinary median.  Take it
  ## directly: with an even number of points every value between the two middle
  ## ones minimises the sum of distances, and Weiszfeld would settle on an
  ## arbitrary one of them rather than the conventional midpoint.
  if (ncol(P) == 1L)
    return(stats::median(P[, 1]))

  m <- colMeans(P)
  for (it in seq_len(maxit)) {
    d <- sqrt(rowSums(sweep(P, 2, m)^2))
    ## The estimate has landed on one of the points: its weight is undefined,
    ## and that point is the answer.
    if (any(d < tol)) return(P[which.min(d), ])
    w <- 1 / d
    mnew <- colSums(P * w) / sum(w)
    if (sqrt(sum((mnew - m)^2)) < tol) return(mnew)
    m <- mnew
  }
  m
}


#' Collapse repeated samples to one synthetic individual per site
#'
#' Replaces the several individuals sampled at each site by a single "false
#' individual" placed at their geometric median, computed with
#' \code{\link{geometric_median}} using \strong{all} the supplied principal
#' coordinates as its coordinate space. The result is one row per site, so
#' there is no repeated sampling left for the random forest to exploit.
#'
#' This is what \code{site.repeats = "genetic.median"} does inside
#' \code{\link{makeGF}}, \code{\link{makeGF_simple}},
#' \code{\link{ordinationJackknife}}, \code{\link{mtrySelJack}} and
#' \code{\link{predict_rf}}; it is exported so that the collapsed data can be
#' inspected directly.
#'
#' @param Y matrix or data frame of principal coordinates (or any other
#'   numeric response), one row per individual. All columns are used as
#'   coordinates.
#' @param sites vector of site memberships, one entry per row of \code{Y}
#'   (factor, character, integer or numeric).
#' @return A data frame with one row per site, in the order of
#'   \code{levels(factor(sites))}, and the same columns as \code{Y}.
#' @seealso \code{\link{geometric_median}}, \code{\link{site_repeats_summary}}
#' @examples
#' set.seed(1)
#' Y <- data.frame(MDS1 = rnorm(30), MDS2 = rnorm(30))
#' sites <- rep(c("reefA", "reefB", "reefC"), each = 10)
#' genetic_medians(Y, sites)
#' @export
genetic_medians <- function(Y, sites) {
  Ym <- as.matrix(Y)
  if (!is.numeric(Ym))
    stop("genetic_medians() needs a numeric response matrix; ",
         "site.repeats = \"genetic.median\" is for principal coordinates, ",
         "use \"blocked.resampling\" or \"direct.use\" for anything else")
  f <- factor(sites)
  if (length(f) != nrow(Ym))
    stop("sites must have one entry per row of Y: expected ", nrow(Ym),
         ", got ", length(f))
  res <- vapply(levels(f),
                function(s) geometric_median(Ym[f == s, , drop = FALSE]),
                numeric(ncol(Ym)))
  ## vapply drops to a plain vector when there is a single coordinate
  out <- if (ncol(Ym) == 1L) matrix(res, ncol = 1L) else t(res)
  rownames(out) <- levels(f)
  if (!is.null(colnames(Ym))) colnames(out) <- colnames(Ym)
  as.data.frame(out)
}


## Collapse the predictors of a site to a single row.  The premise of
## `site.repeats` is that the predictors are measured AT the site, so they are
## constant within it; if they are not, take the mean and say so once.
.rdaf_collapse_predictors <- function(X, f, warn = TRUE) {
  lev <- levels(f)
  varying <- character(0)
  cols <- lapply(names(X), function(v) {
    col <- X[[v]]
    if (is.numeric(col)) {
      m <- tapply(col, f, mean)
      s <- tapply(col, f, function(z) if (length(z) < 2) 0 else stats::sd(z))
      if (any(s > 0, na.rm = TRUE)) varying <<- c(varying, v)
      as.numeric(m[lev])
    } else {
      u <- tapply(as.character(col), f, function(z) unique(z))
      if (any(lengths(u) > 1)) varying <<- c(varying, v)
      vals <- vapply(u[lev], function(z) as.character(z)[1], character(1))
      if (is.factor(col)) factor(vals, levels = levels(col)) else vals
    }
  })
  names(cols) <- names(X)
  out <- as.data.frame(cols, stringsAsFactors = FALSE)
  rownames(out) <- lev
  if (warn && length(varying))
    warning("site.repeats = \"genetic.median\" expects predictors to be ",
            "constant within a site, but ", paste(unique(varying),
            collapse = ", "), " vary; using the within-site mean")
  out
}

## Collapse a fitting problem (X, Y) to one row per site.
.rdaf_collapse_sites <- function(X, Y, f) {
  Ys <- genetic_medians(Y, f)
  Xs <- .rdaf_collapse_predictors(as.data.frame(X), f)
  if (is.matrix(Y)) Ys <- as.matrix(Ys)
  list(X = Xs, Y = Ys, sites = factor(levels(f), levels = levels(f)))
}


#' Validate the site.repeats setting
#'
#' Internal helper. Resolves \code{site.repeats} against a \code{sites} vector
#' and the number of rows of the data, and checks both.
#'
#' @param sites site membership vector or \code{NULL}.
#' @param n number of rows in the data.
#' @param site.repeats one of \code{"genetic.median"},
#'   \code{"blocked.resampling"}, \code{"direct.use"}.
#' @param block.holdout fraction of sites withheld per tree, for
#'   \code{"blocked.resampling"}.
#' @return A list with \code{mode} (the resolved mode, \code{"none"} when no
#'   sites were given), \code{factor}, \code{nsites}, and \code{blocks} (the
#'   compact representation the compiled code expects, only for
#'   \code{"blocked.resampling"}).
#' @keywords internal
#' @noRd
.rdaf_check_site_repeats <- function(sites, n, site.repeats, block.holdout = 1/3) {
  none <- list(mode = "none", factor = NULL, nsites = 0L,
               blocks = .rdaf_check_blocks(NULL, n))
  if (is.null(sites)) return(none)

  mode <- match.arg(site.repeats, .RDAF_SITE_REPEATS)

  if (is.matrix(sites) || is.data.frame(sites)) {
    if (ncol(sites) != 1)
      stop("sites must be a vector, not a multi-column object")
    sites <- sites[[1]]
  }
  if (length(sites) != n)
    stop("sites must have one entry per row of the data: expected ", n,
         ", got ", length(sites))
  if (any(is.na(sites)))
    stop("sites must not contain NA")

  f <- factor(sites)
  ns <- nlevels(f)

  if (mode == "direct.use")
    return(list(mode = "direct.use", factor = f, nsites = as.integer(ns),
                blocks = .rdaf_check_blocks(NULL, n)))

  if (ns < 2)
    stop("sites must define at least two sites; found ", ns)

  if (mode == "genetic.median") {
    if (ns == n)
      warning("every site holds a single sample, so ",
              "site.repeats = \"genetic.median\" changes nothing")
    if (ns < 10)
      warning("collapsing to ", ns, " sites leaves very few rows to fit on")
    return(list(mode = "genetic.median", factor = f, nsites = as.integer(ns),
                blocks = .rdaf_check_blocks(NULL, n)))
  }

  list(mode = "blocked.resampling", factor = f, nsites = as.integer(ns),
       blocks = .rdaf_check_blocks(f, n, block.holdout))
}


## Accept the retired `oob.blocks` / `oob.block.holdout` pair and translate it
## into the current arguments.  Returns the (possibly updated) triple.
.rdaf_deprecate_oob_blocks <- function(sites, site.repeats, block.holdout,
                                       oob.blocks, oob.block.holdout) {
  if (!is.null(oob.blocks)) {
    warning("'oob.blocks' is deprecated: use sites = ..., ",
            "site.repeats = \"blocked.resampling\"", call. = FALSE)
    if (is.null(sites)) {
      sites <- oob.blocks
      site.repeats <- "blocked.resampling"
    }
  }
  if (!is.null(oob.block.holdout)) {
    warning("'oob.block.holdout' is deprecated: use 'block.holdout'",
            call. = FALSE)
    block.holdout <- oob.block.holdout
  }
  list(sites = sites, site.repeats = site.repeats,
       block.holdout = block.holdout)
}


#' Summarise how repeated samples will be handled
#'
#' Reports what \code{site.repeats} will do with a given site vector before any
#' time is spent on a full run: how many sites there are, how many samples each
#' holds, and then, for the chosen mode, how many rows the random forest will
#' actually be fitted on.
#'
#' For \code{"genetic.median"} that is one row per site. For
#' \code{"blocked.resampling"} it is every row, with whole sites withheld from
#' each tree; the summary gives the number of sites withheld and the size of the
#' pool left eligible, of which a bootstrap draw uses about \eqn{1 - 1/e} of the
#' distinct rows, as in any random forest. Highly unbalanced sites are worth
#' knowing about in advance, because with blocked resampling the number of
#' training samples varies from tree to tree.
#'
#' @param sites vector of site memberships, one entry per sample.
#' @param site.repeats one of \code{"genetic.median"} (the default),
#'   \code{"blocked.resampling"} or \code{"direct.use"}.
#' @param block.holdout fraction of sites withheld from each tree under
#'   \code{"blocked.resampling"} (default \code{1/3}).
#' @return (invisibly) a list with the table of site sizes, the resolved mode,
#'   the number of rows fitted, and, for blocked resampling, the number of sites
#'   withheld per tree and the smallest/expected/largest size of the eligible
#'   pool. Printed as a short summary as a side effect.
#' @seealso \code{\link{genetic_medians}}, \code{\link{spatial_blocks}}
#' @examples
#' sites <- rep(c("reefA", "reefB", "reefC", "reefD", "reefE"), each = 12)
#' site_repeats_summary(sites)
#' site_repeats_summary(sites, "blocked.resampling", block.holdout = 0.4)
#' @export
site_repeats_summary <- function(sites, site.repeats = "genetic.median",
                                 block.holdout = 1/3) {
  n <- length(sites)
  s <- .rdaf_check_site_repeats(sites, n, site.repeats, block.holdout)
  tab <- table(s$factor)
  sizes <- as.numeric(tab)

  cat("Repeated sampling within sites\n")
  cat("  samples:               ", n, "\n", sep = "")
  cat("  sites:                 ", s$nsites, "\n", sep = "")
  cat("  samples per site:      min ", min(sizes), ", median ",
      stats::median(sizes), ", max ", max(sizes), "\n", sep = "")
  cat("  site.repeats:          ", s$mode, "\n", sep = "")

  out <- list(sites = tab, mode = s$mode)
  if (s$mode == "genetic.median") {
    cat("  rows fitted:           ", s$nsites,
        " (one geometric median per site)\n", sep = "")
    out$rows.fitted <- s$nsites
  } else if (s$mode == "blocked.resampling") {
    b <- s$blocks
    nkeep <- b$n - b$nhold
    smallest <- sum(sort(sizes)[seq_len(nkeep)])
    largest <- sum(sort(sizes, decreasing = TRUE)[seq_len(nkeep)])
    expected <- n * nkeep / b$n
    cat("  rows fitted:           ", n, " (all individuals)\n", sep = "")
    cat("  withheld per tree:     ", b$nhold, " site(s) (",
        round(100 * b$nhold / b$n), "%)\n", sep = "")
    cat("  eligible pool/tree:    ", smallest, " to ", largest,
        " samples (expected ", round(expected, 1), ")\n", sep = "")
    cat("  of which drawn in-bag: ", "~", round(0.632 * expected),
        " distinct (bootstrap)\n", sep = "")
    out$rows.fitted <- n
    out$n.withheld <- b$nhold
    out$pool <- c(min = smallest, expected = expected, max = largest)
  } else {
    cat("  rows fitted:           ", n,
        " (all individuals, site structure ignored)\n", sep = "")
    out$rows.fitted <- n
  }
  invisible(out)
}


## Number of rows a fit will actually see, given the site.repeats mode.  Used by
## makeGF()/makeGF_simple() to size `maxLevel`.
.rdaf_effective_n <- function(n, sites, site.repeats) {
  if (is.null(sites)) return(n)
  if (match.arg(site.repeats, .RDAF_SITE_REPEATS) != "genetic.median") return(n)
  nlevels(factor(sites))
}


## ---------------------------------------------------------------------------
## Automatic detection of repeated sampling.
##
## When `sites` is not supplied, look at the predictors themselves: samples
## taken at the same place carry the same coordinates, and, if they really are
## from one site, the same environmental values too.
## ---------------------------------------------------------------------------

## Column names that plausibly hold spatial coordinates.  Matching is on the
## name stripped of punctuation and case, and both an x-like and a y-like
## column must be found, exactly one of each, or we conclude there are none.
.RDAF_XNAMES <- c("lon", "long", "longitude", "x", "xx", "east", "easting",
                  "utmx", "utmeasting", "coordx", "lonutm", "longitudeutm",
                  "xutm", "xcoord")
.RDAF_YNAMES <- c("lat", "latitude", "y", "yy", "north", "northing",
                  "utmy", "utmnorthing", "coordy", "latutm", "latitudeutm",
                  "yutm", "ycoord")

.rdaf_coord_columns <- function(X, coords = NULL) {
  ## explicit coordinates win: either a two-column object of their own, or the
  ## names of columns of X
  if (!is.null(coords)) {
    if (is.character(coords)) {
      miss <- setdiff(coords, names(X))
      if (length(miss))
        stop("coords names not found among the predictors: ",
             paste(miss, collapse = ", "))
      return(list(coords = X[coords], names = coords))
    }
    coords <- as.data.frame(coords)
    if (nrow(coords) != nrow(X))
      stop("coords must have one row per sample: expected ", nrow(X),
           ", got ", nrow(coords))
    return(list(coords = coords, names = character(0)))
  }
  nm <- tolower(gsub("[^A-Za-z0-9]", "", names(X)))
  xi <- which(nm %in% .RDAF_XNAMES)
  yi <- which(nm %in% .RDAF_YNAMES)
  if (length(xi) != 1L || length(yi) != 1L)
    return(list(coords = NULL, names = character(0)))
  list(coords = X[c(xi, yi)], names = names(X)[c(xi, yi)])
}

## One string per row, so that "same values" is a single comparison.  Numbers
## are formatted rather than compared bit for bit, which keeps the last digits
## of a coordinate read from a file from splitting a site in two.
.rdaf_row_keys <- function(D) {
  if (!ncol(D)) return(rep("", nrow(D)))
  parts <- lapply(D, function(v)
    if (is.numeric(v)) sprintf("%.10g", v) else as.character(v))
  do.call(paste, c(parts, sep = "\r"))
}


#' Detect repeated sampling in a predictor matrix
#'
#' Looks for samples that were taken at the same place. Coordinates are found
#' among the predictors by name (\code{lon}/\code{lat},
#' \code{x}/\code{y}, \code{easting}/\code{northing} and similar), or supplied
#' with \code{coords}; failing both, a site is a set of rows whose predictor
#' values are identical throughout.
#'
#' Three outcomes, which are exactly what the RDAforest functions act on when
#' \code{sites} is not given:
#'
#' \describe{
#'   \item{no shared locations}{Nothing is reported and the individuals are
#'     analysed directly.}
#'   \item{shared locations, identical environments}{Repeated sampling: a
#'     message is printed and the samples of a site are represented by their
#'     genetic median (\code{site.repeats = "genetic.median"}).}
#'   \item{shared locations, differing environments}{This should not happen if
#'     the environment was measured at the site, so a warning is issued and the
#'     individuals are analysed directly, leaving the decision to you.}
#' }
#'
#' Telling the second case from the third needs the coordinates to be
#' identifiable. When they are not, that is, no recognisable column names and
#' no \code{coords}, a site can only be a set of identical rows, so a sample
#' that shares a location but differs in one environmental value simply counts
#' as a site of its own, and nothing is warned about. Pass \code{coords} if
#' that distinction matters to you.
#'
#' @param X data frame or matrix of predictors, one row per sample.
#' @param coords optional coordinates: either the names of the coordinate
#'   columns of \code{X}, or a separate two-column object with one row per
#'   sample. \code{NULL} looks for coordinate columns by name.
#' @param quiet whether to suppress the message and the warning.
#' @return (invisibly) a list with \code{sites} (a factor, or \code{NULL} when
#'   no repeated sampling was found), \code{site.repeats} (the mode the
#'   RDAforest functions will use) and \code{detected}, one of \code{"none"},
#'   \code{"coords"}, \code{"rows"} or \code{"mismatch"}.
#' @seealso \code{\link{site_repeats_summary}}, \code{\link{genetic_medians}}
#' @examples
#' X <- data.frame(lon = rep(1:4, each = 5), lat = rep(1:4, each = 5),
#'                 temp = rep(c(10, 12, 14, 16), each = 5))
#' det <- detect_sites(X)
#' table(det$sites)
#' @export
detect_sites <- function(X, coords = NULL, quiet = FALSE) {
  none <- list(sites = NULL, site.repeats = "direct.use", detected = "none")
  X <- as.data.frame(X)
  n <- nrow(X)
  if (n < 3L || !ncol(X)) return(invisible(none))

  cc <- .rdaf_coord_columns(X, coords)
  by.coords <- !is.null(cc$coords)
  key <- .rdaf_row_keys(if (by.coords) cc$coords else X)
  f <- factor(key, levels = unique(key))
  ns <- nlevels(f)
  ## every row its own place, or every row the same place: nothing to do
  if (ns == n || ns < 2L) return(invisible(none))

  if (by.coords) {
    ## same location: do the environmental entries agree, as they must if the
    ## environment was measured at the site?
    rest <- X[setdiff(names(X), cc$names)]
    if (ncol(rest)) {
      keyr <- .rdaf_row_keys(rest)
      agree <- all(tapply(keyr, f, function(z) length(unique(z))) == 1L)
      if (!agree) {
        if (!quiet)
          warning("some samples share a spatial location but have different ",
                  "environmental entries, check", call. = FALSE)
        return(invisible(list(sites = NULL, site.repeats = "direct.use",
                              detected = "mismatch")))
      }
    }
  }

  levels(f) <- paste0("site", seq_len(ns))
  if (!quiet) {
    message("Data appear to contain multiple samples per site. Such samples ",
            "will be represented as their genetic median; see option ",
            "site.repeats for alternatives.")
    message("  (", n, " samples in ", ns, " sites of ",
            min(table(f)), " to ", max(table(f)), " samples, identified by ",
            if (by.coords) "shared coordinates)" else
              "identical predictor rows)")
  }
  invisible(list(sites = f, site.repeats = "genetic.median",
                 detected = if (by.coords) "coords" else "rows"))
}

## Resolve `sites` when the user did not supply it.  Returns the pair the
## fitting functions go on to use.
##
## `explicit` says whether the caller named a `site.repeats` of their own.  If
## they did, detection supplies the sites but NOT the mode: what the data get
## is what was asked for.  Only a caller who left `site.repeats` alone gets the
## detector's default, which is "genetic.median".
.rdaf_resolve_sites <- function(X, sites, site.repeats, coords = NULL,
                                auto.sites = TRUE, explicit = FALSE) {
  if (!is.null(sites) || !isTRUE(auto.sites))
    return(list(sites = sites, site.repeats = site.repeats))

  ## detect_sites() announces the genetic median by name, which would be a lie
  ## when another mode was asked for, so in that case detect quietly and report
  ## the truth here instead.
  det <- detect_sites(X, coords, quiet = explicit)

  if (is.null(det$sites)) {
    ## nothing to do, but a mismatch is a data-integrity problem worth saying
    ## out loud whatever mode was asked for
    if (explicit && identical(det$detected, "mismatch"))
      warning("some samples share a spatial location but have different ",
              "environmental entries, check", call. = FALSE)
    return(list(sites = NULL, site.repeats = site.repeats))
  }

  if (!explicit)
    return(list(sites = det$sites, site.repeats = det$site.repeats))

  mode <- match.arg(site.repeats, .RDAF_SITE_REPEATS)
  message("Data appear to contain multiple samples per site (",
          length(det$sites), " samples in ", nlevels(det$sites),
          " sites); handling them with site.repeats = \"", mode, "\".")
  list(sites = det$sites, site.repeats = mode)
}
