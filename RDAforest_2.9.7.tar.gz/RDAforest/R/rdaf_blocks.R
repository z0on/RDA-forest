## ---------------------------------------------------------------------------
## Blocked (grouped) out-of-bag resampling for RDAforest.
##
## Low-level helper that validates a blocking vector and turns it into the
## compact integer representation the compiled random forest code expects.
## Reached from the user-facing `site.repeats = "blocked.resampling"`; see
## site_repeats.R.
## ---------------------------------------------------------------------------

#' Validate a blocking vector
#'
#' Internal helper. Checks a blocking vector against the number of rows of the
#' design matrix and converts it into the representation the compiled random
#' forest code expects: 1-based consecutive integer block codes plus the number
#' of distinct blocks.
#'
#' @param blocks a vector of length \code{n} giving the block membership of
#'   each row (factor, character, integer or numeric), or \code{NULL} for the
#'   usual unblocked sampling.
#' @param n number of rows in the data.
#' @param holdout fraction of blocks to withhold from each tree.
#' @return A list with components \code{index} (integer block codes, or a single
#'   zero when blocking is off), \code{n} (number of blocks, zero when blocking
#'   is off), \code{holdout}, \code{nhold} (number of blocks actually withheld
#'   per tree) and \code{factor} (the blocks as a factor, or \code{NULL}).
#' @keywords internal
#' @noRd
.rdaf_check_blocks <- function(blocks, n, holdout = 1/3) {
  if (is.null(blocks))
    return(list(index = 0L, n = 0L, holdout = 0, nhold = 0L, factor = NULL))

  if (is.matrix(blocks) || is.data.frame(blocks)) {
    if (ncol(blocks) != 1)
      stop("sites must be a vector, not a multi-column object")
    blocks <- blocks[[1]]
  }
  if (length(blocks) != n)
    stop("sites must have one entry per row of the data: expected ",
         n, ", got ", length(blocks))
  if (any(is.na(blocks)))
    stop("sites must not contain NA")

  f <- factor(blocks)
  nb <- nlevels(f)
  if (nb < 2)
    stop("sites must define at least two blocks; found ", nb)

  if (!is.numeric(holdout) || length(holdout) != 1 || is.na(holdout))
    stop("block.holdout must be a single number")
  if (holdout <= 0 || holdout >= 1)
    stop("block.holdout must be strictly between 0 and 1")

  nhold <- round(holdout * nb)
  nhold <- max(1L, min(as.integer(nhold), nb - 1L))
  if (nhold != round(holdout * nb))
    warning("block.holdout = ", format(holdout), " with ", nb,
            " sites rounds to ", nhold, " withheld site(s) per tree")

  ## Warn about a configuration that leaves very little training data.
  insize <- sum(sort(table(f), decreasing = TRUE)[seq_len(nb - nhold)])
  if (insize < 5)
    warning("blocked resampling may leave as few as ", insize,
            " in-bag cases per tree")

  list(index = as.integer(f), n = as.integer(nb), holdout = as.double(holdout),
       nhold = nhold, factor = f)
}
