## ---------------------------------------------------------------------------
## Ordinations for the jackknife functions.  Y is always a distance matrix
## (raw data matrices are no longer accepted: pass as.matrix(dist(Y)), which
## gives the same ordination as an RDA of Y), and the ordination is always a
## principal coordinates analysis by capscale(), optionally conditioned on
## covariates.
## ---------------------------------------------------------------------------

## Check that Y is a distance matrix; a `dist` object is converted.  Anything
## else that is square and symmetric is returned exactly as supplied, so that
## results do not change from earlier versions.
.rdaf_as_distance <- function(Y) {
  if (inherits(Y, "dist")) Y <- as.matrix(Y)
  Ym <- tryCatch(as.matrix(Y), error = function(e) NULL)
  ok <- !is.null(Ym) && is.numeric(Ym) && length(dim(Ym)) == 2 &&
    nrow(Ym) == ncol(Ym) && nrow(Ym) > 1 && !anyNA(Ym) &&
    isSymmetric(unname(Ym))
  if (!ok)
    stop("Y must be a distance matrix: square and symmetric, one row and ",
         "column per sample (for example 1-cor(t(genotypes)), or a 'dist' ",
         "object). Raw data matrices are not accepted; for one, pass ",
         "as.matrix(dist(Y)), which gives the same ordination as an RDA of Y.",
         call. = FALSE)
  Y
}

## Ordination of all samples.
.rdaf_ord_full <- function(Y, covariates = NULL) {
  if (!is.null(covariates)) capscale(Y ~ 1 + Condition(as.matrix(covariates)))
  else capscale(Y ~ 1)
}

## One jackknife replicate: ordination of the in-bag samples, with all samples
## projected onto it.
.rdaf_ord_rep <- function(Y, ib.keep, covariates = NULL) {
  Y.ib <- Y[ib.keep, ib.keep]
  if (!is.null(covariates)) {
    covars.ib <- covariates[ib.keep, ]
    ords0 <- capscale(Y.ib ~ 1 + Condition(as.matrix(covars.ib)))
  } else {
    ords0 <- capscale(Y.ib ~ 1)
  }
  suppressWarnings({ ords <- predict(ords0, Y, type = "sp", scaling = "sites") })
  list(ords0 = ords0, ords = ords)
}

## ---------------------------------------------------------------------------
## mtrySelJack helpers
## ---------------------------------------------------------------------------

## The two mtry values mtrySelJack compares.  The general defaults coincide
## (3 and 3) for five or fewer predictors, which makes the test a coin toss,
## so small predictor sets get 1 vs 2 (three predictors) or 1 vs 3 (four or
## five).  Fewer than three predictors cannot be tested at all.
.rdaf_mtry_pair <- function(np, mintry = NULL, maxtry = NULL) {
  if (np < 3)
    stop("mtrySelJack needs at least 3 predictors: the test compares ",
         "importances at two different mtry values, and with ", np,
         " there is no meaningful pair.", call. = FALSE)
  if (np <= 5) {
    dmin <- 1; dmax <- if (np == 3) 2 else 3
  } else {
    dmin <- max(3, round(np / 5)); dmax <- max(min(np - 2, 6), round(2 * np / 5) + 1)
  }
  if (is.null(mintry)) mintry <- dmin
  if (is.null(maxtry)) maxtry <- dmax
  if (mintry < 1 || maxtry > np || mintry >= maxtry)
    stop("need 1 <= mintry < maxtry <= the number of predictors (", np,
         "); got mintry = ", mintry, ", maxtry = ", maxtry, call. = FALSE)
  c(mintry, maxtry)
}

## Correlations among the numeric predictors, kept in the mtrySelJack() result
## so that Reselect() can redo the report without the data.
.rdaf_predictor_cor <- function(X) {
  num <- names(X)[vapply(X, is.numeric, logical(1))]
  if (length(num) < 2) return(NULL)
  suppressWarnings(stats::cor(X[, num, drop = FALSE], use = "pairwise.complete.obs"))
}

## Dropped predictors that correlate with a retained one at |r| >= report.cor,
## reported in a message and returned as a data frame.  `cmat` is the
## correlation matrix from .rdaf_predictor_cor().
.rdaf_dropped_pairs <- function(cmat, goodvars, importances, prop.positive,
                                ic, pp.cutoff, report.cor = 0.7) {
  empty <- data.frame(dropped = character(0), kept = character(0),
                      r = numeric(0), importance = numeric(0),
                      prop.positive = numeric(0), reason = character(0),
                      stringsAsFactors = FALSE)
  if (is.null(report.cor) || is.na(report.cor) || is.null(cmat)) return(empty)
  num <- colnames(cmat)
  dropped <- setdiff(intersect(names(importances), num), goodvars)
  kept <- intersect(goodvars, num)
  if (!length(dropped) || !length(kept)) return(empty)
  cm <- cmat[dropped, kept, drop = FALSE]
  hit <- which(!is.na(cm) & abs(cm) >= report.cor, arr.ind = TRUE)
  if (!nrow(hit)) return(empty)
  d <- dropped[hit[, 1]]
  imp <- unname(importances[d]); pp <- unname(prop.positive[d])
  reason <- ifelse(imp < ic & pp < pp.cutoff, "mtry test and low importance",
            ifelse(pp < pp.cutoff, "mtry test", "low importance"))
  out <- data.frame(dropped = d, kept = kept[hit[, 2]], r = cm[hit],
                    importance = imp, prop.positive = pp, reason = reason,
                    stringsAsFactors = FALSE)
  out <- out[order(-abs(out$r), out$dropped), ]
  rownames(out) <- NULL
  message("\nDropped predictors correlated with retained ones (|r| >= ",
          report.cor, "):\n",
          paste(vapply(unique(out$dropped), function(d) {
            o <- out[out$dropped == d, ]
            sprintf("  %s (%s) ~ %s", d, o$reason[1],
                    paste(sprintf("%s %.2f", o$kept, o$r), collapse = ", "))
          }, character(1)), collapse = "\n"),
          "\nThe mtry test treats such predictors as proxies of the retained ",
          "ones. Two predictors that are both real drivers but correlated can ",
          "lose to each other the same way, so reconsider any that are ",
          "plausibly drivers in their own right. Details in $dropped.pairs.")
  out
}
