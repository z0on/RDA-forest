/*******************************************************************
   Copyright (C) 2001-7  Leo Breiman and Adele Cutler and Merck & Co, Inc.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
*******************************************************************

   C translation of rfsub.f (buildtree, findbestsplit, movedata and the
   small array helpers), made for RDAforest so that the package builds
   without a Fortran compiler.

   The translation is deliberately literal.  Arrays keep the column-major
   layout and 1-based indexing of the Fortran original through the macros
   below, the control flow mirrors the original statement for statement, and
   the random number generator is drawn from in exactly the same order, so
   that a forest grown by this code is bit-for-bit identical to one grown by
   the Fortran it replaces.

   Two details of the original that look like bugs but are load-bearing,
   because they consume random numbers and so shift every later draw, are
   reproduced exactly and flagged in place:

     - in findbestsplit, the "break ties at random" test runs after critmax
       has already been updated, so a strict improvement also counts as a tie
       and draws a random number;
     - the same pattern appears in buildtree when a terminal node's class is
       chosen.

   Fortran's implicit typing (i-n integer, everything else double precision)
   has been made explicit.
*******************************************************************/

#include <R.h>
#include <Rmath.h>
#include "rf.h"

/* Fortran arrays are column-major and 1-based; these macros preserve both so
   that the translated index expressions read like the original. */
#define A(i, j)        a[((i) - 1) + ((j) - 1) * mdim]
#define B(i, j)        b[((i) - 1) + ((j) - 1) * mdim]
#define TREEMAP(i, j)  treemap[((i) - 1) + ((j) - 1) * 2]
#define CLASSPOP(i, j) classpop[((i) - 1) + ((j) - 1) * nclass]
#define TCLASSCAT(i, j) tclasscat[((i) - 1) + ((j) - 1) * nclass]

/* 1-based views of the plain vectors */
#define V(x, i) (x)[(i) - 1]


/* ------------------------------------------------------------------ *
 *  FINDBESTSPLIT
 *
 *  For the best split, msplit is the variable split on.  decsplit is the
 *  decrease in impurity.  If msplit is numerical, nbest is the case number of
 *  the value of msplit split on, and the next larger value is its successor.
 *  If msplit is categorical, nbest is the coding into an integer of the
 *  categories going left.
 * ------------------------------------------------------------------ */
static void findbestsplit(int *a, int *b, int *cl, int mdim, int nsample,
                          int nclass, int *cat, int maxcat, int ndstart,
                          int ndend, double *tclasspop, double *tclasscat,
                          int *msplit, double *decsplit, int *nbest,
                          int *ncase, int *jstat, int mtry, double *win,
                          double *wr, double *wl, int mred, int *mind) {
    double pno, pdo, crit0, critmax, rrn, rrd, rln, rld, u, su, crit;
    double dn[32];
    int i, j, k, l, mt, mvar, lcat, nsp, nc, nn, nnz, nhit, ntie;
    int ncmax = 10, ncsplit = 512;

    /* compute initial values of numerator and denominator of Gini */
    pno = 0.0;
    pdo = 0.0;
    for (j = 1; j <= nclass; ++j) {
        pno += V(tclasspop, j) * V(tclasspop, j);
        pdo += V(tclasspop, j);
    }
    crit0 = pno / pdo;
    *jstat = 0;

    /* start main loop through variables to find best split */
    critmax = -1.0e25;
    for (k = 1; k <= mred; ++k) V(mind, k) = k;
    nn = mred;

    /* sampling mtry variables w/o replacement */
    for (mt = 1; mt <= mtry; ++mt) {
        j = (int) (nn * unif_rand()) + 1;
        mvar = V(mind, j);
        V(mind, j) = V(mind, nn);
        V(mind, nn) = mvar;
        nn = nn - 1;
        lcat = V(cat, mvar);

        if (lcat == 1) {
            /* Split on a numerical predictor. */
            rrn = pno;
            rrd = pdo;
            rln = 0.0;
            rld = 0.0;
            for (j = 1; j <= nclass; ++j) V(wl, j) = 0.0;
            for (j = 1; j <= nclass; ++j) V(wr, j) = V(tclasspop, j);
            ntie = 1;
            for (nsp = ndstart; nsp <= ndend - 1; ++nsp) {
                nc = A(mvar, nsp);
                u = V(win, nc);
                k = V(cl, nc);
                rln = rln + u * (2 * V(wl, k) + u);
                rrn = rrn + u * (-2 * V(wr, k) + u);
                rld = rld + u;
                rrd = rrd - u;
                V(wl, k) = V(wl, k) + u;
                V(wr, k) = V(wr, k) - u;
                if (B(mvar, nc) < B(mvar, A(mvar, nsp + 1))) {
                    /* If neither node is empty, check the split. */
                    if ((rrd < rld ? rrd : rld) > 1.0e-5) {
                        crit = (rln / rld) + (rrn / rrd);
                        if (crit > critmax) {
                            *nbest = nsp;
                            critmax = crit;
                            *msplit = mvar;
                        }
                        /* Break ties at random.  Note that this runs after
                           the update above, exactly as in the Fortran, so a
                           strict improvement also lands here and draws. */
                        if (crit == critmax) {
                            ntie = ntie + 1;
                            if (unif_rand() < 1.0 / ntie) {
                                *nbest = nsp;
                                critmax = crit;
                                *msplit = mvar;
                            }
                        }
                    }
                }
            }
        } else {
            /* Split on a categorical predictor: decrease in impurity. */
            for (j = 0; j < nclass * 32; ++j) tclasscat[j] = 0.0;
            for (nsp = ndstart; nsp <= ndend; ++nsp) {
                nc = V(ncase, nsp);
                l = A(mvar, V(ncase, nsp));
                TCLASSCAT(V(cl, nc), l) = TCLASSCAT(V(cl, nc), l) + V(win, nc);
            }
            nnz = 0;
            for (i = 1; i <= lcat; ++i) {
                su = 0.0;
                for (j = 1; j <= nclass; ++j) su += TCLASSCAT(j, i);
                V(dn, i) = su;
                if (su > 0) nnz = nnz + 1;
            }
            nhit = 0;
            if (nnz > 1) {
                if (nclass == 2 && lcat > ncmax) {
                    catmaxb(&pdo, tclasscat, tclasspop, &nclass, &lcat,
                            nbest, &critmax, &nhit, dn);
                } else {
                    catmax(&pdo, tclasscat, tclasspop, &nclass, &lcat,
                           nbest, &critmax, &nhit, &maxcat, &ncmax, &ncsplit);
                }
                if (nhit == 1) *msplit = mvar;
            }
        }
    }
    if (critmax < -1.0e10 || *msplit == 0) *jstat = -1;
    *decsplit = critmax - crit0;
}


/* ------------------------------------------------------------------ *
 *  MYUNPACK
 *
 *  npack is a long integer.  Returns icat, zeroes and ones corresponding to
 *  the coefficients in the binary expansion of npack.
 * ------------------------------------------------------------------ */
static void myunpack(int l, int npack, int *icat) {
    int j, k, n;
    for (j = 1; j <= 32; ++j) V(icat, j) = 0;
    n = npack;
    V(icat, 1) = n % 2;
    for (k = 2; k <= l; ++k) {
        n = (n - V(icat, k - 1)) / 2;
        V(icat, k) = n % 2;
    }
}


/* ------------------------------------------------------------------ *
 *  MOVEDATA
 *
 *  Based on the best split, the data in the part of the a matrix
 *  corresponding to the current node is moved left if it belongs to the left
 *  child and right if it belongs to the right child.
 * ------------------------------------------------------------------ */
static void movedata(int *a, int *ta, int mdim, int nsample, int ndstart,
                     int ndend, int *idmove, int *ncase, int msplit,
                     int *cat, int nbest, int *ndendl) {
    int icat[32];
    int nsp, nc, l, msh, k, n, ih;

    /* compute idmove = indicator of case nos. going left */
    if (V(cat, msplit) == 1) {
        for (nsp = ndstart; nsp <= nbest; ++nsp) {
            nc = A(msplit, nsp);
            V(idmove, nc) = 1;
        }
        for (nsp = nbest + 1; nsp <= ndend; ++nsp) {
            nc = A(msplit, nsp);
            V(idmove, nc) = 0;
        }
        *ndendl = nbest;
    } else {
        *ndendl = ndstart - 1;
        l = V(cat, msplit);
        myunpack(l, nbest, icat);
        for (nsp = ndstart; nsp <= ndend; ++nsp) {
            nc = V(ncase, nsp);
            if (V(icat, A(msplit, nc)) == 1) {
                V(idmove, nc) = 1;
                *ndendl = *ndendl + 1;
            } else {
                V(idmove, nc) = 0;
            }
        }
    }

    /* shift case nos. right and left for numerical variables */
    for (msh = 1; msh <= mdim; ++msh) {
        if (V(cat, msh) == 1) {
            k = ndstart - 1;
            for (n = ndstart; n <= ndend; ++n) {
                ih = A(msh, n);
                if (V(idmove, ih) == 1) {
                    k = k + 1;
                    V(ta, k) = A(msh, n);
                }
            }
            for (n = ndstart; n <= ndend; ++n) {
                ih = A(msh, n);
                if (V(idmove, ih) == 0) {
                    k = k + 1;
                    V(ta, k) = A(msh, n);
                }
            }
            for (k = ndstart; k <= ndend; ++k) A(msh, k) = V(ta, k);
        }
    }

    /* The original has a block here guarded by `ndo = 0; if (ndo .eq. 1)`,
       i.e. permanently disabled.  It is omitted. */

    /* compute case nos. for right and left nodes */
    if (V(cat, msplit) == 1) {
        for (n = ndstart; n <= ndend; ++n) V(ncase, n) = A(msplit, n);
    } else {
        k = ndstart - 1;
        for (n = ndstart; n <= ndend; ++n) {
            if (V(idmove, V(ncase, n)) == 1) {
                k = k + 1;
                V(ta, k) = V(ncase, n);
            }
        }
        for (n = ndstart; n <= ndend; ++n) {
            if (V(idmove, V(ncase, n)) == 0) {
                k = k + 1;
                V(ta, k) = V(ncase, n);
            }
        }
        for (k = ndstart; k <= ndend; ++k) V(ncase, k) = V(ta, k);
    }
}


/* ------------------------------------------------------------------ *
 *  BUILDTREE
 *
 *  Repeated calls to findbestsplit and movedata.  ncur is the total number of
 *  nodes to date.  nodestatus(k) = 1 if the kth node has been split, 2 if the
 *  node exists but has not yet been split, -1 if the node is terminal.  A node
 *  is terminal if its size is below a threshold, if it is all one class, or if
 *  all the x-values are equal.  If node k is split, its children are numbered
 *  ncur+1 (left) and ncur+2 (right).
 * ------------------------------------------------------------------ */
void buildtree(int *a, int *b, int *cl, int *cat, int *maxcat, int *mdim_,
               int *nsample_, int *nclass_, int *treemap, int *bestvar,
               int *bestsplit, int *bestsplitnext, double *tgini,
               int *nodestatus, int *nodepop, int *nodestart,
               double *classpop, double *tclasspop, double *tclasscat,
               int *ta, int *nrnodes_, int *idmove, int *ndsize_,
               int *ncase, int *mtry_, int *iv, int *nodeclass,
               int *ndbigtree, double *win, double *wr, double *wl,
               int *mred_, int *nuse_, int *mind, double *decsplitarr) {
    const int mdim = *mdim_, nsample = *nsample_, nclass = *nclass_;
    const int nrnodes = *nrnodes_, ndsize = *ndsize_, mtry = *mtry_;
    const int mred = *mred_, nuse = *nuse_;

    double popt1, popt2, pp, decsplit;
    int msplit, ntie, ncur, kbuild, ndstart, ndend, jstat, nbest, ndendl;
    int j, k, n, nc, kn;

    msplit = 0;
    for (j = 0; j < nrnodes; ++j) {
        nodestatus[j] = 0;
        nodestart[j] = 0;
        nodepop[j] = 0;
    }
    for (j = 0; j < nclass * nrnodes; ++j) classpop[j] = 0.0;

    for (j = 1; j <= nclass; ++j) CLASSPOP(j, 1) = V(tclasspop, j);
    ncur = 1;
    V(nodestart, 1) = 1;
    V(nodepop, 1) = nuse;
    V(nodestatus, 1) = 2;

    /* start main loop */
    for (kbuild = 1; kbuild <= nrnodes; ++kbuild) {
        if (kbuild > ncur) break;
        if (V(nodestatus, kbuild) != 2) continue;

        /* initialize for next call to findbestsplit */
        ndstart = V(nodestart, kbuild);
        ndend = ndstart + V(nodepop, kbuild) - 1;
        for (j = 1; j <= nclass; ++j) V(tclasspop, j) = CLASSPOP(j, kbuild);
        jstat = 0;
        decsplit = 0.0;
        nbest = 0;

        findbestsplit(a, b, cl, mdim, nsample, nclass, cat, *maxcat,
                      ndstart, ndend, tclasspop, tclasscat, &msplit,
                      &decsplit, &nbest, ncase, &jstat, mtry, win, wr, wl,
                      mred, mind);
        if (jstat == -1) {
            V(nodestatus, kbuild) = -1;
            continue;
        } else {
            V(bestvar, kbuild) = msplit;
            V(iv, msplit) = 1;
            if (decsplit < 0.0) decsplit = 0.0;
            V(tgini, msplit) = V(tgini, msplit) + decsplit;
            if (V(cat, msplit) == 1) {
                V(bestsplit, kbuild) = A(msplit, nbest);
                V(bestsplitnext, kbuild) = A(msplit, nbest + 1);
            } else {
                V(bestsplit, kbuild) = nbest;
                V(bestsplitnext, kbuild) = 0;
            }
            V(decsplitarr, kbuild) = decsplit;
        }

        movedata(a, ta, mdim, nsample, ndstart, ndend, idmove, ncase,
                 msplit, cat, nbest, &ndendl);

        /* left node no. = ncur+1, right node no. = ncur+2 */
        V(nodepop, ncur + 1) = ndendl - ndstart + 1;
        V(nodepop, ncur + 2) = ndend - ndendl;
        V(nodestart, ncur + 1) = ndstart;
        V(nodestart, ncur + 2) = ndendl + 1;

        /* find class populations in both nodes */
        for (n = ndstart; n <= ndendl; ++n) {
            nc = V(ncase, n);
            j = V(cl, nc);
            CLASSPOP(j, ncur + 1) = CLASSPOP(j, ncur + 1) + V(win, nc);
        }
        for (n = ndendl + 1; n <= ndend; ++n) {
            nc = V(ncase, n);
            j = V(cl, nc);
            CLASSPOP(j, ncur + 2) = CLASSPOP(j, ncur + 2) + V(win, nc);
        }

        /* check on nodestatus */
        V(nodestatus, ncur + 1) = 2;
        V(nodestatus, ncur + 2) = 2;
        if (V(nodepop, ncur + 1) <= ndsize) V(nodestatus, ncur + 1) = -1;
        if (V(nodepop, ncur + 2) <= ndsize) V(nodestatus, ncur + 2) = -1;
        popt1 = 0.0;
        popt2 = 0.0;
        for (j = 1; j <= nclass; ++j) {
            popt1 += CLASSPOP(j, ncur + 1);
            popt2 += CLASSPOP(j, ncur + 2);
        }
        for (j = 1; j <= nclass; ++j) {
            if (CLASSPOP(j, ncur + 1) == popt1) V(nodestatus, ncur + 1) = -1;
            if (CLASSPOP(j, ncur + 2) == popt2) V(nodestatus, ncur + 2) = -1;
        }

        TREEMAP(1, kbuild) = ncur + 1;
        TREEMAP(2, kbuild) = ncur + 2;
        V(nodestatus, kbuild) = 1;
        ncur = ncur + 2;
        if (ncur >= nrnodes) break;
    }

    *ndbigtree = nrnodes;
    for (k = nrnodes; k >= 1; --k) {
        if (V(nodestatus, k) == 0) *ndbigtree = *ndbigtree - 1;
        if (V(nodestatus, k) == 2) V(nodestatus, k) = -1;
    }

    /* form prediction in terminal nodes */
    for (kn = 1; kn <= *ndbigtree; ++kn) {
        if (V(nodestatus, kn) == -1) {
            pp = 0.0;
            ntie = 1;
            for (j = 1; j <= nclass; ++j) {
                if (CLASSPOP(j, kn) > pp) {
                    V(nodeclass, kn) = j;
                    pp = CLASSPOP(j, kn);
                }
                /* Break ties at random.  As in findbestsplit, this follows
                   the update above and so also fires on a strict maximum. */
                if (CLASSPOP(j, kn) == pp) {
                    ntie = ntie + 1;
                    if (unif_rand() < 1.0 / ntie) {
                        V(nodeclass, kn) = j;
                        pp = CLASSPOP(j, kn);
                    }
                }
            }
        }
    }
}
