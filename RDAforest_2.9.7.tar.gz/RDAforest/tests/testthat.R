library(testthat)
library(RDAforest)

test_check("RDAforest")
