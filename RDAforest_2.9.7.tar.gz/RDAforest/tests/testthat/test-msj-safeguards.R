## Distance-only input, mtry pairs for small predictor sets, and the report of
## dropped predictors that are correlated with retained ones.

sg_sim <- function(n = 70, seed = 1, np = 6) {
  set.seed(seed)
  D1 <- stats::rnorm(n); D2 <- stats::rnorm(n)
  X <- data.frame(D1 = D1, D2 = D2,
                  P1 = 0.95 * D1 + sqrt(1 - 0.95^2) * stats::rnorm(n))
  for (k in seq_len(np - 3)) X[[paste0("N", k)]] <- stats::rnorm(n)
  G <- matrix(stats::rnorm(n * 30), n, 30)
  G[, 1:10]  <- 0.8 * D1 + 0.6 * G[, 1:10]
  G[, 11:20] <- 0.8 * D2 + 0.6 * G[, 11:20]
  list(X = X, G = G, D = as.matrix(dist(G)))
}
q <- function(e) suppressMessages(e)

test_that("raw data matrices are refused, distances in any form accepted", {
  d <- sg_sim()
  for (f in list(mtrySelJack, ordinationJackknife))
    expect_error(f(d$G, d$X, nreps = 2, auto.sites = FALSE), "distance matrix")
  expect_error(mtrySelJack(as.data.frame(d$G[, 1:10]), d$X, auto.sites = FALSE),
               "as.matrix\\(dist\\(Y\\)\\)")
  ## a dist object gives exactly what its matrix form gives
  set.seed(3)
  a <- q(mtrySelJack(dist(d$G), d$X, nreps = 2, top.pcs = 2, ntrees = 60, auto.sites = FALSE))
  set.seed(3)
  b <- q(mtrySelJack(d$D, d$X, nreps = 2, top.pcs = 2, ntrees = 60, auto.sites = FALSE))
  expect_identical(a, b)
})

test_that("covariates work (the partial-RDA projection failure is gone)", {
  d <- sg_sim()
  cv <- cbind(stats::runif(70), stats::runif(70))
  set.seed(4)
  expect_no_error(q(mtrySelJack(d$D, d$X, covariates = cv, nreps = 2, top.pcs = 2,
                                ntrees = 60, auto.sites = FALSE)))
  set.seed(4)
  expect_no_error(q(ordinationJackknife(d$D, d$X, covariates = cv, nreps = 2, top.pcs = 2,
                                        ntrees = 60, auto.sites = FALSE)))
})

test_that("mtry pairs: adjusted for 3-5 predictors, unchanged above, refused below", {
  mp <- RDAforest:::.rdaf_mtry_pair
  expect_error(mp(2), "at least 3 predictors")
  expect_equal(mp(3), c(1, 2))
  expect_equal(mp(4), c(1, 3))
  expect_equal(mp(5), c(1, 3))
  expect_equal(mp(6), c(3, 4))
  expect_equal(mp(9), c(3, 6))
  expect_equal(mp(20), c(4, 9))
  expect_equal(mp(4, 2, 4), c(2, 4))                  # explicit values honoured
  expect_error(mp(8, 3, 3), "mintry < maxtry")
  expect_error(mp(4, 1, 5), "mintry < maxtry")
  d <- sg_sim(np = 4)
  set.seed(5)
  mm <- q(mtrySelJack(d$D, d$X, nreps = 3, top.pcs = 2, ntrees = 60, auto.sites = FALSE))
  expect_equal(unname(mm$mtry), c(1, 3))
  expect_error(mtrySelJack(d$D, d$X[, 1:2], auto.sites = FALSE), "at least 3")
})

test_that("dropped predictors correlated with kept ones are reported", {
  d <- sg_sim()
  set.seed(6)
  msgs <- capture_messages(mm <- mtrySelJack(d$D, d$X, nreps = 6, top.pcs = 2,
                                             ntrees = 150, auto.sites = FALSE))
  expect_true(all(c("D1", "D2") %in% mm$goodvars))
  expect_false("P1" %in% mm$goodvars)
  dp <- mm$dropped.pairs
  expect_s3_class(dp, "data.frame")
  expect_named(dp, c("dropped", "kept", "r", "importance", "prop.positive", "reason"))
  expect_true(any(dp$dropped == "P1" & dp$kept == "D1"))
  expect_true(all(abs(dp$r) >= 0.7))
  expect_true(all(!dp$dropped %in% mm$goodvars) && all(dp$kept %in% mm$goodvars))
  expect_true(any(grepl("P1 .* ~ D1", msgs)))
  ## switched off
  set.seed(6)
  mm2 <- q(mtrySelJack(d$D, d$X, nreps = 6, top.pcs = 2, ntrees = 150,
                       auto.sites = FALSE, report.cor = NULL))
  expect_equal(nrow(mm2$dropped.pairs), 0L)
  expect_identical(mm2$goodvars, mm$goodvars)
  ## a threshold above every correlation reports nothing
  set.seed(6)
  mm3 <- q(mtrySelJack(d$D, d$X, nreps = 6, top.pcs = 2, ntrees = 150,
                       auto.sites = FALSE, report.cor = 0.99))
  expect_equal(nrow(mm3$dropped.pairs), 0L)
})

test_that("Reselect recomputes and reports dropped pairs", {
  d <- sg_sim()
  set.seed(6)
  mm <- q(mtrySelJack(d$D, d$X, nreps = 6, top.pcs = 2, ntrees = 150, auto.sites = FALSE))
  expect_true(is.matrix(mm$cor.X))
  expect_equal(mm$report.cor, 0.7)
  ## the original cutoffs reproduce the original selection and report
  r1 <- q(Reselect(mm, prop.positive.cutoff = 0.333, importance.cutoff = 0.1))
  expect_identical(r1$goodvars, mm$goodvars)
  expect_identical(r1$dropped.pairs, mm$dropped.pairs)
  ## and the report is shown again
  msgs <- capture_messages(Reselect(mm, 0.333, 0.1))
  expect_true(any(grepl("P1 .* ~ D1", msgs)))
  ## a cutoff that lets P1 in removes it from the dropped list
  r2 <- q(Reselect(mm, prop.positive.cutoff = 0))
  expect_true("P1" %in% r2$goodvars)
  expect_false("P1" %in% r2$dropped.pairs$dropped)
  expect_true(all(!r2$dropped.pairs$dropped %in% r2$goodvars))
  expect_true(all(r2$dropped.pairs$kept %in% r2$goodvars))
  ## switched off, and the threshold carried from the original call
  expect_equal(nrow(Reselect(mm, 0.333, 0.1, report.cor = NULL)$dropped.pairs), 0L)
  set.seed(6)
  mm9 <- q(mtrySelJack(d$D, d$X, nreps = 6, top.pcs = 2, ntrees = 150,
                       auto.sites = FALSE, report.cor = 0.99))
  expect_equal(nrow(q(Reselect(mm9, 0.333, 0.1))$dropped.pairs), 0L)
  expect_true(nrow(q(Reselect(mm9, 0.333, 0.1, report.cor = 0.7))$dropped.pairs) > 0)
})

test_that("Reselect on an object without stored correlations", {
  d <- sg_sim()
  set.seed(6)
  mm <- q(mtrySelJack(d$D, d$X, nreps = 6, top.pcs = 2, ntrees = 150, auto.sites = FALSE))
  old <- mm; old$cor.X <- NULL; old$report.cor <- NULL
  expect_warning(r <- q(Reselect(old, 0.333, 0.1)), "pass the predictors as X=")
  expect_null(r$dropped.pairs)
  expect_identical(r$goodvars, mm$goodvars)
  r2 <- q(Reselect(old, 0.333, 0.1, X = d$X))
  expect_identical(r2$dropped.pairs, mm$dropped.pairs)
  expect_true(is.matrix(r2$cor.X))
})
