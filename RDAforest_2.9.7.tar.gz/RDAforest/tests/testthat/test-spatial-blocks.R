## Tests for building a blocking vector from spatial coordinates.

fake_latlon <- function(seed = 1) {
  set.seed(seed)
  ## six well-separated clumps of varying size
  n <- c(4, 6, 8, 10, 12, 14)
  lon <- unlist(mapply(function(k, c0) stats::rnorm(k, c0, 0.4),
                       n, c(-160, -140, -120, -100, -80, -60)))
  lat <- unlist(mapply(function(k, c0) stats::rnorm(k, c0, 0.4),
                       n, c(45, 55, 65, 50, 60, 45)))
  data.frame(lon = lon, lat = lat)
}

test_that("spatial_blocks returns one block per sample, all big enough", {
  ll <- fake_latlon()
  b <- spatial_blocks(ll, nblocks = 6, min.size = 4)
  expect_s3_class(b, "factor")
  expect_length(b, nrow(ll))
  expect_equal(nlevels(b), 6)
  expect_true(all(table(b) >= 4))
})

test_that("levels are ordered by block size, largest first", {
  ll <- fake_latlon()
  b <- spatial_blocks(ll, nblocks = 6, min.size = 4)
  sizes <- as.numeric(table(b))
  expect_false(is.unsorted(rev(sizes)))
  expect_equal(levels(b), paste0("block", 1:6))
})

test_that("min.size is enforced even when a plain cut would strand samples", {
  ## one far-flung outlier that a plain cut would put in a block of its own
  ll <- fake_latlon()
  ll <- rbind(ll, data.frame(lon = 0, lat = 5))
  b <- spatial_blocks(ll, nblocks = 6, min.size = 5)
  expect_true(all(table(b) >= 5))
  expect_equal(nlevels(b), 6)
})

test_that("blocks are geographically tight", {
  ll <- fake_latlon()
  b <- spatial_blocks(ll, nblocks = 6, min.size = 4)
  D <- as.matrix(gcd.dist(ll)$gcd.distances)
  within <- mean(unlist(lapply(levels(b), function(l) {
    i <- which(b == l); D[i, i][upper.tri(diag(length(i)))]
  })))
  overall <- mean(D[upper.tri(D)])
  expect_lt(within, overall / 3)
})

test_that("a pre-computed distance matrix can be supplied instead", {
  ll <- fake_latlon()
  d <- gcd.dist(ll)$gcd.distances
  expect_identical(spatial_blocks(ll, nblocks = 5, min.size = 4),
                   spatial_blocks(distances = d, nblocks = 5, min.size = 4))
  expect_error(spatial_blocks(nblocks = 5), "either latlon or distances")
})

test_that("impossible requests are refused", {
  ll <- fake_latlon()
  expect_error(spatial_blocks(ll, nblocks = 1), "at least 2")
  expect_error(spatial_blocks(ll, nblocks = 20, min.size = 10),
               "cannot make")
})

test_that("the result works as a blocked.resampling sites vector", {
  ll <- fake_latlon()
  b <- spatial_blocks(ll, nblocks = 6, min.size = 4)
  n <- nrow(ll)
  X <- data.frame(lon = ll$lon, lat = ll$lat, noise = stats::rnorm(n))
  y <- 0.1 * ll$lat + stats::rnorm(n)
  set.seed(1)
  fit <- rdaf_randomForest(x = X, y = y, ntree = 30, keep.inbag = TRUE,
                           sites = b, site.repeats = "blocked.resampling")
  ## two of the six blocks are withheld from each tree, and no drawn row
  ## ever comes from a withheld block
  nout <- apply(fit$inbag, 2, function(z) sum(tapply(z, b, max) == 0))
  expect_true(all(nout == 2))
})
