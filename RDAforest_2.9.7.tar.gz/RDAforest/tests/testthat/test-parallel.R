## Parallel replicates in mtrySelJack() and ordinationJackknife().

par_sim <- function(n = 60, seed = 1) {
  set.seed(seed)
  X <- data.frame(temp = stats::rnorm(n), depth = stats::runif(n),
                  noise = stats::rnorm(n), noise2 = stats::rnorm(n))
  Y <- data.frame(a = 2 * X$temp + stats::rnorm(n, 0, 0.5),
                  b = X$depth + stats::rnorm(n, 0, 0.5),
                  c = stats::rnorm(n))
  list(X = X, Y = Y)
}
q <- function(e) suppressMessages(e)

test_that("ncores is validated and capped at nreps", {
  expect_error(RDAforest:::.rdaf_check_ncores(0, 5), "1 or more")
  expect_error(RDAforest:::.rdaf_check_ncores("a", 5), "1 or more")
  expect_equal(RDAforest:::.rdaf_check_ncores(8, 3), 3L)
  expect_equal(RDAforest:::.rdaf_check_ncores(2.7, 10), 2L)
})

test_that("per-replicate streams leave the caller's generator as it was", {
  set.seed(5); k0 <- RNGkind()
  s <- RDAforest:::.rdaf_rep_seeds(4)
  expect_identical(RNGkind(), k0)
  expect_length(s, 4L)
  expect_false(identical(s[[1]], s[[2]]))
  ## the caller's stream advanced by exactly one draw
  x <- runif(1)
  set.seed(5); sample.int(.Machine$integer.max, 1L); expect_identical(runif(1), x)
})

test_that("mtrySelJack gives the same answer on any number of cores above one", {
  skip_on_os("windows")
  d <- par_sim()
  set.seed(21)
  a <- q(mtrySelJack(as.matrix(dist(d$Y)), d$X, nreps = 4, top.pcs = 2, ntrees = 80, auto.sites = FALSE, ncores = 2))
  set.seed(21)
  b <- q(mtrySelJack(as.matrix(dist(d$Y)), d$X, nreps = 4, top.pcs = 2, ntrees = 80, auto.sites = FALSE, ncores = 3))
  expect_identical(a, b)
})

test_that("ordinationJackknife in parallel: same result on 2 or 3 cores and with sockets", {
  skip_on_os("windows")
  d <- par_sim()
  D <- as.matrix(dist(d$Y)); warm <- d$X; warm$temp <- warm$temp + 0.3
  f <- function(nc) { set.seed(22)
    q(ordinationJackknife(D, d$X, nreps = 3, top.pcs = 2, ntrees = 60, auto.sites = FALSE,
                          newX = list(now = d$X, warm = warm), extra = 0.5, ncores = nc)) }
  a <- f(2); b <- f(3)
  expect_identical(a$now$predictions.direct, b$now$predictions.direct)
  expect_identical(a$warm$predictions.turnover, b$warm$predictions.turnover)
  expect_identical(a$now$median.importance, b$now$median.importance)
  old <- options(RDAforest.parallel = "psock"); on.exit(options(old))
  p <- f(2)
  expect_identical(a$warm$predictions.direct, p$warm$predictions.direct)
})

test_that("socket clusters give what forking gives", {
  skip_on_cran()
  d <- par_sim()
  set.seed(23)
  a <- q(mtrySelJack(as.matrix(dist(d$Y)), d$X, nreps = 2, top.pcs = 2, ntrees = 60, auto.sites = FALSE, ncores = 2))
  old <- options(RDAforest.parallel = "psock"); on.exit(options(old))
  set.seed(23)
  b <- q(mtrySelJack(as.matrix(dist(d$Y)), d$X, nreps = 2, top.pcs = 2, ntrees = 60, auto.sites = FALSE, ncores = 2))
  expect_identical(a, b)
})

test_that("parallel runs leave the caller's generator kind and stream as they should be", {
  skip_on_os("windows")
  d <- par_sim()
  ## 3 replicates on 2 cores: the last batch holds one replicate, which
  ## mclapply() runs in this very process
  set.seed(40); k0 <- RNGkind()
  q(ordinationJackknife(as.matrix(dist(d$Y)), d$X, nreps = 3, top.pcs = 2, ntrees = 40,
                        auto.sites = FALSE, ncores = 2))
  expect_identical(RNGkind(), k0)
  x <- runif(1)
  set.seed(40); sample.int(.Machine$integer.max, 1L)
  expect_identical(runif(1), x)
})
