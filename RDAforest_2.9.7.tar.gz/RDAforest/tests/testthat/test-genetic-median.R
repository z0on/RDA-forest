## Tests for site.repeats = "genetic.median": the geometric median itself, the
## per-site collapse, and the way the three modes behave.

## ---------------------------------------------------------------------------
## the geometric median
## ---------------------------------------------------------------------------

## sum of Euclidean distances from a point to a cloud: the quantity the
## geometric median minimises
sumdist <- function(m, P) sum(sqrt(rowSums(sweep(as.matrix(P), 2, m)^2)))

test_that("geometric_median finds the minimum of the sum of distances", {
  set.seed(7)
  for (k in 1:5) {
    P <- matrix(stats::rnorm(20), 10, 2)
    g <- geometric_median(P)
    o <- stats::optim(colMeans(P), sumdist, P = P, method = "BFGS")
    ## Weiszfeld reaches the same optimum a general-purpose optimiser does
    expect_lt(sumdist(g, P) - o$value, 1e-8)
    expect_lt(sqrt(sum((g - o$par)^2)), 1e-3)
    ## and it beats the centroid, which minimises SQUARED distances
    expect_lte(sumdist(g, P), sumdist(colMeans(P), P))
  }
})

test_that("geometric_median works in more than two dimensions", {
  set.seed(8)
  P <- matrix(stats::rnorm(10 * 6), 10, 6)
  g <- geometric_median(P)
  expect_length(g, 6)
  o <- stats::optim(colMeans(P), sumdist, P = P, method = "BFGS")
  expect_lt(sumdist(g, P) - o$value, 1e-8)
})

test_that("geometric_median is robust where the mean is not", {
  P <- rbind(matrix(0, 20, 2), c(100, 100))     # one wild outlier
  g <- geometric_median(P)
  expect_lt(sqrt(sum(g^2)), 1e-6)               # stays with the bulk
  expect_gt(sqrt(sum(colMeans(P)^2)), 4)        # the mean is dragged away
})

test_that("geometric_median handles the degenerate cases", {
  expect_equal(geometric_median(matrix(c(3, 4), 1, 2)), c(3, 4))
  ## two points: any point on the segment is optimal; the midpoint is returned
  expect_equal(geometric_median(rbind(c(0, 0), c(2, 0))), c(1, 0))
  ## one dimension is the ordinary median
  expect_equal(geometric_median(matrix(c(1, 2, 3, 100), ncol = 1)), 2.5)
  ## landing exactly on a data point is the case Weiszfeld cannot weight
  expect_equal(geometric_median(rbind(c(0, 0), c(0, 0), c(5, 5))), c(0, 0),
               tolerance = 1e-6)
  expect_error(geometric_median(matrix(c(1, NA), 1, 2)), "missing")
  expect_error(geometric_median(matrix("a", 1, 1)), "numeric")
})

## ---------------------------------------------------------------------------
## the per-site collapse
## ---------------------------------------------------------------------------

test_that("genetic_medians returns one row per site, in level order", {
  set.seed(9)
  Y <- data.frame(MDS1 = stats::rnorm(30), MDS2 = stats::rnorm(30))
  sites <- rep(c("reefB", "reefA", "reefC"), each = 10)
  g <- genetic_medians(Y, sites)
  expect_equal(nrow(g), 3L)
  expect_equal(rownames(g), c("reefA", "reefB", "reefC"))
  expect_equal(names(g), names(Y))
  ## each row is the geometric median of its own site, using BOTH coordinates
  expect_equal(unname(unlist(g["reefA", ])),
               unname(geometric_median(Y[sites == "reefA", ])))
  expect_error(genetic_medians(Y, sites[1:10]), "one entry per row")
})

test_that("the collapse uses all supplied coordinates jointly", {
  ## a point that is median on each axis separately need not be the geometric
  ## median of the cloud: check we are not just taking column medians
  set.seed(10)
  Y <- data.frame(a = c(0, 0, 3, 4, 10), b = c(0, 5, 0, 8, 10))
  g <- unlist(genetic_medians(Y, rep("s", 5)))
  colmed <- apply(Y, 2, stats::median)
  expect_lte(sumdist(g, Y), sumdist(colmed, Y))
})

test_that("predictors constant within a site survive the collapse", {
  set.seed(11)
  sites <- rep(paste0("s", 1:5), each = 6)
  X <- data.frame(temp = rep(stats::rnorm(5), each = 6),
                  depth = rep(stats::runif(5), each = 6))
  Y <- data.frame(p1 = stats::rnorm(30), p2 = stats::rnorm(30))
  coll <- RDAforest:::.rdaf_collapse_sites(X, Y, factor(sites))
  expect_equal(nrow(coll$X), 5L)
  expect_equal(coll$X$temp, as.numeric(tapply(X$temp, sites, function(z) z[1])))
  expect_equal(nrow(coll$Y), 5L)
})

test_that("predictors that vary within a site are averaged, with a warning", {
  sites <- factor(rep(paste0("s", 1:5), each = 6))
  X <- data.frame(v = stats::runif(30))
  Y <- data.frame(p1 = stats::rnorm(30))
  expect_warning(coll <- RDAforest:::.rdaf_collapse_sites(X, Y, sites),
                 "constant within a site")
  expect_equal(coll$X$v, as.numeric(tapply(X$v, sites, mean)))
})

## ---------------------------------------------------------------------------
## the modes, end to end
## ---------------------------------------------------------------------------

make_sites <- function(nsite = 20, per = 8, seed = 1) {
  set.seed(seed)
  sites <- factor(rep(paste0("site", seq_len(nsite)), each = per))
  n <- length(sites); idx <- as.integer(sites)
  E <- matrix(stats::rnorm(nsite * 3), nsite, 3)
  colnames(E) <- c("driver", "noise1", "noise2")
  u <- stats::rnorm(nsite)
  Y <- data.frame(
    pc1 = E[idx, 1] + u[idx] + stats::rnorm(n, 0, 0.5),
    pc2 = E[idx, 2] + stats::rnorm(n, 0, 0.5))
  list(X = as.data.frame(E[idx, , drop = FALSE]), Y = Y, sites = sites,
       Xsite = as.data.frame(E))
}

test_that("genetic.median fits one row per site", {
  d <- make_sites()
  set.seed(12)
  gf <- makeGF_simple(d$Y, d$X, ntrees = 60, sites = d$sites,
                      site.repeats = "genetic.median")
  expect_equal(nrow(gf$X), 20L)
  expect_equal(nrow(gf$Y), 20L)
  expect_equal(gf$site.repeats, "genetic.median")
  ## the fitted Y is exactly the per-site geometric medians
  expect_equal(unname(as.matrix(gf$Y)),
               unname(as.matrix(genetic_medians(d$Y, d$sites)[, names(d$Y)])))
  ## and the predictors are the site-level values
  expect_equal(unname(as.matrix(gf$X)), unname(as.matrix(d$Xsite)))
})

test_that("direct.use is exactly the same as supplying no sites", {
  ## auto.sites must be off in the reference arm: these predictors repeat, so
  ## the automatic check would otherwise detect sites and collapse them
  d <- make_sites()
  set.seed(13); a <- makeGF_simple(d$Y, d$X, ntrees = 60, auto.sites = FALSE)
  set.seed(13); b <- makeGF_simple(d$Y, d$X, ntrees = 60, sites = d$sites,
                                   site.repeats = "direct.use")
  expect_equal(a$result, b$result)
  expect_equal(a$overall.imp, b$overall.imp)
  expect_equal(b$site.repeats, "direct.use")
})

test_that("genetic.median is the default when sites are given", {
  d <- make_sites()
  set.seed(14); a <- makeGF_simple(d$Y, d$X, ntrees = 60, sites = d$sites)
  set.seed(14); b <- makeGF_simple(d$Y, d$X, ntrees = 60, sites = d$sites,
                                   site.repeats = "genetic.median")
  expect_equal(a$result, b$result)
  expect_equal(nrow(a$X), 20L)
})

test_that("rdaf_randomForest collapses with the univariate median", {
  d <- make_sites()
  set.seed(15)
  fit <- rdaf_randomForest(x = d$X, y = d$Y$pc1, ntree = 100,
                           sites = d$sites, site.repeats = "genetic.median")
  expect_equal(length(fit$predicted), 20L)
  expect_equal(fit$site.repeats, "genetic.median")
  ## same fit as collapsing by hand beforehand
  ys <- as.numeric(tapply(d$Y$pc1, d$sites, stats::median))
  set.seed(15)
  ref <- rdaf_randomForest(x = d$Xsite, y = ys, ntree = 100)
  expect_equal(fit$mse, ref$mse)
})

test_that("genetic.median refuses a factor response", {
  d <- make_sites()
  expect_error(
    rdaf_randomForest(x = d$X, y = factor(d$Y$pc1 > 0), ntree = 10,
                      sites = d$sites, site.repeats = "genetic.median"),
    "numeric response")
})

test_that("an unknown site.repeats is rejected", {
  d <- make_sites()
  expect_error(makeGF_simple(d$Y, d$X, ntrees = 10, sites = d$sites,
                             site.repeats = "median"), "arg")
})

test_that("predict_rf honours site.repeats", {
  d <- make_sites()
  newX <- d$Xsite
  set.seed(16)
  p <- predict_rf(d$Y, d$X, newX, sites = d$sites,
                  site.repeats = "genetic.median", ntree = 60)
  expect_equal(nrow(p$preds), nrow(newX))
  expect_true(all(is.finite(as.matrix(p$preds))))
})

test_that("both honest modes suppress a site-tagging noise predictor", {
  ## Predictors are site-level, so a noise predictor can single out a site with
  ## an unusual mean.  With the individuals used directly that pays off, because
  ## a held-out individual's site-mates are in the training set.
  set.seed(17)
  nsite <- 30; per <- 8
  sites <- factor(rep(paste0("s", seq_len(nsite)), each = per))
  n <- length(sites); idx <- as.integer(sites)
  E <- scale(matrix(stats::rnorm(nsite * 3), nsite, 3))
  colnames(E) <- c("driver", "noise1", "noise2")
  u <- stats::rnorm(nsite)
  Y <- data.frame(pc1 = sqrt(0.6) * E[idx, 1] + sqrt(0.2) * u[idx] +
                        sqrt(0.2) * stats::rnorm(n),
                  pc2 = stats::rnorm(n))
  X <- as.data.frame(E[idx, , drop = FALSE])

  noise_share <- function(g) {
    imp <- rdaf_importance(g, type = "Weighted")
    imp <- imp[colnames(E)]; imp[is.na(imp)] <- 0
    sum(imp[2:3]) / sum(imp[1])
  }
  set.seed(18); direct <- makeGF_simple(Y, X, ntrees = 300, sites = sites,
                                        site.repeats = "direct.use")
  set.seed(18); median <- makeGF_simple(Y, X, ntrees = 300, sites = sites,
                                        site.repeats = "genetic.median")
  set.seed(18); blocked <- makeGF_simple(Y, X, ntrees = 300, sites = sites,
                                         site.repeats = "blocked.resampling")
  expect_gt(noise_share(direct), noise_share(median))
  expect_gt(noise_share(direct), noise_share(blocked))
})
