## The vendored engine must reproduce extendedForest / gradientForest exactly
## when no blocking is requested.  These tests are skipped when the original
## packages are not installed.

test_that("rdaf_randomForest reproduces extendedForest::randomForest", {
  skip_if_not_installed("extendedForest")
  set.seed(1)
  n <- 80
  X <- as.data.frame(matrix(stats::rnorm(n * 5), n, 5))
  names(X) <- paste0("v", 1:5)
  y <- 2 * X$v1 - X$v2 + stats::rnorm(n)

  set.seed(99)
  a <- extendedForest::randomForest(x = X, y = y, ntree = 80,
                                    importance = TRUE, keep.inbag = TRUE,
                                    keep.forest = TRUE)
  set.seed(99)
  b <- rdaf_randomForest(x = X, y = y, ntree = 80, importance = TRUE,
                         keep.inbag = TRUE, keep.forest = TRUE)

  expect_identical(a$mse, b$mse)
  expect_identical(a$rsq, b$rsq)
  expect_identical(a$predicted, b$predicted)
  expect_identical(unname(a$importance), unname(b$importance))
  expect_identical(a$inbag, b$inbag)
  expect_identical(a$forest, b$forest)

  ## and with sampling without replacement
  set.seed(98)
  c1 <- extendedForest::randomForest(x = X, y = y, ntree = 40,
                                     replace = FALSE, sampsize = 50)
  set.seed(98)
  c2 <- rdaf_randomForest(x = X, y = y, ntree = 40, replace = FALSE,
                          sampsize = 50)
  expect_identical(c1$mse, c2$mse)
})

test_that("rdaf_gradientForest reproduces gradientForest::gradientForest", {
  skip_if_not_installed("gradientForest")
  set.seed(2)
  n <- 80
  X <- as.data.frame(matrix(stats::rnorm(n * 5), n, 5))
  names(X) <- paste0("v", 1:5)
  Y <- data.frame(pc1 = 2 * X$v1 + stats::rnorm(n),
                  pc2 = X$v3 + stats::rnorm(n),
                  pc3 = stats::rnorm(n))
  dat <- cbind(X, Y)

  set.seed(77)
  a <- gradientForest::gradientForest(dat, names(X), names(Y), ntree = 80,
                                      maxLevel = 2, corr.threshold = 0.25,
                                      trace = FALSE)
  set.seed(77)
  b <- rdaf_gradientForest(dat, names(X), names(Y), ntree = 80,
                           maxLevel = 2, corr.threshold = 0.25, trace = FALSE)

  expect_identical(a$imp.rsq, b$imp.rsq)
  expect_identical(a$overall.imp, b$overall.imp)
  expect_identical(a$overall.imp2, b$overall.imp2)
  expect_identical(a$result, b$result)
  expect_identical(a$res, b$res)
  expect_identical(gradientForest::importance(a, type = "Weighted"),
                   rdaf_importance(b, type = "Weighted"))
  expect_identical(unclass(predict(a, X)), unclass(predict(b, X)))
  expect_identical(gradientForest::cumimp(a, "v1"), rdaf_cumimp(b, "v1"))
})
