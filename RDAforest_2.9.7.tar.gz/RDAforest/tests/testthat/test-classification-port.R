## The classification tree builder is a C translation of the original rfsub.f
## (see src/rfsub.c), so that RDAforest installs without a Fortran compiler.
## These tests pin it to the Fortran it replaces: with the same seed every
## result must be identical, not merely close.  Skipped when extendedForest,
## which still uses the Fortran, is not installed.

cdata <- function(n = 150, seed = 11) {
  set.seed(seed)
  X <- data.frame(v1 = stats::rnorm(n), v2 = stats::rnorm(n),
                  v3 = stats::rnorm(n), v4 = stats::rnorm(n),
                  v5 = stats::rnorm(n))
  lin <- 1.5 * X$v1 - X$v2 + 0.5 * X$v3
  list(X = X, lin = lin,
       y2 = factor(ifelse(lin + stats::rnorm(n) > 0, "hi", "lo")),
       y4 = cut(lin + stats::rnorm(n, 0, 0.5), 4, labels = paste0("c", 1:4)))
}

catdata <- function(n = 150, seed = 12) {
  set.seed(seed)
  X <- data.frame(
    num1 = stats::rnorm(n),
    f3 = factor(sample(letters[1:3], n, TRUE)),
    f8 = factor(sample(letters[1:8], n, TRUE)),
    f15 = factor(sample(LETTERS[1:15], n, TRUE)),   # > ncmax: exercises catmaxb
    num2 = stats::rnorm(n))
  eff <- c(a = -1.5, b = 0, c = 1.5)[as.character(X$f3)]
  list(X = X,
       y2 = factor(ifelse(eff + X$num1 + stats::rnorm(n) > 0, "hi", "lo")),
       y4 = cut(eff + X$num1 + stats::rnorm(n, 0, 0.4), 4,
                labels = paste0("c", 1:4)))
}

expect_same_forest <- function(seed, x, y, ...) {
  set.seed(seed); a <- extendedForest::randomForest(x = x, y = y, ...)
  set.seed(seed); b <- rdaf_randomForest(x = x, y = y, ...)
  expect_identical(a$err.rate, b$err.rate)
  expect_identical(unname(a$predicted), unname(b$predicted))
  expect_identical(unname(a$votes), unname(b$votes))
  expect_identical(a$confusion, b$confusion)
  expect_identical(unname(a$oob.times), unname(b$oob.times))
  expect_identical(unname(a$importance), unname(b$importance))
  if (!is.null(a$forest)) {
    expect_identical(a$forest$treemap, b$forest$treemap)
    expect_identical(a$forest$nodestatus, b$forest$nodestatus)
    expect_identical(a$forest$bestvar, b$forest$bestvar)
    expect_identical(a$forest$nodepred, b$forest$nodepred)
    expect_identical(a$forest$xbestsplit, b$forest$xbestsplit)
    expect_identical(a$forest$ndbigtree, b$forest$ndbigtree)
    expect_identical(a$forest$nodeImprove, b$forest$nodeImprove)
  }
  invisible(list(a = a, b = b))
}

test_that("the package links no Fortran runtime", {
  so <- system.file("libs", package = "RDAforest")
  so <- list.files(so, pattern = "RDAforest\\.(so|dll|dylib)$",
                   full.names = TRUE, recursive = TRUE)
  skip_if(!length(so), "shared object not found")
  skip_on_os(c("windows", "solaris"))
  lister <- if (Sys.info()[["sysname"]] == "Darwin") "otool -L" else "ldd"
  out <- tryCatch(system(paste(lister, shQuote(so[1])), intern = TRUE,
                         ignore.stderr = TRUE),
                  error = function(e) NULL, warning = function(w) NULL)
  skip_if(is.null(out), "could not list shared object dependencies")
  expect_false(any(grepl("gfortran|quadmath", out)))
})

test_that("classification matches the Fortran on numeric predictors", {
  skip_if_not_installed("extendedForest")
  d <- cdata()
  expect_same_forest(101, d$X, d$y2, ntree = 200, importance = TRUE,
                     keep.forest = TRUE, keep.inbag = TRUE)
  expect_same_forest(102, d$X, d$y4, ntree = 200, importance = TRUE,
                     keep.forest = TRUE)
  expect_same_forest(103, d$X, d$y2, ntree = 150, mtry = 1,
                     importance = TRUE, keep.forest = TRUE)
  expect_same_forest(104, d$X, d$y2, ntree = 150, nodesize = 10,
                     importance = TRUE, keep.forest = TRUE)
})

test_that("classification matches the Fortran under the sampling options", {
  skip_if_not_installed("extendedForest")
  d <- cdata()
  expect_same_forest(105, d$X, d$y2, ntree = 150, replace = FALSE,
                     sampsize = 90, importance = TRUE, keep.forest = TRUE)
  expect_same_forest(106, d$X, d$y2, ntree = 150, classwt = c(2, 1),
                     cutoff = c(0.6, 0.4), importance = TRUE,
                     keep.forest = TRUE)
  expect_same_forest(107, d$X, d$y2, ntree = 150, strata = d$y2,
                     sampsize = c(40, 40), importance = TRUE,
                     keep.forest = TRUE)
})

test_that("proximity, local importance and conditional permutation match", {
  skip_if_not_installed("extendedForest")
  d <- cdata()
  r <- expect_same_forest(108, d$X, d$y2, ntree = 120, proximity = TRUE,
                          importance = TRUE, keep.forest = TRUE)
  expect_identical(unname(r$a$proximity), unname(r$b$proximity))
  r <- expect_same_forest(109, d$X, d$y4, ntree = 120, localImp = TRUE,
                          keep.forest = TRUE)
  expect_identical(unname(r$a$localImportance), unname(r$b$localImportance))
  expect_same_forest(110, d$X, d$y2, ntree = 150, importance = TRUE,
                     keep.forest = TRUE, maxLevel = 3,
                     corr.threshold = 0.25, keep.group = TRUE)
})

test_that("categorical predictors match, including the catmaxb branch", {
  ## this is the path through catmax, catmaxb and myunpack
  skip_if_not_installed("extendedForest")
  d <- catdata()
  expect_same_forest(201, d$X, d$y2, ntree = 200, importance = TRUE,
                     keep.forest = TRUE)
  expect_same_forest(202, d$X, d$y4, ntree = 200, importance = TRUE,
                     keep.forest = TRUE)
  expect_same_forest(203, d$X, d$y2, ntree = 150, mtry = 5,
                     importance = TRUE, keep.forest = TRUE)
})

test_that("tie-breaking consumes the RNG exactly as the Fortran did", {
  ## heavily tied predictors and a balanced response maximise the number of
  ## random draws spent on breaking ties; any drift shows up immediately
  skip_if_not_installed("extendedForest")
  X <- data.frame(a = rep(1:5, each = 30), b = rep(1:3, 50),
                  c = stats::rnorm(150))
  y <- factor(rep(c("x", "y"), 75))
  expect_same_forest(301, X, y, ntree = 200, importance = TRUE,
                     keep.forest = TRUE)
})

test_that("prediction and getTree match on a classification forest", {
  skip_if_not_installed("extendedForest")
  d <- catdata()
  set.seed(401)
  a <- extendedForest::randomForest(x = d$X, y = d$y4, ntree = 150,
                                    keep.forest = TRUE)
  set.seed(401)
  b <- rdaf_randomForest(x = d$X, y = d$y4, ntree = 150, keep.forest = TRUE)
  expect_identical(unname(predict(a, d$X)), unname(predict(b, d$X)))
  expect_identical(unname(predict(a, d$X, type = "prob")),
                   unname(predict(b, d$X, type = "prob")))
  expect_identical(unname(extendedForest::getTree(a, 1)),
                   unname(rdaf_getTree(b, 1)))
  expect_identical(unname(extendedForest::getTree(a, 150)),
                   unname(rdaf_getTree(b, 150)))
})

test_that("a classification gradient forest matches", {
  skip_if_not_installed("extendedForest")
  skip_if_not_installed("gradientForest")
  d <- cdata()
  dat <- cbind(d$X, data.frame(s1 = d$y2, s2 = d$y4))
  set.seed(601)
  a <- gradientForest::gradientForest(dat, names(d$X), c("s1", "s2"),
                                      ntree = 150, trace = FALSE)
  set.seed(601)
  b <- rdaf_gradientForest(dat, names(d$X), c("s1", "s2"), ntree = 150,
                           trace = FALSE)
  expect_identical(a$imp.rsq, b$imp.rsq)
  expect_identical(a$res, b$res)
  expect_identical(gradientForest::importance(a, "Weighted"),
                   rdaf_importance(b, "Weighted"))
})

test_that("blocked OOB still holds for classification after the port", {
  d <- cdata()
  blocks <- rep(paste0("b", 1:10), each = 15)
  set.seed(701)
  f <- rdaf_randomForest(x = d$X, y = d$y2, ntree = 150, keep.inbag = TRUE,
                         importance = TRUE, sites = blocks,
                         site.repeats = "blocked.resampling")
  nout <- apply(f$inbag, 2, function(z) sum(tapply(z, blocks, max) == 0))
  expect_true(all(nout == 3))
  expect_true(is.finite(f$err.rate[150, "OOB"]))
})
