## Tests for the automatic detection of repeated sampling.

MSG  <- "multiple samples per site"
WARN <- "share a spatial location but have different environmental entries"

site_data <- function(nsite = 6, per = 5, coordnames = c("lon", "lat")) {
  set.seed(3)
  idx <- rep(seq_len(nsite), each = per)
  X <- data.frame(a = round(seq(-100, -95, length.out = nsite), 3)[idx],
                  b = round(seq(30, 40, length.out = nsite), 3)[idx],
                  temp = round(stats::rnorm(nsite), 4)[idx],
                  depth = round(stats::runif(nsite), 4)[idx])
  names(X)[1:2] <- coordnames
  n <- nrow(X)
  Y <- data.frame(pc1 = X$temp + stats::rnorm(n, 0, 0.4),
                  pc2 = X$depth + stats::rnorm(n, 0, 0.4))
  list(X = X, Y = Y, n = n, nsite = nsite)
}

## ---------------------------------------------------------------------------
## the three outcomes
## ---------------------------------------------------------------------------

test_that("repeated samples at shared coordinates are detected and reported", {
  d <- site_data()
  expect_message(det <- detect_sites(d$X), MSG)
  expect_equal(det$detected, "coords")
  expect_equal(det$site.repeats, "genetic.median")
  expect_equal(nlevels(det$sites), 6L)
  expect_true(all(table(det$sites) == 5))
})

test_that("data with no shared coordinates pass silently", {
  set.seed(4)
  X <- data.frame(lon = stats::rnorm(40), lat = stats::rnorm(40),
                  temp = stats::rnorm(40))
  expect_silent(det <- detect_sites(X))
  expect_null(det$sites)
  expect_equal(det$detected, "none")
  expect_equal(det$site.repeats, "direct.use")
})

test_that("shared coordinates with differing environments warn and go direct", {
  d <- site_data()
  d$X$temp[3] <- d$X$temp[3] + 1            # one sample out of step
  expect_warning(det <- detect_sites(d$X), WARN)
  expect_null(det$sites)
  expect_equal(det$detected, "mismatch")
  expect_equal(det$site.repeats, "direct.use")
})

test_that("identical rows are detected even with no coordinate columns", {
  d <- site_data(coordnames = c("v1", "v2"))   # nothing name-like
  expect_message(det <- detect_sites(d$X), MSG)
  expect_equal(det$detected, "rows")
  expect_equal(nlevels(det$sites), 6L)
})

test_that("coordinate columns are found under several spellings", {
  for (nm in list(c("lon", "lat"), c("Longitude", "Latitude"), c("x", "y"),
                  c("easting", "northing"), c("UTM_X", "UTM_Y"))) {
    d <- site_data(coordnames = nm)
    expect_message(det <- detect_sites(d$X), MSG, info = paste(nm, collapse = "/"))
    expect_equal(det$detected, "coords")
  }
})

test_that("coords can be named or supplied separately", {
  d <- site_data(coordnames = c("place1", "place2"))
  expect_message(det <- detect_sites(d$X, coords = c("place1", "place2")), MSG)
  expect_equal(det$detected, "coords")
  ## as a separate object, with the environment alone in X
  env <- d$X[c("temp", "depth")]
  ll <- d$X[c("place1", "place2")]
  expect_message(det2 <- detect_sites(env, coords = ll), MSG)
  expect_equal(det2$detected, "coords")
  expect_equal(nlevels(det2$sites), 6L)
  expect_error(detect_sites(env, coords = "nope"), "not found")
  expect_error(detect_sites(env, coords = ll[1:3, ]), "one row per sample")
})

test_that("quiet suppresses both the message and the warning", {
  d <- site_data()
  expect_silent(detect_sites(d$X, quiet = TRUE))
  d$X$temp[3] <- d$X$temp[3] + 1
  expect_silent(detect_sites(d$X, quiet = TRUE))
})

test_that("degenerate inputs are left alone", {
  expect_null(detect_sites(data.frame(a = 1:2, b = 1:2))$sites)      # n < 3
  ## every row the same place: there is only one site, nothing to collapse to
  expect_silent(det <- detect_sites(data.frame(lon = rep(1, 10),
                                               lat = rep(2, 10))))
  expect_null(det$sites)
})

## ---------------------------------------------------------------------------
## what the fitting functions do with it
## ---------------------------------------------------------------------------

test_that("makeGF_simple detects repeats and fits one row per site", {
  d <- site_data(nsite = 12, per = 6)
  set.seed(20)
  expect_message(gf <- makeGF_simple(d$Y, d$X, ntrees = 80), MSG)
  expect_equal(nrow(gf$X), 12L)
  expect_equal(gf$site.repeats, "genetic.median")
  ## identical to naming the sites by hand
  sites <- factor(rep(paste0("site", 1:12), each = 6),
                  levels = paste0("site", 1:12))
  set.seed(20)
  ref <- makeGF_simple(d$Y, d$X, ntrees = 80, sites = sites,
                       site.repeats = "genetic.median")
  expect_equal(gf$result, ref$result)
})

test_that("auto.sites = FALSE switches the check off", {
  d <- site_data(nsite = 12, per = 6)
  set.seed(21)
  expect_no_message(a <- makeGF_simple(d$Y, d$X, ntrees = 80,
                                      auto.sites = FALSE))
  expect_equal(nrow(a$X), d$n)
  expect_null(a$site.repeats)
  ## and is the same fit as before the automatic check existed
  set.seed(21)
  b <- makeGF_simple(d$Y, d$X, ntrees = 80, sites = NULL, auto.sites = FALSE)
  expect_equal(a$result, b$result)
})

test_that("an explicit sites argument overrides detection", {
  d <- site_data(nsite = 12, per = 6)
  own <- factor(rep(c("A", "B", "C"), length.out = d$n))
  set.seed(22)
  expect_no_message(gf <- makeGF_simple(d$Y, d$X, ntrees = 80, sites = own,
                                       site.repeats = "direct.use"))
  expect_equal(nrow(gf$X), d$n)
  expect_equal(gf$site.repeats, "direct.use")
})

test_that("the mismatch warning leaves the analysis direct", {
  d <- site_data(nsite = 12, per = 6)
  d$X$temp[5] <- d$X$temp[5] + 1
  set.seed(23)
  expect_warning(gf <- makeGF_simple(d$Y, d$X, ntrees = 80), WARN)
  expect_equal(nrow(gf$X), d$n)
  expect_null(gf$site.repeats)
})

test_that("rdaf_randomForest detects repeats too", {
  d <- site_data(nsite = 12, per = 6)
  set.seed(24)
  expect_message(fit <- rdaf_randomForest(x = d$X, y = d$Y$pc1, ntree = 100),
                 MSG)
  expect_equal(length(fit$predicted), 12L)
  expect_equal(fit$site.repeats, "genetic.median")
})

test_that("the message is issued once, not once per response axis", {
  d <- site_data(nsite = 12, per = 6)
  set.seed(25)
  msgs <- capture_messages(makeGF_simple(d$Y, d$X, ntrees = 60))
  expect_equal(sum(grepl(MSG, msgs)), 1L)
})

test_that("a jackknife reports once, not once per replicate", {
  d <- site_data(nsite = 14, per = 5)
  set.seed(26)
  msgs <- capture_messages(
    oj <- ordinationJackknife(as.matrix(dist(d$Y)), d$X, nreps = 3, top.pcs = 2, ntrees = 60))
  expect_equal(sum(grepl(MSG, msgs)), 1L)
})

## ---------------------------------------------------------------------------
## detection supplies the SITES, never the MODE
## ---------------------------------------------------------------------------

test_that("an explicit site.repeats survives auto-detection", {
  d <- site_data(nsite = 12, per = 6)
  sites <- factor(rep(paste0("site", 1:12), each = 6),
                  levels = paste0("site", 1:12))

  ## blocked.resampling: every individual kept, sites used as blocks
  set.seed(30)
  expect_message(b <- makeGF_simple(d$Y, d$X, ntrees = 80,
                                    site.repeats = "blocked.resampling"),
                 "blocked.resampling")
  expect_equal(nrow(b$X), d$n)
  expect_equal(b$site.repeats, "blocked.resampling")
  set.seed(30)
  ref <- makeGF_simple(d$Y, d$X, ntrees = 80, sites = sites,
                       site.repeats = "blocked.resampling")
  expect_equal(b$result, ref$result)

  ## direct.use: individuals used as they are
  set.seed(31)
  expect_message(u <- makeGF_simple(d$Y, d$X, ntrees = 80,
                                    site.repeats = "direct.use"),
                 "direct.use")
  expect_equal(nrow(u$X), d$n)
  expect_equal(u$site.repeats, "direct.use")
  set.seed(31)
  ref2 <- makeGF_simple(d$Y, d$X, ntrees = 80, auto.sites = FALSE)
  expect_equal(u$result, ref2$result)

  ## and naming the default explicitly still gives the median
  set.seed(32)
  m <- makeGF_simple(d$Y, d$X, ntrees = 80, site.repeats = "genetic.median")
  expect_equal(nrow(m$X), 12L)
})

test_that("the detection message never names a mode that was not used", {
  d <- site_data(nsite = 12, per = 6)
  set.seed(33)
  msgs <- capture_messages(makeGF_simple(d$Y, d$X, ntrees = 60,
                                         site.repeats = "blocked.resampling"))
  expect_false(any(grepl("genetic median", msgs)))
  expect_true(any(grepl('site.repeats = "blocked.resampling"', msgs, fixed = TRUE)))
})

test_that("rdaf_randomForest honours an explicit site.repeats too", {
  d <- site_data(nsite = 12, per = 6)
  set.seed(34)
  expect_message(f <- rdaf_randomForest(x = d$X, y = d$Y$pc1, ntree = 100,
                                        site.repeats = "blocked.resampling"),
                 "blocked.resampling")
  expect_equal(length(f$predicted), d$n)
  expect_equal(f$site.repeats, "blocked.resampling")
})

test_that("the jackknives honour an explicit site.repeats", {
  d <- site_data(nsite = 14, per = 5)
  set.seed(35)
  msgs <- capture_messages(
    oj <- ordinationJackknife(as.matrix(dist(d$Y)), d$X, nreps = 2, top.pcs = 2, ntrees = 60,
                              site.repeats = "blocked.resampling"))
  expect_equal(sum(grepl("blocked.resampling", msgs)), 1L)
  expect_false(any(grepl("genetic median", msgs)))
  set.seed(36)
  msgs2 <- capture_messages(
    mm <- mtrySelJack(as.matrix(dist(d$Y)), d$X, nreps = 2, top.pcs = 2, ntrees = 60,
                      site.repeats = "direct.use"))
  expect_equal(sum(grepl("direct.use", msgs2)), 1L)
})

test_that("the mismatch warning still fires when a mode was named", {
  d <- site_data(nsite = 12, per = 6)
  d$X$temp[5] <- d$X$temp[5] + 1
  set.seed(37)
  expect_warning(gf <- makeGF_simple(d$Y, d$X, ntrees = 80,
                                     site.repeats = "blocked.resampling"), WARN)
  expect_equal(nrow(gf$X), d$n)
  expect_null(gf$site.repeats)
})
