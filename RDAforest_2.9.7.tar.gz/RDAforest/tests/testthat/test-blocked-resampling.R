## Tests for site.repeats = "blocked.resampling".

make_data <- function(n = 90, p = 5, seed = 1) {
  set.seed(seed)
  X <- as.data.frame(matrix(stats::rnorm(n * p), n, p))
  names(X) <- paste0("v", seq_len(p))
  list(X = X, y = 2 * X$v1 - X$v2 + stats::rnorm(n))
}

test_that(".rdaf_check_blocks validates its input", {
  chk <- RDAforest:::.rdaf_check_blocks
  b <- rep(letters[1:5], each = 4)

  expect_equal(chk(NULL, 20)$n, 0L)

  ok <- chk(b, 20, 1/3)
  expect_equal(ok$n, 5L)
  expect_equal(ok$nhold, 2L)             # round(5/3) = 2
  expect_equal(sort(unique(ok$index)), 1:5)
  expect_length(ok$index, 20)

  expect_error(chk(b, 19), "one entry per row")
  expect_error(chk(rep("a", 20), 20), "at least two blocks")
  expect_error(chk(replace(b, 1, NA), 20), "must not contain NA")
  expect_error(chk(b, 20, 0), "strictly between 0 and 1")
  expect_error(chk(b, 20, 1), "strictly between 0 and 1")
  expect_error(chk(b, 20, "half"), "single number")

  ## the held-out count is clamped into [1, nblocks - 1]
  expect_equal(chk(b, 20, 0.01)$nhold, 1L)
  expect_equal(chk(b, 20, 0.99)$nhold, 4L)
})

## `inbag` records the rows drawn into the training sample, as it always has.
## Blocking restricts which rows are ELIGIBLE to be drawn, so the invariant is
## about blocks contributing rows, not about whole blocks being in-bag.
blocks_out <- function(inbag, blocks)      # blocks contributing no drawn row
  apply(inbag, 2, function(z) sum(tapply(z, blocks, max) == 0))
blocks_in <- function(inbag, blocks)       # blocks contributing at least one
  apply(inbag, 2, function(z) sum(tapply(z, blocks, max) == 1))

test_that("no drawn row ever comes from a withheld block", {
  d <- make_data()
  blocks <- rep(paste0("s", 1:9), each = 10)
  set.seed(2)
  fit <- rdaf_randomForest(x = d$X, y = d$y, ntree = 40, keep.inbag = TRUE,
                           importance = TRUE, sites = blocks, site.repeats = "blocked.resampling")
  expect_true(all(blocks_out(fit$inbag, blocks) == 3))
  expect_true(all(blocks_in(fit$inbag, blocks) == 6))
})

test_that("the right number of blocks is withheld from every tree", {
  d <- make_data()
  blocks <- rep(paste0("s", 1:9), each = 10)
  set.seed(3)
  fit <- rdaf_randomForest(x = d$X, y = d$y, ntree = 40, keep.inbag = TRUE,
                           sites = blocks, site.repeats = "blocked.resampling", block.holdout = 1/3)
  expect_true(all(blocks_out(fit$inbag, blocks) == 3))
  expect_equal(fit$sites.withheld, 3L)
})

test_that("the training sample is a bootstrap of the retained blocks", {
  ## blocking changes which rows are eligible, not how they are drawn: the
  ## draw is still with replacement, so about 1-1/e of the eligible pool is
  ## drawn, exactly as in an unblocked forest
  d <- make_data()
  blocks <- rep(paste0("s", 1:9), each = 10)
  set.seed(31)
  fit <- rdaf_randomForest(x = d$X, y = d$y, ntree = 200, keep.inbag = TRUE,
                           sites = blocks, site.repeats = "blocked.resampling", block.holdout = 1/3)
  pool <- 60                                   # 6 retained blocks of 10
  frac <- mean(colSums(fit$inbag)) / pool
  expect_lt(abs(frac - (1 - exp(-1))), 0.03)
  ## and with replace = FALSE the pool is sampled to 0.632 of its size, once
  set.seed(32)
  fit2 <- rdaf_randomForest(x = d$X, y = d$y, ntree = 200, keep.inbag = TRUE,
                            replace = FALSE, sites = blocks, site.repeats = "blocked.resampling")
  expect_lt(abs(mean(colSums(fit2$inbag)) / pool - 0.632), 0.03)
  expect_true(all(blocks_out(fit2$inbag, blocks) == 3))
})

test_that("the out-of-bag set is the withheld blocks and nothing else", {
  ## a retained row that the bootstrap happened to miss is NOT out-of-bag:
  ## its block-mates are in the training set.  So oob.times counts only the
  ## trees in which that row's own block was withheld.
  d <- make_data()
  blocks <- rep(paste0("s", 1:9), each = 10)
  ntree <- 300
  set.seed(33)
  fit <- rdaf_randomForest(x = d$X, y = d$y, ntree = ntree, sites = blocks, site.repeats = "blocked.resampling",
                           block.holdout = 1/3)
  expect_lt(abs(mean(fit$oob.times) - ntree / 3), 0.06 * ntree)
  expect_true(all(fit$oob.times > 0))
  expect_false(any(is.na(fit$predicted)))
})

test_that("unequal block sizes work", {
  d <- make_data()
  blocks <- rep(letters[1:5], times = c(5, 10, 15, 25, 35))
  set.seed(4)
  fit <- rdaf_randomForest(x = d$X, y = d$y, ntree = 40, keep.inbag = TRUE,
                           sites = blocks, site.repeats = "blocked.resampling", block.holdout = 0.4)
  expect_true(all(blocks_out(fit$inbag, blocks) == 2))
  expect_gt(diff(range(colSums(fit$inbag))), 0)
})

test_that("site handling is off by default and the fit is reproducible", {
  d <- make_data()
  set.seed(6); a <- rdaf_randomForest(x = d$X, y = d$y, ntree = 50)
  set.seed(6); b <- rdaf_randomForest(x = d$X, y = d$y, ntree = 50)
  expect_identical(a$mse, b$mse)
  expect_null(a$sites)
})

test_that("blocking works for classification too", {
  d <- make_data()
  yc <- factor(ifelse(d$y > 0, "hi", "lo"))
  blocks <- rep(paste0("s", 1:9), each = 10)
  set.seed(7)
  fit <- rdaf_randomForest(x = d$X, y = yc, ntree = 40, keep.inbag = TRUE,
                           sites = blocks, site.repeats = "blocked.resampling")
  expect_true(all(blocks_out(fit$inbag, blocks) == 3))
  expect_true(is.finite(fit$err.rate[40, "OOB"]))
})

test_that("unsupervised forests reject sites", {
  d <- make_data()
  expect_error(
    rdaf_randomForest(x = d$X, ntree = 10,
                      sites = rep(paste0("s", 1:9), each = 10),
                      site.repeats = "blocked.resampling"),
    "unsupervised")
})

test_that("rdaf_gradientForest accepts and records sites", {
  d <- make_data(n = 60, seed = 8)
  X <- d$X
  Y <- data.frame(pc1 = d$y, pc2 = X$v3 + stats::rnorm(60))
  blocks <- rep(paste0("s", 1:6), each = 10)
  set.seed(9)
  gf <- rdaf_gradientForest(cbind(X, Y), names(X), names(Y), ntree = 50,
                            sites = blocks, site.repeats = "blocked.resampling")
  expect_s3_class(gf, "rdaf_gradientForest")
  expect_false(is.null(gf$sites))
  expect_equal(gf$block.holdout, 1/3)
  expect_true(all(is.finite(rdaf_importance(gf, type = "Weighted"))))
  ## bad blocks are caught before any forest is grown
  expect_error(
    rdaf_gradientForest(cbind(X, Y), names(X), names(Y), ntree = 5,
                        sites = blocks[1:10],
                        site.repeats = "blocked.resampling"),
    "one entry per row")
})

test_that("blocking makes a group-confounded predictor look less important", {
  ## y is driven by a block-level effect that no predictor explains; the
  ## bootstrap out-of-bag score should be flattered by it, the blocked one not.
  set.seed(10)
  n <- 100
  blk <- rep(paste0("g", 1:10), each = 10)
  X <- data.frame(tag = as.numeric(factor(blk)),      # pure group label
                  real = stats::rnorm(n),
                  noise = stats::rnorm(n))
  beta <- stats::setNames(stats::rnorm(10, 0, 4), paste0("g", 1:10))
  y <- beta[blk] + 0.3 * X$real + stats::rnorm(n, 0, 0.3)

  set.seed(11)
  u <- rdaf_randomForest(x = X, y = y, ntree = 400, importance = TRUE)
  set.seed(11)
  b <- rdaf_randomForest(x = X, y = y, ntree = 400, importance = TRUE,
                         sites = blk, site.repeats = "blocked.resampling")
  expect_gt(u$rsq[400], b$rsq[400])
})

test_that("site_repeats_summary reports the design", {
  blocks <- rep(letters[1:5], times = c(5, 10, 15, 25, 35))
  out <- capture.output(
    res <- site_repeats_summary(blocks, "blocked.resampling", 0.4))
  expect_equal(res$n.withheld, 2L)
  expect_equal(unname(res$pool["min"]), 30)
  expect_equal(unname(res$pool["max"]), 75)
  expect_equal(res$rows.fitted, 90)
  expect_true(any(grepl("blocked.resampling", out)))

  out2 <- capture.output(res2 <- site_repeats_summary(blocks))
  expect_equal(res2$mode, "genetic.median")
  expect_equal(res2$rows.fitted, 5L)
})

test_that("the retired oob.blocks arguments still work, with a warning", {
  d <- make_data()
  blocks <- rep(paste0("s", 1:9), each = 10)
  set.seed(2)
  expect_warning(
    old <- rdaf_randomForest(x = d$X, y = d$y, ntree = 40, keep.inbag = TRUE,
                             oob.blocks = blocks),
    "deprecated")
  set.seed(2)
  new <- rdaf_randomForest(x = d$X, y = d$y, ntree = 40, keep.inbag = TRUE,
                           sites = blocks, site.repeats = "blocked.resampling")
  expect_identical(old$mse, new$mse)
})
