## ordinationJackknife(): one environment, several, or none.

oj_sim <- function(n = 60, seed = 1) {
  set.seed(seed)
  X <- data.frame(temp = stats::rnorm(n), depth = stats::runif(n), noise = stats::rnorm(n))
  Y <- data.frame(a = 2 * X$temp + stats::rnorm(n, 0, 0.5), b = X$depth + stats::rnorm(n, 0, 0.5),
                  c = stats::rnorm(n))
  warm <- X; warm$temp <- warm$temp + 0.3
  list(X = X, D = as.matrix(dist(Y)), warm = warm, n = n)
}
q <- function(e) suppressMessages(e)
K <- c("sum.importances", "predictions.direct", "predictions.turnover", "median.importance",
       "all.importances", "goodrows", "failed.reps")
run <- function(d, seed, ...) { set.seed(seed)
  q(ordinationJackknife(d$D, d$X, nreps = 3, top.pcs = 2, ntrees = 60, auto.sites = FALSE, ...)) }

test_that("without newX, the predictors in X are scored", {
  d <- oj_sim()
  a <- run(d, 1)
  expect_equal(nrow(a$predictions.direct), d$n)
  expect_equal(nrow(a$predictions.turnover), d$n)
  expect_identical(a$goodrows, seq_len(d$n))
  expect_named(a, c(K[1:6], "failed.reps", "ensemble.id"), ignore.order = TRUE)
  ## and it is exactly what newX = X gives
  b <- run(d, 1, newX = d$X)
  expect_identical(a$predictions.direct, b$predictions.direct)
  expect_identical(a$predictions.turnover, b$predictions.turnover)
})

test_that("a list of environments gives what separate runs with the same seed give", {
  d <- oj_sim()
  m <- run(d, 2, newX = list(now = d$X, warm = d$warm), extra = c(0, 0.5), extra.npred = c(3, 1))
  s1 <- run(d, 2, newX = d$X, extra = 0)
  s2 <- run(d, 2, newX = d$warm, extra = 0.5, extra.npred = 1)
  expect_named(m, c("now", "warm"))
  for (k in K) {
    expect_identical(m$now[[k]], s1[[k]], info = k)
    expect_identical(m$warm[[k]], s2[[k]], info = k)
  }
  ## one run, one token; separate runs, different tokens
  expect_identical(m$now$ensemble.id, m$warm$ensemble.id)
  expect_false(identical(s1$ensemble.id, s2$ensemble.id))
})

test_that("list elements may be unnamed or NULL (NULL stands for X)", {
  d <- oj_sim()
  m <- run(d, 3, newX = list(NULL, d$warm), extra = 0.5)
  expect_named(m, c("newX1", "newX2"))
  expect_identical(m$newX1$predictions.direct, run(d, 3)$predictions.direct)
})

test_that("gen_offset_oj: silent within one run, warns across runs", {
  d <- oj_sim(n = 40)
  xy <- data.frame(x = seq_len(40), y = seq_len(40))
  m <- run(d, 4, newX = list(now = d$X, warm = d$warm), extra = 1)
  expect_no_warning(gen_offset_oj(m$now, m$warm, xy, xy))
  other <- run(d, 5, newX = d$warm, extra = 1)
  expect_warning(gen_offset_oj(m$now, other, xy, xy), "different ordinationJackknife\\(\\) runs")
  o <- suppressWarnings(gen_offset_oj(m$now, other, xy, xy))
  expect_true("offset" %in% names(o))
  a <- m$now; a$ensemble.id <- NULL; b <- other; b$ensemble.id <- NULL
  expect_no_warning(gen_offset_oj(a, b, xy, xy))
  ## and a token does not disturb the random number stream
  set.seed(61); x1 <- runif(3); id <- RDAforest:::.rdaf_fit_id(); x2 <- runif(3)
  set.seed(61); expect_equal(c(x1, x2), runif(6))
})

test_that("site handling runs in every mode", {
  set.seed(47)
  sites <- factor(rep(paste0("s", 1:12), each = 5))
  idx <- as.integer(sites); n <- length(idx)
  E <- scale(matrix(stats::rnorm(36), 12, 3)); colnames(E) <- c("driver", "n1", "n2")
  X <- as.data.frame(E[idx, , drop = FALSE])
  D <- as.matrix(dist(data.frame(a = E[idx, 1] + stats::rnorm(n, 0, 0.5),
                                 b = E[idx, 2] + stats::rnorm(n, 0, 0.5), c = stats::rnorm(n))))
  for (m in c("genetic.median", "blocked.resampling", "direct.use")) {
    set.seed(48)
    a <- q(ordinationJackknife(D, X, nreps = 2, top.pcs = 2, ntrees = 60, sites = sites,
                               site.repeats = m, newX = list(X, X)))
    expect_equal(nrow(a$newX1$predictions.direct), n, info = m)
    expect_identical(a$newX1$predictions.direct, a$newX2$predictions.direct, info = m)
  }
  ## auto-detection decides once and says so once
  set.seed(50)
  msgs <- capture_messages(ordinationJackknife(D, X, nreps = 2, top.pcs = 2, ntrees = 60,
                                               newX = list(X, X)))
  expect_equal(sum(grepl("multiple samples per site", msgs)), 1L)
  set.seed(51)
  msgs2 <- capture_messages(ordinationJackknife(D, X, nreps = 2, top.pcs = 2, ntrees = 60,
                                                site.repeats = "blocked.resampling"))
  expect_equal(sum(grepl("blocked.resampling", msgs2)), 1L)
})

test_that("bad input is refused before fitting", {
  d <- oj_sim()
  expect_error(ordinationJackknife(d$D, d$X, newX = list()), "empty")
  expect_error(ordinationJackknife(d$D, d$X, newX = list(a = d$X, a = d$warm)), "distinct names")
  expect_error(ordinationJackknife(d$D, d$X, newX = list(a = d$X, b = 1:3)), "data frame")
  expect_error(ordinationJackknife(d$D, d$X, newX = 1:3), "data frame")
  expect_error(ordinationJackknife(d$D, d$X, newX = list(d$X, d$warm), extra = c(0, 0.1, 0.2)),
               "one per environment")
  expect_error(ordinationJackknife(d$D, d$X, extra.npred = 99), "between 0 and")
  expect_error(ordinationJackknife(d$D, d$X, ncores = 0), "1 or more")
  expect_error(q(ordinationJackknife(d$D[1:10, 1:10], d$X, nreps = 2, auto.sites = FALSE)),
               "incompatible input matrices")
  expect_false(exists("ojFit", envir = asNamespace("RDAforest")))
  expect_false(exists("ojPredict", envir = asNamespace("RDAforest")))
})

test_that("turnover curves predict exactly as the gradient forest does", {
  d <- oj_sim()
  set.seed(70)
  Y <- data.frame(a = d$X$temp + stats::rnorm(d$n), b = d$X$depth + stats::rnorm(d$n))
  g <- q(makeGF_simple(Y, d$X, ntrees = 100, auto.sites = FALSE))
  cis <- RDAforest:::.rdaf_oj_curves(g, names(d$X))
  nx <- rbind(d$X, d$X[1:5, ] + 3, d$X[6:10, ] - 3)
  expect_identical(RDAforest:::.rdaf_oj_turnover(cis, nx), predict(g, nx))
})
