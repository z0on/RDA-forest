## Tests for extra.npred: how far each predictor may extend beyond the range
## the model actually saw.

oj_data <- function(n = 60, seed = 1) {
  set.seed(seed)
  X <- data.frame(v1 = stats::runif(n, 0, 1), v2 = stats::runif(n, 0, 1),
                  v3 = stats::runif(n, 0, 1), v4 = stats::runif(n, 0, 1),
                  v5 = stats::runif(n, 0, 1))
  Y <- data.frame(p1 = 2 * X$v1 + stats::rnorm(n, 0, 0.3),
                  p2 = X$v2 + stats::rnorm(n, 0, 0.3),
                  p3 = stats::rnorm(n))
  list(X = X, Y = Y, n = n)
}

## a newX whose rows each step one predictor a known distance past its maximum
step_out <- function(X, frac, below = FALSE) {
  rng <- apply(X, 2, range)
  span <- rng[2, ] - rng[1, ]
  mid <- colMeans(X)
  out <- do.call(rbind, lapply(names(X), function(v) {
    row <- mid
    row[v] <- if (below) rng[1, v] - frac * span[v] else rng[2, v] + frac * span[v]
    row
  }))
  ## plus one row that is in range for everything, so newX is never emptied
  out <- as.data.frame(rbind(out, mid))
  rownames(out) <- c(names(X), "inside")
  out
}

run_oj <- function(d, newX, ...)
  suppressMessages(ordinationJackknife(as.matrix(dist(d$Y)), d$X, newX = newX, nreps = 2,
                                       top.pcs = 2, ntrees = 60,
                                       auto.sites = FALSE, ...))

test_that("extra.npred restricts extra to the leading predictors", {
  d <- oj_data()
  ## each row is 0.2 of a span past one predictor's maximum
  nx <- step_out(d$X, 0.2)
  ## extra = 0.1 admits none of them; extra.npred = 2 exempts v3, v4, v5
  oj <- run_oj(d, nx, extra = 0.1, extra.npred = 2)
  expect_equal(unname(oj$goodrows), c(FALSE, FALSE, TRUE, TRUE, TRUE, TRUE))
})

test_that("a predictor within its own allowance is kept and clamped", {
  d <- oj_data()
  nx <- step_out(d$X, 0.05)              # inside an allowance of 0.1
  oj <- run_oj(d, nx, extra = 0.1, extra.npred = 2)
  expect_true(all(oj$goodrows))
  expect_equal(nrow(oj$predictions.direct), 6L)
  expect_true(all(is.finite(as.matrix(oj$predictions.direct))))
})

test_that("the default is unchanged from earlier versions", {
  d <- oj_data()
  nx <- step_out(d$X, 0.2)
  ## extra = 0, extra.npred = all: nothing may extend, so only the in-range
  ## row survives
  oj <- run_oj(d, nx, extra = 0)
  expect_equal(unname(oj$goodrows), c(rep(FALSE, 5), TRUE))

  ## and naming extra.npred = ncol(X) explicitly is the same thing
  set.seed(9); a <- run_oj(d, d$X, extra = 0)
  set.seed(9); b <- run_oj(d, d$X, extra = 0, extra.npred = ncol(d$X))
  expect_equal(a$median.importance, b$median.importance)
  expect_equal(a$predictions.direct, b$predictions.direct)
})

test_that("extra.npred = 0 lets every predictor extend without limit", {
  d <- oj_data()
  nx <- step_out(d$X, 50)                # far outside, every predictor
  oj <- run_oj(d, nx, extra = 0, extra.npred = 0)
  expect_true(all(oj$goodrows))
  expect_equal(nrow(oj$predictions.direct), 6L)
})

test_that("unlimited predictors never drop a row, however far out", {
  d <- oj_data()
  nx <- step_out(d$X, 1000)
  oj <- run_oj(d, nx, extra = 0.1, extra.npred = 2)
  expect_equal(unname(oj$goodrows), c(FALSE, FALSE, TRUE, TRUE, TRUE, TRUE))
  expect_equal(nrow(oj$predictions.direct), 4L)
})

test_that("extension below the minimum is treated the same way", {
  d <- oj_data()
  nx <- step_out(d$X, 0.3, below = TRUE)
  oj <- run_oj(d, nx, extra = 0.1, extra.npred = 2)
  expect_equal(unname(oj$goodrows), c(FALSE, FALSE, TRUE, TRUE, TRUE, TRUE))
})

test_that("bad extra.npred is rejected", {
  d <- oj_data()
  expect_error(run_oj(d, d$X, extra.npred = -1), "between 0 and")
  expect_error(run_oj(d, d$X, extra.npred = 99), "between 0 and")
  expect_error(run_oj(d, d$X, extra.npred = c(1, 2)), "single number|one per environment")
  expect_error(run_oj(d, d$X, extra.npred = "two"), "single number|one per environment")
})
