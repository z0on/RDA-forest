## ---------------------------------------------------------------------------
## Fit-once / predict-many split of ordinationJackknife().
##
## ojFit() runs the jackknife and RETAINS the per-replicate models; ojPredict()
## scores any grid through the stored ensemble.  ordinationJackknife() is the
## two composed, so all three share one code path and one random number stream.
## ---------------------------------------------------------------------------

## Validate extra.npred against the number of predictors.  Called early by
## ordinationJackknife() so that a typo is caught before the fitting, not after.
.rdaf_check_extra_npred <- function(extra.npred, np) {
  if (!is.numeric(extra.npred) || length(extra.npred) != 1 || is.na(extra.npred))
    stop("extra.npred must be a single number")
  extra.npred <- round(extra.npred)
  if (extra.npred < 0 || extra.npred > np)
    stop("extra.npred must be between 0 and the number of predictors (", np, ")")
  extra.npred
}

## Clamp newX into the range the model saw, dropping rows that reach further
## than their predictor's allowance.  `extra` applies to the first extra.npred
## predictors in the order they were supplied in X; the rest get Inf, so nothing
## is ever out of range for them and no row is dropped on their account.
.rdaf_filter_newX <- function(newX, X, extra = 0, extra.npred = ncol(X)) {
  if (is.null(newX))
    return(list(newX = X, goodrows = seq_len(nrow(X))))
  extra.npred <- .rdaf_check_extra_npred(extra.npred, ncol(X))
  extras <- stats::setNames(rep(Inf, ncol(X)), colnames(X))
  if (extra.npred > 0) extras[seq_len(extra.npred)] <- extra

  newX <- newX[, colnames(newX) %in% colnames(X)]
  ranges <- apply(X, 2, range)
  spans <- ranges[2, ] - ranges[1, ]
  ranges.s <- ranges
  ## spans * Inf would be NaN for a constant predictor, so set the unlimited
  ## ones straight to Inf
  pad <- spans * extras[colnames(ranges)]
  pad[!is.finite(extras[colnames(ranges)])] <- Inf
  ranges.s[2, ] <- ranges[2, ] + pad
  ranges.s[1, ] <- ranges[1, ] - pad
  for (v in colnames(newX)) {
    newX[, v][newX[, v] < ranges.s[1, v]] <- NA
    newX[, v][newX[, v] < ranges[1, v]] <- ranges[1, v]
    newX[, v][newX[, v] > ranges.s[2, v]] <- NA
    newX[, v][newX[, v] > ranges[2, v]] <- ranges[2, v]
  }
  goodrows <- apply(newX, 1, function(x) sum(is.na(x)) == 0)
  list(newX = newX[goodrows, ], goodrows = goodrows)
}



## Reduce one replicate's models to what prediction reads.  The forests lose
## the parts only used during fitting or for in-sample summaries (node sums of
## squares and improvements, the OOB predictions, the response, the OOB
## counts): predict() with newdata never touches them.  The gradient forest is
## replaced by the cumulative-importance curve of each predictor, which is all
## that turnover prediction uses.
.rdaf_oj_compact <- function(rf, gf, vars) {
  for (j in seq_along(rf)) {
    rf[[j]]$forest$nodeSS <- NULL; rf[[j]]$forest$nodeImprove <- NULL
    rf[[j]]$predicted <- NULL; rf[[j]]$y <- NULL; rf[[j]]$oob.times <- NULL
  }
  list(rf = rf,
       gf = lapply(stats::setNames(vars, vars), function(v) rdaf_cumimp(gf, v)))
}

## Turnover prediction from stored cumulative-importance curves: the body of
## predict.rdaf_gradientForest(object, newdata, extrap = TRUE), with the call
## to rdaf_cumimp() replaced by the curve kept by ojFit().
.rdaf_oj_turnover <- function(cis, newdata, extrap = TRUE) {
  out <- newdata
  for (varX in names(newdata)) {
    ci <- cis[[varX]]
    if (is.null(ci))
      stop("the following predictor is not in the fitted ensemble: ", varX)
    if (length(ci$x) == 1) {
      out[, varX] <- ci$y
    } else {
      f <- stats::approxfun(ci, rule = 1)
      out[, varX] <- f(newdata[, varX])
      xold <- range(ci$x)
      yold <- range(ci$y)
      if (xold[1] == xold[2])
        stop(paste0("variable [", varX, "] has badly formed cumulative importance curve:\n ", ci))
      grad_norm <- diff(yold)
      upper_extrap <- newdata[, varX] > xold[2]
      if (length(upper_extrap) > 0) {
        upper_norm <- (newdata[upper_extrap, varX] - min(xold)) / (max(xold) - min(xold))
        out[upper_extrap, varX] <- .rdaf_compress_extrap(upper_norm - 1, as.numeric(extrap), grad_norm, yold[2])
      }
      lower_extrap <- newdata[, varX] < xold[1]
      if (length(lower_extrap) > 0) {
        lower_norm <- (newdata[lower_extrap, varX] - min(xold)) / (max(xold) - min(xold))
        out[lower_extrap, varX] <- -.rdaf_compress_extrap(-lower_norm, as.numeric(extrap), grad_norm, -yold[1])
      }
    }
  }
  class(out) <- c("predict.rdaf_gradientForest", "data.frame")
  out
}

## Score one replicate's models on newX.  Used both by ojPredict(), which
## works from stored models, and by ordinationJackknife(), which scores each
## replicate as it is fitted and then lets the models go.  `gf` is either the
## list of curves ojFit() keeps or, for fits saved by RDAforest 2.9.1, a whole
## gradient forest.
.rdaf_oj_predict_one <- function(rf, gf, newX) {
  Yp <- list()
  for (j in seq_along(rf)) {
    message("predicting mds ", j)
    Yp[[j]] <- predict(rf[[j]], newX)
  }
  message("predicting turnover")
  tt <- if (inherits(gf, "rdaf_gradientForest")) predict(gf, newX)
        else .rdaf_oj_turnover(gf, newX)
  list(d = data.frame(do.call(cbind, Yp)), t = tt)
}

## A token identifying one fitted ensemble.  tempfile() gives a unique string
## without touching the random number stream, which must stay exactly as it was
## so that the three entry points remain bit-identical to one another.
##
## The component is called `ensemble.id`, not `fit.id`, on purpose: `$` partial-
## matches on lists, so a `fit.id` would answer to `$fit` whenever the ensemble
## itself was not kept, and hand back a string where a model was asked for.
.rdaf_fit_id <- function()
  paste0("ojfit.", format(Sys.time(), "%Y%m%d%H%M%S"), ".",
         sub("^file", "", basename(tempfile(pattern = "file"))))

## Rescale the averaged turnover curves and put the return value together.
.rdaf_oj_assemble <- function(pred.d, pred.t, fit, goodrows) {
  importances <- fit$median.importance
  for (m in colnames(pred.t))
    pred.t[, m] <- decostand(pred.t[, m], method = "range") * importances[m]
  list(sum.importances = fit$sum.importances, predictions.direct = pred.d,
       predictions.turnover = pred.t, median.importance = importances,
       all.importances = fit$all.importances, goodrows = goodrows,
       failed.reps = fit$failed.reps, ensemble.id = fit$ensemble.id)
}

#' Ordination jackknife: fit once
#'
#' Fits the same models as \code{\link{ordinationJackknife}} and keeps them, so
#' that predictions for any number of new environments can be made afterwards
#' with \code{\link{ojPredict}} from one set of fitted forests. Replicates are
#' built, and the random number stream is consumed, exactly as in
#' \code{ordinationJackknife}: with the same seed,
#' \code{ojPredict(ojFit(Y, X, ...), newX, extra)} returns what
#' \code{ordinationJackknife(Y, X, newX = newX, extra = extra, ...)} returns.
#'
#' Use it when several environments are to be scored through the same model:
#' present-day and a set of future climate scenarios, say. Fitting is what
#' costs the time, and this way it happens once, so every scenario is scored
#' through exactly the same ensemble rather than through a fresh one that
#' differs by the luck of the draw.
#'
#' The price is memory, kept down by storing only what prediction reads: the
#' \code{nreps * top.pcs} random forests without their training-only parts
#' (node sums of squares and improvements, out-of-bag predictions, the
#' response), and, in place of each replicate's gradient forest, the
#' cumulative-importance curve of every predictor. The trees themselves remain,
#' so the object still grows with \code{ntrees * nreps * top.pcs}; reduce one
#' of those if it becomes a problem, or use \code{ordinationJackknife} with
#' \code{keep.models = FALSE} when only one grid is to be scored.
#'
#' @inheritParams ordinationJackknife
#' @param .stream internal. A function of \code{(rf, gf)} called with each
#'   replicate's (compacted) models as they are fitted; when supplied the models are handed
#'   to it and not retained, which is how \code{\link{ordinationJackknife}}
#'   scores a grid without holding the whole ensemble in memory.
#' @return A list. \code{rf} - for each successful replicate, the list of
#'   \code{\link{rdaf_randomForest}} models (one per retained principal
#'   component) used for direct predictions, stripped of the parts that
#'   prediction does not read; \code{gf} - for each successful replicate, the
#'   cumulative-importance curve (\code{\link{rdaf_cumimp}}) of every
#'   predictor in the matching gradient forest, a named list of \code{x}/\code{y}
#'   lists, used for turnover predictions; \code{X} - the predictor matrix the
#'   models were fitted on; \code{n.models} - the number of successful
#'   replicates; \code{ensemble.id} - a token identifying this ensemble, carried
#'   into everything \code{\link{ojPredict}} returns so that
#'   \code{\link{gen_offset_oj}} can tell whether two prediction sets came
#'   from the same fit; \code{sites} and \code{site.repeats} - how repeated
#'   samples were handled; \code{sum.importances},
#'   \code{median.importance}, \code{all.importances}, \code{failed.reps} - as
#'   in \code{\link{ordinationJackknife}}.
#' @seealso \code{\link{ojPredict}}, \code{\link{ordinationJackknife}}
#' @examples
#' \donttest{
#' set.seed(1)
#' n <- 60
#' X <- data.frame(temp = rnorm(n), depth = runif(n), noise = rnorm(n))
#' Y <- data.frame(a = 2 * X$temp + rnorm(n), b = X$depth + rnorm(n),
#'                 c = rnorm(n))
#' fit <- ojFit(Y, X, nreps = 3, top.pcs = 2, ntrees = 100, auto.sites = FALSE)
#' now <- ojPredict(fit, X)
#' ## a warmer world, scored through the same forests
#' future <- X; future$temp <- future$temp + 0.5
#' then <- ojPredict(fit, future, extra = 0.2, extra.npred = 1)
#' }
#' @importFrom dplyr group_by
#' @importFrom dplyr summarise
#' @importFrom dplyr %>%
#' @import vegan
#' @export
ojFit=function(Y,X,oob=0.2,covariates=NULL,nreps=25,top.pcs=15,rescale2npcs=FALSE,mtry=NULL,ntrees=1500,sites=NULL,site.repeats=c("genetic.median","blocked.resampling","direct.use"),block.holdout=1/3,coords=NULL,auto.sites=TRUE,.stream=NULL) {
  # resolve and validate the site.repeats setting up front, once only.
  # Ask whether a mode was named before match.arg() collapses the default.
  .explicit=!missing(site.repeats)
  site.repeats=match.arg(site.repeats)
  .res=.rdaf_resolve_sites(X,sites,site.repeats,coords,auto.sites,.explicit)
  sites=.res$sites; site.repeats=.res$site.repeats
  srep=.rdaf_check_site_repeats(sites,nrow(X),site.repeats,block.holdout)
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  if(rescale2npcs==TRUE){rescale2npcs=top.pcs } else {rescale2npcs=NULL }
  # setting mtry to N/3 or 2 (note: the default is N/3 or 1)
  if (is.null(mtry)){ mt=max(floor(ncol(X)/3),2) } else { mt=mtry }
  failed.reps=0;v.order=NULL
  # site handling for the direct-prediction forests, as in predict_rf()
  fit.sites=if(srep$mode=="blocked.resampling") srep$factor else NULL
  imps=c();replicate=c();impsum=c()
  rfs=list();gfs=list();n.models=0

  if(dim(Y)[1]==dim(Y)[2] & sum(Y[,1]==Y[1,])==dim(Y)[1]) {
    if(!is.null(covariates)) {
      ords.full=capscale(Y~1+Condition(as.matrix(covariates)))
    } else {
      ords.full=capscale(Y~1)
    }
  } else {
    if(!is.null(covariates)) {
      ords.full=rda(Y~1+Condition(as.matrix(covariates)))
    } else {
      ords.full=rda(Y~1)
    }
  }

  sc.full=scores(ords.full,scaling=1,display="sites",choices=c(1:length(ords.full$CA$eig)))
  for(i in 1:nreps){
    message("\nreplicate ",i)
    ib.keep=sample(1:nrow(Y),round(nrow(Y)*(1-oob)))
    if(!is.null(covariates)) {
      covars.ib=covariates[ib.keep,]
      if(dim(Y)[1]==dim(Y)[2] & sum(Y[,1]==Y[1,])==dim(Y)[1]) {
        Y.ib=Y[ib.keep,ib.keep]
        ords0=capscale(Y.ib~1+Condition(as.matrix(covars.ib)))
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      } else {
        Y.ib=Y[ib.keep,]
        ords0=rda(Y.ib~1+Condition(as.matrix(covars.ib)))
        suppressWarnings({ords=predict(ords0,Y,type='wa',scaling="sites")})
      }
    } else {
      if(dim(Y)[1]==dim(Y)[2] & sum(Y[,1]==Y[1,])==dim(Y)[1]) {
        Y.ib=Y[ib.keep,ib.keep]
        ords0=capscale(Y.ib~1)
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      } else {
        Y.ib=Y[ib.keep,]
        ords0=rda(Y.ib~1)
        suppressWarnings({ords=predict(ords0,Y,type='wa',scaling="sites")})
      }
    }
    # align projected ordinaton with full-model scores
    orr=data.frame(procrustes(sc.full,ords,scale = T)$Yrot)
    names(orr)[1:top.pcs]=colnames(sc.full)[1:top.pcs]
    gf1=makeGF_simple(orr[,1:top.pcs],X,ntrees=ntrees,mtry=mt,sites=sites,site.repeats=site.repeats,block.holdout=block.holdout,auto.sites=FALSE)
    if(is.null(gf1)) {
      failed.reps=failed.reps+1
      message("   ... nothing is predictable. Moving to next rep")
      next
    }
    else{
      # direct-prediction forests, fitted exactly as predict_rf() fits them
      Yf=orr[,1:top.pcs]; Xf=X
      if(srep$mode=="genetic.median"){
        coll=.rdaf_collapse_sites(X,Yf,srep$factor)
        Xf=coll$X; Yf=coll$Y
      }
      rf=list()
      for(j in 1:ncol(Yf)){
        pc=Yf[,j]
        rf[[j]]=rdaf_randomForest(x=Xf,y=pc,sites=fit.sites,site.repeats="blocked.resampling",block.holdout=block.holdout,auto.sites=FALSE,ntree=ntrees,mtry=mt)
      }
      if (is.null(v.order)) {
        v.order=names(importance_RDAforest(gf1,ords0))
      }
      # `.stream` lets a caller consume each replicate as it is fitted and let
      # the models go, which is how ordinationJackknife() keeps its memory flat
      # keep only what prediction reads (see .rdaf_oj_compact)
      cm=.rdaf_oj_compact(rf,gf1,colnames(X))
      if(is.null(.stream)) { rfs[[length(rfs)+1]]=cm$rf; gfs[[length(gfs)+1]]=cm$gf }
      else { .stream(cm$rf,cm$gf) }
      n.models=n.models+1
      ii=importance_RDAforest(gf1,ords0,rescale2npcs=rescale2npcs)[v.order]
      imps=c(imps,ii)
      replicate=c(replicate,rep(i,length(v.order)))
      impsum=c(impsum,sum(ii))
    }
  }
  if(!n.models) { stop("every replicate failed: nothing is predictable") }

  # computing median importances of variables
  dimps=data.frame(imps)
  dimps$replicate=replicate
  dimps$variable=names(imps)
  names(dimps)[1]="importance"
  meds=dimps%>%
    group_by(variable)%>%
    summarise(median(importance))
  meds=as.data.frame(meds)
  importances=meds$`median(importance)`
  names(importances)=meds$variable

  # releveling variables according to median importance
  varorder=meds$variable[order(meds[,2],decreasing=T)]
  importances=importances[varorder]
  dimps$variable=factor(dimps$variable,levels=rev(varorder))
  return(list(rf=rfs,gf=gfs,n.models=n.models,X=X,ensemble.id=.rdaf_fit_id(),
              sites=srep$factor,
              site.repeats=if(srep$mode=="none") NULL else srep$mode,
              sum.importances=impsum,median.importance=importances,
              all.importances=dimps,failed.reps=failed.reps))
}


#' Ordination jackknife: predict from a fitted ensemble
#'
#' Predicts \code{newX} from the models fitted by \code{\link{ojFit}},
#' averaging across replicates. The forests are fitted once, however many
#' environments are scored, so a set of scenarios is compared through one
#' ensemble rather than through several that differ by the luck of the draw.
#'
#' @param fit object returned by \code{\link{ojFit}}.
#' @param newX new matrix of predictor variables where associated differences in
#'   Y must be predicted (averaged across replicates). If omitted, predictions
#'   are made for the predictors the models were fitted on.
#' @param extra if a \code{newX} variable is outside the range of its \code{X}
#'   values by not more than this fraction of the variable's span, it is set to
#'   the max or min of \code{X}. Values further away are set to NA and those
#'   rows are deleted. Applies only to the first \code{extra.npred} predictors.
#' @param extra.npred number of predictors, counted from the first as they were
#'   supplied to \code{\link{ojFit}}, to which \code{extra} applies. The rest
#'   may extend beyond their modelled range without limit. The default is all of
#'   them. See \code{\link{ordinationJackknife}}.
#' @return As \code{\link{ordinationJackknife}}: \code{sum.importances},
#'   \code{predictions.direct}, \code{predictions.turnover},
#'   \code{median.importance}, \code{all.importances}, \code{goodrows},
#'   \code{failed.reps}, and \code{ensemble.id}, the token of the ensemble the
#'   predictions came from.
#' @seealso \code{\link{ojFit}}, \code{\link{ordinationJackknife}}
#' @import vegan
#' @export
ojPredict=function(fit,newX=NULL,extra=0,extra.npred=ncol(fit$X)) {
  if(is.null(fit$rf) || !length(fit$rf)) {
    stop("fit holds no models: was it made by ojFit()?")
  }
  flt=.rdaf_filter_newX(newX,fit$X,extra,extra.npred)
  for(i in seq_along(fit$rf)){
    message("\nreplicate ",i," of ",length(fit$rf)," (",nrow(flt$newX)," rows)")
    p=.rdaf_oj_predict_one(fit$rf[[i]],fit$gf[[i]],flt$newX)
    if (i==1) { pred.d=p$d; pred.t=p$t } else { pred.d=pred.d+p$d; pred.t=pred.t+p$t }
  }
  .rdaf_oj_assemble(pred.d/length(fit$rf),pred.t/length(fit$rf),fit,flt$goodrows)
}
