# RDAforest 2.9.2

## Leaner fitted ensembles

`ojFit()` (and so `ordinationJackknife(keep.models = TRUE)`) now keeps only
what prediction reads:

* each direct-prediction random forest loses `forest$nodeSS`,
  `forest$nodeImprove`, `predicted`, `y` and `oob.times`, none of which
  `predict()` touches when given new data;
* each replicate's gradient forest is replaced by the cumulative-importance
  curve (`rdaf_cumimp()`) of every predictor, a named list of `x`/`y` pairs,
  which is all that turnover prediction uses.

For the 94 wolves at the defaults (`nreps = 25`, `top.pcs = 15`,
`ntrees = 1500`) the retained ensemble drops from 2.66 GB to 1.32 GB: the random
forests from 1.97 to 1.31 GB and the gradient forests from 0.69 GB to 10 Mb.
Predictions are bit-identical to 2.9.1 and to 2.8.1. Fits saved by 2.9.1,
which hold whole gradient forests, are still accepted by `ojPredict()`.

The `gf` component of an `ojFit()` object is therefore no longer a list of
`rdaf_gradientForest` objects. Anything that used it for plotting or
importance should refit with `makeGF()`.

# RDAforest 2.9.1

## `ordinationJackknife(keep.models = TRUE)`

`ordinationJackknife()` now hands the fitted ensemble back in `$fit`, ready for
`ojPredict()` on another environment without refitting:

```r
oj  <- ordinationJackknife(Y, X, newX = envc, extra = 0.1)   # keep.models = TRUE
ojf <- ojPredict(oj$fit, newX = envf, extra = 0.2)           # same forests
```

The predictions are identical whether the models are kept or not; the cost is
memory, since the ensemble holds `nreps` gradient forests and `nreps * top.pcs`
random forests — about 2.7 GB for 94 samples at the defaults, more with more
samples. A message says so when it passes a gigabyte, and `keep.models = FALSE`
restores the old behaviour of scoring each replicate as it is fitted and
releasing it.

## `gen_offset_oj()` checks that the two predictions are comparable

A genetic offset is the difference between two sets of predictions, so it only
measures the difference between two *environments* if both were scored through
the same fitted ensemble. Every prediction now carries `ensemble.id`, a token
of the ensemble it came from, and `gen_offset_oj()` warns when its two
arguments disagree:

> the two prediction sets come from different model fits, so this offset mixes
> the difference between two ensembles in with the difference between two
> environments.

It is a warning, not an error — the offset is still returned. Objects saved
before the tokens existed carry none and pass unchecked.

The component is `ensemble.id` rather than `fit.id` deliberately: `$` partial-
matches on lists, so a `fit.id` would answer to `$fit` whenever the ensemble was
not kept, handing back a string where a model was asked for.

# RDAforest 2.9.0

## `ojFit()` and `ojPredict()`: fit once, predict many

`ordinationJackknife()` fits its replicates and scores one grid. When several
environments are to be scored through the same model — present-day and a set of
future scenarios — that meant one full fit per environment, and each fit drew
its own replicates.

```r
fit <- ojFit(Y, X, covariates = latlon.gcd, nreps = 25, top.pcs = 10)
now    <- ojPredict(fit, envc, extra = 0.1)
future <- ojPredict(fit, envf, extra = 0.2)
```

`ojFit()` runs the jackknife and keeps the models; `ojPredict()` scores any grid
through them, with its own `extra` and `extra.npred`. With the same seed,
`ojPredict(ojFit(Y, X, ...), newX, extra)` returns exactly what
`ordinationJackknife(Y, X, newX = newX, extra = extra, ...)` returns.

**This matters for genetic offset.** The offset is the difference between two
predictions, so when each comes from its own `ordinationJackknife()` run, that
difference carries the sampling noise of two independent ensembles on top of
the environmental change. Scoring the same grid twice through two separate fits
of the wolf data gives a median spurious offset of 0.025 at `nreps = 5`, 0.014
at 11 and 0.010 at 25, against a real climate offset of about 0.05 — that is 20
to 50 percent of the signal. Through one fitted ensemble the same comparison
gives exactly zero.

`ojFit()` holds `nreps` gradient forests and `nreps * top.pcs` random forests,
which on a large problem runs to gigabytes: about 780 Mb for the wolves at
`nreps = 10, top.pcs = 10, ntrees = 1500`. Drop the object once the predictions
are made, or use `ordinationJackknife()` when only one grid is to be scored.

## `ordinationJackknife()` now runs on that code

Its replicates are built by `ojFit()` and scored by the same code `ojPredict()`
uses, so the three share one code path and one random number stream. Results are
**bit-identical** to 2.8.1: on the wolf data every returned component —
importances, both prediction tables, `goodrows`, `failed.reps` — passes
`identical()`, not merely `all.equal()`.

Memory and speed are unchanged too. `ordinationJackknife()` scores each
replicate as soon as it is fitted and then releases it, so it never holds the
whole ensemble the way `ojFit()` does.

# RDAforest 2.8.1

## `extra.npred` in `ordinationJackknife()`

`extra` says how far a predictor in `newX` may reach beyond the range the model
was fitted on before its row is dropped. It now applies only to the first
`extra.npred` predictors, counted in the order they were supplied in `X`; the
rest may extend without limit, so no row is ever dropped on their account.

```r
ordinationJackknife(Y, X, newX = rasters, extra = 0.1, extra.npred = 2)
```

With five predictors, that lets predictors 1 and 2 reach a tenth of their span
past the modelled range and no further, while predictors 3 to 5 are
unrestricted. Useful when some predictors should be extrapolated cautiously
(climate, say) while others legitimately cover ground the samples did not
(coordinates, depth).

The default is `extra.npred = ncol(X)` which, with `extra = 0`, is exactly the
old behaviour: no extension anywhere.

## Fixes

- Automatic site detection no longer overrides an explicitly named
  `site.repeats`. Detection supplies the *sites*; the mode is whatever the
  caller asked for, and only a caller who left `site.repeats` alone gets the
  `"genetic.median"` default. Affected `rdaf_randomForest()`,
  `rdaf_gradientForest()`, `makeGF()`, `makeGF_simple()`, `predict_rf()`,
  `mtrySelJack()` and `ordinationJackknife()`. When a mode is named, the
  message now says which one was used instead of naming the genetic median.

# RDAforest 2.8.0

## `site.repeats`: three ways to handle repeated samples within a site

The `oob.blocks` / `oob.block.holdout` pair introduced in 2.7.0 is replaced by
`sites` plus `site.repeats`. Pass the site membership of each sample as `sites`,
and choose what is done about the repeats:

| `site.repeats` | what it does | rows fitted |
|---|---|---|
| `"genetic.median"` (default) | collapses each site to one synthetic individual at the geometric median of its members | one per site |
| `"blocked.resampling"` | keeps every individual, withholds whole sites from each tree | all |
| `"direct.use"` | ignores the site structure: the ordinary random forest | all |

`sites = NULL` (the default) means no repeated sampling and leaves everything as
it was, so code that does not use the option is unaffected.

### `"genetic.median"`

Each site is replaced by a single **"false individual"**: not one of the real
samples, but the point with the smallest sum of Euclidean distances to all of
them, found by **Weiszfeld's iteration** in the space of *all* the principal
coordinates being analysed. The iteration starts at the centroid and repeatedly
replaces the estimate by the mean of the points weighted by the reciprocal of
their distances to it, until it stops moving; if it lands exactly on a data
point that point is returned.

This is not the medoid (which is a real sample, and so carries that individual's
own noise) and not the centroid (which minimises *squared* distances and is
pulled around by outliers). The forest is then fitted to one row per site, so
there is no repeated sampling left to exploit.

New exported helpers: `geometric_median()` for a single set of points,
`genetic_medians()` for the per-site collapse, and `detect_sites()` for the
automatic check described below.

### `"blocked.resampling"`

What `oob.blocks` did in 2.7.0. Each tree withholds a random `block.holdout`
fraction of whole sites (default `1/3`), then draws its training sample from the
rows of the sites that remain, in exactly the ordinary way: with replacement by
default, honouring `replace` and `sampsize` (the latter scaled to the size of
the pool). The out-of-bag set is the withheld sites and nothing else.

### `"direct.use"`

The ordinary random forest, bit for bit: what RDAforest did before 2.7.0.

## Automatic detection

`sites` no longer has to be supplied. Left `NULL`, RDAforest inspects the
predictors before fitting. Coordinate columns are recognised by name
(`lon`/`lat`, `x`/`y`, `easting`/`northing` and similar) or given with `coords`;
with no coordinates identified, a site is a set of rows whose predictor values
are identical throughout.

- **No shared locations** — the individuals are used directly, silently.
- **Shared location, same environment** — treated as repeated sampling and
  handled according to `site.repeats`. With `site.repeats` left at its default
  the message is *"Data appear to contain multiple samples per site. Such
  samples will be represented as their genetic median; see option site.repeats
  for alternatives."*; naming a mode overrides the default, and the message then
  says which mode was used. Detection supplies the sites, never the mode.
- **Shared location, different environment** — *"some samples share a spatial
  location but have different environmental entries, check"* is warned, and the
  individuals are used directly, leaving the decision to you.

Telling the second case from the third needs the coordinates to be
identifiable. With no recognisable column names and no `coords`, a site can only
be a set of identical rows, so a sample that shares a location but differs in
one environmental value counts as a site of its own and nothing is warned about.

`detect_sites()` runs the check on its own and returns what it found.
`auto.sites = FALSE` switches it off; passing `sites` overrides it. The check
runs once per top-level call, so a jackknife does not repeat the message on
every replicate.

## Why it matters

In a simulation of 40 sites with 10 individuals each, two of four site-level
predictors truly driving the genetics at R² = 0.6:

| `site.repeats` | false importance (noise/real) | cross-validation R² |
|---|---|---|
| `"direct.use"` | 0.57 | 0.76 |
| `"blocked.resampling"` | 0.03 | 0.35 |
| `"genetic.median"` | 0.03 | 0.41 |

Under `"direct.use"` a predictor that merely tags an unusual site looks like a
driver, and R² overstates a relationship whose truth is 0.6. The two honest
settings agree with each other and now *understate* it, because they are working
from 40 effective observations rather than 400.

## Where the option lives

`rdaf_randomForest()`, `rdaf_gradientForest()`, `makeGF()`, `makeGF_simple()`,
`predict_rf()`, `predict_gf()`, `mtrySelJack()` and `ordinationJackknife()`.

`site_repeats_summary()` reports what a given setting implies (how many sites,
how many rows will be fitted, and for blocked resampling how large the eligible
pool is per tree) before you commit to a long run. It replaces
`oob_blocks_summary()`.

`spatial_blocks()` no longer fails when a re-split lands on a block too small to
halve (`hclust` needs at least two objects), which could happen with a small
`min.size` and many blocks.

As before, the `oob` argument of `ordinationJackknife()` and `mtrySelJack()`,
which governs how many samples are withheld when the ordination is rebuilt in
each replicate, remains a plain random draw over rows. `site.repeats` governs
the random forest fitting only.

## Deprecations

`oob.blocks` and `oob.block.holdout` are still accepted by `rdaf_randomForest()`
and `rdaf_gradientForest()`, with a warning; they map to `sites` with
`site.repeats = "blocked.resampling"` and to `block.holdout`. They will be
removed in a future version. `oob_blocks_summary()` is gone; use
`site_repeats_summary()`.

# RDAforest 2.7.0

## Blocked out-of-bag sampling

Random forest fitting can now hold out **whole pre-specified blocks of samples**
rather than whichever individual rows the bootstrap happens to miss.

Pass a categorical vector, one entry per sample, as `oob.blocks`.
`oob.block.holdout` sets the fraction of blocks withheld from each tree
(default `1/3`, rounded to a whole number of blocks).

**Blocking changes only which samples are eligible; nothing else.** Each tree
first withholds a random fraction of the blocks, then draws its training sample
from the rows of the blocks that remain, in exactly the ordinary way: with
replacement by default, so about 1 − 1/e of the eligible rows are drawn, and
honouring `replace` and `sampsize` (the latter scaled to the size of the pool).
The out-of-bag set is the withheld blocks and nothing else — a retained row that
the draw happened to miss is not scored, because its block-mates are in the
training sample.

```r
# 12 geographic blocks of at least 4 samples each
blocks <- spatial_blocks(latlon, nblocks = 12, min.size = 4)
oob_blocks_summary(blocks)

oj <- ordinationJackknife(Y = cordist, X = env, newX = envc,
                          covariates = latlon.gcd, nreps = 25,
                          oob.blocks = blocks)
```

Why it matters: when samples come in groups (several individuals per site,
siblings, sequencing batches, repeated years), a row the bootstrap missed almost
always has a near-duplicate of itself in the training set. Out-of-bag R-squared
and variable importance are then optimistic, and predictors that merely tag the
group look important. Blocked sampling scores every tree on groups it has never
seen.

The option is available on `rdaf_randomForest()`, `rdaf_gradientForest()`,
`makeGF()`, `makeGF_simple()`, `predict_rf()`, `predict_gf()`, `mtrySelJack()`
and `ordinationJackknife()`. It defaults to `NULL`, which is the ordinary
bootstrap, so existing scripts are unaffected.

Note: the `oob` argument of `ordinationJackknife()` and `mtrySelJack()`, which
governs how many samples are withheld when the **ordination** is rebuilt in each
replicate, is still a plain random draw over rows. `oob.blocks` changes the
random forest fitting only.

### New functions

* `spatial_blocks()` builds a blocking vector by clustering samples on great
  circle distances (Ward's method), merging and re-splitting until every block
  holds at least `min.size` samples.
* `oob_blocks_summary()` reports what a blocking scheme implies: number of
  blocks, block sizes, blocks withheld per tree, and the resulting range of
  eligible-pool sizes.

## The package is now self-contained

`extendedForest` and `gradientForest` are no longer dependencies. The functions
RDAforest used from them are incorporated into the package, together with the
C and Fortran random forest engine, which is what made blocked sampling
possible.

Incorporated functions are renamed with an `rdaf_` prefix so that RDAforest can
be loaded alongside the original packages without masking anything:

| was | is now |
| --- | --- |
| `extendedForest::randomForest()` | `rdaf_randomForest()` |
| `extendedForest::getTree()` | `rdaf_getTree()` |
| `extendedForest::varUsed()`, `treesize()` | `rdaf_varUsed()`, `rdaf_treesize()` |
| `gradientForest::gradientForest()` | `rdaf_gradientForest()` |
| `gradientForest::cumimp()` | `rdaf_cumimp()` |
| `importance()` (both packages) | `rdaf_importance()` |

Fitted objects have class `rdaf_randomForest` / `rdaf_gradientForest`, and
`print()`, `plot()`, `predict()` and `density()` dispatch on them as before.

Everything else is unchanged. With the same random seed and no `oob.blocks`,
the incorporated code reproduces `extendedForest` and `gradientForest` exactly:
the package's test suite asserts `identical()` on the forest structure, MSE,
R-squared, out-of-bag predictions, in-bag matrix, importances, `cumimp()` curves
and `predict()` output.

The parts of `gradientForest` that RDAforest never used — the
`combinedGradientForest` family — were not carried over.

### Consequences for installation

RDAforest now contains compiled code, so installing from source needs a C
compiler: Rtools on Windows, the Xcode command line tools on macOS,
`r-base-dev` on Linux.

**No Fortran compiler is required.** The classification tree builder that
`extendedForest` inherits from Breiman and Cutler (`rfsub.f`: `buildtree`,
`findbestsplit`, `movedata` and their helpers) has been translated to C in
`src/rfsub.c`, and `gfortran` is no longer part of the build. The translation
is deliberately literal, keeping the original column-major layout, control flow
and — critically — the exact order in which random numbers are drawn, including
two tie-breaking quirks that look like bugs but shift every subsequent draw.
The test suite pins this down: with the same seed, classification forests are
`identical()` to the Fortran ones across fourteen configurations covering
multiple classes, `mtry`, `nodesize`, sampling with and without replacement,
class weights and cutoffs, stratified sampling, proximity, local importance,
conditional permutation, categorical predictors (both the exhaustive and the
sampled-split branches) and a deliberately tie-heavy dataset.

### If you call the old functions directly

Scripts that only use RDAforest's own functions need no changes. A script that
called `gradientForest()` or `randomForest()` directly should either add the
`rdaf_` prefix, or keep loading the original packages, which still works.

## Documentation

Every incorporated function now has its own help page, and the new blocked
sampling option is documented on each function that accepts it.
`?RDAforest` gives an overview.
