## Tests for the fit-once / predict-many split of ordinationJackknife().

oj_sim <- function(n = 60, seed = 1) {
  set.seed(seed)
  X <- data.frame(temp = stats::rnorm(n), depth = stats::runif(n),
                  noise = stats::rnorm(n))
  Y <- data.frame(a = 2 * X$temp + stats::rnorm(n, 0, 0.5),
                  b = X$depth + stats::rnorm(n, 0, 0.5),
                  c = stats::rnorm(n))
  list(X = X, Y = Y, n = n)
}
quiet <- function(expr) suppressMessages(expr)

test_that("ojPredict(ojFit()) reproduces ordinationJackknife() exactly", {
  d <- oj_sim()
  set.seed(42)
  fit <- quiet(ojFit(d$Y, d$X, nreps = 3, top.pcs = 2, ntrees = 100,
                     auto.sites = FALSE))
  a <- quiet(ojPredict(fit, d$X))
  set.seed(42)
  b <- quiet(ordinationJackknife(d$Y, d$X, newX = d$X, nreps = 3, top.pcs = 2,
                                 ntrees = 100, auto.sites = FALSE))
  ## everything but the ensemble token, which is unique to each fit, and $fit,
  ## which only ordinationJackknife() carries
  for (k in setdiff(names(b), c("ensemble.id", "fit")))
    expect_identical(a[[k]], b[[k]], info = k)
})

test_that("the same holds with newX omitted and with extra/extra.npred", {
  d <- oj_sim()
  set.seed(43)
  fit <- quiet(ojFit(d$Y, d$X, nreps = 2, top.pcs = 2, ntrees = 80,
                     auto.sites = FALSE))
  set.seed(43)
  b <- quiet(ordinationJackknife(d$Y, d$X, nreps = 2, top.pcs = 2, ntrees = 80,
                                 auto.sites = FALSE))
  expect_identical(quiet(ojPredict(fit))$predictions.direct, b$predictions.direct)

  ## a grid that reaches past the modelled range on the first predictor only
  nx <- d$X
  nx$temp <- nx$temp + 0.15 * diff(range(d$X$temp))
  set.seed(43)
  c1 <- quiet(ordinationJackknife(d$Y, d$X, newX = nx, extra = 0.2,
                                  extra.npred = 1, nreps = 2, top.pcs = 2,
                                  ntrees = 80, auto.sites = FALSE))
  c2 <- quiet(ojPredict(fit, nx, extra = 0.2, extra.npred = 1))
  expect_identical(c1$predictions.direct, c2$predictions.direct)
  expect_identical(c1$goodrows, c2$goodrows)
})

test_that("one fit scores several grids through the same ensemble", {
  d <- oj_sim()
  set.seed(44)
  fit <- quiet(ojFit(d$Y, d$X, nreps = 3, top.pcs = 2, ntrees = 100,
                     auto.sites = FALSE))
  warm <- d$X; warm$temp <- warm$temp + 0.3
  p0 <- quiet(ojPredict(fit, d$X))
  p1 <- quiet(ojPredict(fit, warm, extra = 0.5, extra.npred = 1))
  ## predicting twice from one fit is deterministic
  expect_identical(p0$predictions.direct, quiet(ojPredict(fit, d$X))$predictions.direct)
  ## and the two grids give different answers, as they must
  expect_false(isTRUE(all.equal(p0$predictions.direct, p1$predictions.direct)))
  ## importances come from the fit, so they are the same whatever is scored
  expect_identical(p0$median.importance, p1$median.importance)
})

test_that("ojFit retains one set of models per successful replicate", {
  d <- oj_sim()
  set.seed(45)
  fit <- quiet(ojFit(d$Y, d$X, nreps = 3, top.pcs = 2, ntrees = 60,
                     auto.sites = FALSE))
  expect_length(fit$rf, 3L)
  expect_length(fit$gf, 3L)
  expect_equal(fit$n.models, 3L)
  expect_length(fit$rf[[1]], 2L)                     # one forest per PC
  expect_s3_class(fit$rf[[1]][[1]], "rdaf_randomForest")
  ## gradient forests are kept as their cumulative-importance curves
  expect_type(fit$gf[[1]], "list")
  expect_named(fit$gf[[1]], names(d$X))
  expect_named(fit$gf[[1]]$temp, c("x", "y"))
  ## and forests lose what prediction never reads
  expect_null(fit$rf[[1]][[1]]$predicted)
  expect_null(fit$rf[[1]][[1]]$y)
  expect_null(fit$rf[[1]][[1]]$forest$nodeSS)
  expect_equal(fit$X, d$X)
  expect_null(fit$site.repeats)
})

test_that("keep.models decides whether the ensemble comes back", {
  d <- oj_sim()
  set.seed(46)
  a <- quiet(ordinationJackknife(d$Y, d$X, newX = d$X, nreps = 2, top.pcs = 2,
                                 ntrees = 60, auto.sites = FALSE))
  set.seed(46)
  b <- quiet(ordinationJackknife(d$Y, d$X, newX = d$X, nreps = 2, top.pcs = 2,
                                 ntrees = 60, auto.sites = FALSE,
                                 keep.models = FALSE))
  ## TRUE is the default and hands the ensemble back
  expect_false(is.null(a$fit))
  expect_length(a$fit$rf, 2L)
  expect_null(b$fit)          # and not the token: $ must not partial-match
  expect_null(b$rf)
  ## and the predictions are identical either way
  for (k in c("sum.importances", "predictions.direct", "predictions.turnover",
              "median.importance", "all.importances", "goodrows", "failed.reps"))
    expect_identical(a[[k]], b[[k]], info = k)
  expect_named(b, c("sum.importances", "predictions.direct",
                    "predictions.turnover", "median.importance",
                    "all.importances", "goodrows", "failed.reps", "ensemble.id"))
})

test_that("the retained fit can score another grid without refitting", {
  d <- oj_sim()
  set.seed(53)
  a <- quiet(ordinationJackknife(d$Y, d$X, newX = d$X, nreps = 2, top.pcs = 2,
                                 ntrees = 60, auto.sites = FALSE))
  again <- quiet(ojPredict(a$fit, d$X))
  expect_identical(again$predictions.direct, a$predictions.direct)
  expect_identical(again$ensemble.id, a$ensemble.id)
  warm <- d$X; warm$temp <- warm$temp + 0.3
  p <- quiet(ojPredict(a$fit, warm, extra = 0.5, extra.npred = 1))
  expect_identical(p$ensemble.id, a$ensemble.id)
  expect_false(isTRUE(all.equal(p$predictions.direct, a$predictions.direct)))
})

test_that("site handling carries through the split", {
  set.seed(47)
  sites <- factor(rep(paste0("s", 1:12), each = 5))
  n <- length(sites); idx <- as.integer(sites)
  E <- scale(matrix(stats::rnorm(12 * 3), 12, 3))
  colnames(E) <- c("driver", "n1", "n2")
  X <- as.data.frame(E[idx, , drop = FALSE])
  Y <- data.frame(a = E[idx, 1] + stats::rnorm(n, 0, 0.5),
                  b = E[idx, 2] + stats::rnorm(n, 0, 0.5),
                  c = stats::rnorm(n))
  for (m in c("genetic.median", "blocked.resampling", "direct.use")) {
    set.seed(48)
    fit <- quiet(ojFit(Y, X, nreps = 2, top.pcs = 2, ntrees = 80,
                       sites = sites, site.repeats = m))
    expect_equal(fit$site.repeats, m, info = m)
    a <- quiet(ojPredict(fit, X))
    set.seed(48)
    b <- quiet(ordinationJackknife(Y, X, newX = X, nreps = 2, top.pcs = 2,
                                   ntrees = 80, sites = sites,
                                   site.repeats = m))
    expect_identical(a$predictions.direct, b$predictions.direct, info = m)
    expect_identical(a$median.importance, b$median.importance, info = m)
  }
})

test_that("auto-detection still decides the mode once, in ojFit", {
  set.seed(49)
  sites <- rep(paste0("s", 1:12), each = 5)
  idx <- rep(seq_len(12), each = 5); n <- length(idx)
  E <- scale(matrix(stats::rnorm(36), 12, 3)); colnames(E) <- c("d", "n1", "n2")
  X <- as.data.frame(E[idx, , drop = FALSE])
  Y <- data.frame(a = E[idx, 1] + stats::rnorm(n, 0, 0.5),
                  b = stats::rnorm(n), c = stats::rnorm(n))
  ## left alone: detection supplies sites and the genetic.median default
  set.seed(50)
  msgs <- capture_messages(fit <- ojFit(Y, X, nreps = 2, top.pcs = 2, ntrees = 60))
  expect_equal(sum(grepl("multiple samples per site", msgs)), 1L)
  expect_equal(fit$site.repeats, "genetic.median")
  ## named: the mode is honoured, and said once
  set.seed(51)
  msgs2 <- capture_messages(
    fit2 <- ojFit(Y, X, nreps = 2, top.pcs = 2, ntrees = 60,
                  site.repeats = "blocked.resampling"))
  expect_equal(sum(grepl("blocked.resampling", msgs2)), 1L)
  expect_equal(fit2$site.repeats, "blocked.resampling")
})

test_that("bad input is rejected", {
  d <- oj_sim()
  expect_error(ojPredict(list(X = d$X)), "no models")
  set.seed(52)
  fit <- quiet(ojFit(d$Y, d$X, nreps = 2, top.pcs = 2, ntrees = 60,
                     auto.sites = FALSE))
  expect_error(ojPredict(fit, d$X, extra.npred = 99), "between 0 and")
  expect_error(ojPredict(fit, d$X, extra.npred = "two"), "single number")
  expect_error(quiet(ojFit(d$Y[1:10, ], d$X, nreps = 2, auto.sites = FALSE)),
               "incompatible input matrices")
  ## extra.npred is checked before any fitting happens
  expect_error(ordinationJackknife(d$Y, d$X, extra.npred = -1), "between 0 and")
})


## ---------------------------------------------------------------------------
## the fit token, and the gen_offset_oj guard that uses it
## ---------------------------------------------------------------------------

test_that("predictions carry the token of the ensemble they came from", {
  d <- oj_sim()
  set.seed(60)
  f1 <- quiet(ojFit(d$Y, d$X, nreps = 2, top.pcs = 2, ntrees = 60,
                    auto.sites = FALSE))
  set.seed(60)
  f2 <- quiet(ojFit(d$Y, d$X, nreps = 2, top.pcs = 2, ntrees = 60,
                    auto.sites = FALSE))
  expect_type(f1$ensemble.id, "character")
  ## same seed, same numbers, but a different ensemble: different token
  expect_false(identical(f1$ensemble.id, f2$ensemble.id))
  ## every prediction from one fit carries that fit's token
  expect_identical(quiet(ojPredict(f1, d$X))$ensemble.id, f1$ensemble.id)
  expect_identical(quiet(ojPredict(f1, d$X[1:30, ]))$ensemble.id, f1$ensemble.id)
  ## and generating a token must not disturb the random number stream
  set.seed(61); x1 <- runif(3); id <- RDAforest:::.rdaf_fit_id(); x2 <- runif(3)
  set.seed(61); y <- runif(6)
  expect_equal(c(x1, x2), y)
})

test_that("gen_offset_oj warns when the two fits differ, and not when they agree", {
  d <- oj_sim(n = 40)
  xy <- data.frame(x = seq_len(40), y = seq_len(40))
  set.seed(62)
  fit <- quiet(ojFit(d$Y, d$X, nreps = 2, top.pcs = 2, ntrees = 60,
                     auto.sites = FALSE))
  warm <- d$X; warm$temp <- warm$temp + 0.3
  now <- quiet(ojPredict(fit, d$X))
  then <- quiet(ojPredict(fit, warm, extra = 1))
  ## one ensemble: no complaint
  expect_no_warning(gen_offset_oj(now, then, xy, xy))

  ## two ensembles: a warning, but the offset is still returned
  set.seed(63)
  other <- quiet(ordinationJackknife(d$Y, d$X, newX = warm, extra = 1,
                                     nreps = 2, top.pcs = 2, ntrees = 60,
                                     auto.sites = FALSE))
  expect_warning(gen_offset_oj(now, other, xy, xy), "different model fits")
  o <- suppressWarnings(gen_offset_oj(now, other, xy, xy))
  expect_true(is.data.frame(o))
  expect_true("offset" %in% names(o))

  ## objects saved before tokens existed pass unchecked
  a <- now; a$ensemble.id <- NULL; b <- other; b$ensemble.id <- NULL
  expect_no_warning(gen_offset_oj(a, b, xy, xy))
})


test_that("stored curves predict turnover exactly as the gradient forest does", {
  d <- oj_sim()
  set.seed(70)
  g <- quiet(makeGF_simple(d$Y[, 1:2], d$X, ntrees = 100, auto.sites = FALSE))
  cis <- lapply(stats::setNames(names(d$X), names(d$X)),
                function(v) rdaf_cumimp(g, v))
  ## inside the range, and beyond it at both ends
  nx <- rbind(d$X, d$X[1:5, ] + 3, d$X[6:10, ] - 3)
  expect_identical(RDAforest:::.rdaf_oj_turnover(cis, nx), predict(g, nx))
})

test_that("a fit holding whole gradient forests (as 2.9.1 saved) still predicts", {
  d <- oj_sim()
  set.seed(71)
  fit <- quiet(ojFit(d$Y, d$X, nreps = 2, top.pcs = 2, ntrees = 60,
                     auto.sites = FALSE))
  set.seed(72)
  g <- quiet(makeGF_simple(d$Y[, 1:2], d$X, ntrees = 60, auto.sites = FALSE))
  old <- fit; old$gf <- list(g, g)
  new <- fit; new$gf <- rep(list(lapply(stats::setNames(names(d$X), names(d$X)),
                                        function(v) rdaf_cumimp(g, v))), 2)
  expect_identical(quiet(ojPredict(old, d$X)), quiet(ojPredict(new, d$X)))
})
