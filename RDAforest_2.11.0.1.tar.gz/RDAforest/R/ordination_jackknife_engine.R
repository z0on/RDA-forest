## ---------------------------------------------------------------------------
## The engine behind ordinationJackknife().
##
## Each replicate fits its models, scores every environment it was given, and
## lets the models go, so the ensemble is never held in memory however many
## environments are scored, and all of them go through the same replicates.
## ---------------------------------------------------------------------------

## Get newX ready for scoring: keep the model's predictors, set aside rows
## with missing values, and clamp the rest into the range the model saw (a
## forest is flat beyond its data anyway; clamping keeps the turnover curves
## flat too, rather than extrapolating them).  Which rows are too novel to
## predict is decided after the fit, once importances are known (see
## .rdaf_oj_assemble), so every complete row is scored.
.rdaf_prepare_newX <- function(newX, X) {
  if (is.null(newX))
    return(list(newX = X, raw = X, complete = rep(TRUE, nrow(X)), is.X = TRUE))
  miss <- setdiff(colnames(X), colnames(newX))
  if (length(miss))
    stop("newX lacks predictor(s) used by the model: ", paste(miss, collapse = ", "),
         call. = FALSE)
  ## newX's own column order and row names, as earlier versions returned them
  newX <- newX[, colnames(newX) %in% colnames(X), drop = FALSE]
  complete <- stats::complete.cases(newX)
  if (.row_names_info(newX) > 0) names(complete) <- rownames(newX)
  raw <- newX[complete, , drop = FALSE]
  cl <- raw
  ranges <- apply(X, 2, range)
  for (v in colnames(cl))
    cl[, v] <- pmin(pmax(cl[, v], ranges[1, v]), ranges[2, v])
  list(newX = cl, raw = raw, complete = complete, is.X = FALSE)
}

## The cumulative-importance (turnover) curve of every predictor in a
## gradient forest: all that turnover prediction reads.  Computed once per
## replicate and used for every environment.
.rdaf_oj_curves <- function(gf, vars)
  lapply(stats::setNames(vars, vars), function(v) rdaf_cumimp(gf, v))

## A replicate's direct-prediction forests without the parts only used while
## fitting or for in-sample summaries (node sums of squares and improvements,
## the out-of-bag predictions and counts, the response): predict() with new
## data never reads them.  This roughly halves what keep.models returns.
.rdaf_oj_strip <- function(rf) {
  for (j in seq_along(rf)) {
    rf[[j]]$forest$nodeSS <- NULL; rf[[j]]$forest$nodeImprove <- NULL
    rf[[j]]$predicted <- NULL; rf[[j]]$y <- NULL; rf[[j]]$oob.times <- NULL
  }
  rf
}

## Turnover prediction from cumulative-importance curves: the body of
## predict.rdaf_gradientForest(object, newdata, extrap = TRUE), with the call
## to rdaf_cumimp() replaced by a curve computed once per replicate.
.rdaf_oj_turnover <- function(cis, newdata, extrap = TRUE) {
  out <- newdata
  for (varX in names(newdata)) {
    ci <- cis[[varX]]
    if (is.null(ci))
      stop("the following predictor is not in the fitted ensemble: ", varX)
    if (length(ci$x) == 1) {
      out[, varX] <- ci$y
    } else {
      f <- stats::approxfun(ci, rule = 1)
      out[, varX] <- f(newdata[, varX])
      xold <- range(ci$x)
      yold <- range(ci$y)
      if (xold[1] == xold[2])
        stop(paste0("variable [", varX, "] has badly formed cumulative importance curve:\n ", ci))
      grad_norm <- diff(yold)
      upper_extrap <- newdata[, varX] > xold[2]
      if (length(upper_extrap) > 0) {
        upper_norm <- (newdata[upper_extrap, varX] - min(xold)) / (max(xold) - min(xold))
        out[upper_extrap, varX] <- .rdaf_compress_extrap(upper_norm - 1, as.numeric(extrap), grad_norm, yold[2])
      }
      lower_extrap <- newdata[, varX] < xold[1]
      if (length(lower_extrap) > 0) {
        lower_norm <- (newdata[lower_extrap, varX] - min(xold)) / (max(xold) - min(xold))
        out[lower_extrap, varX] <- -.rdaf_compress_extrap(-lower_norm, as.numeric(extrap), grad_norm, -yold[1])
      }
    }
  }
  class(out) <- c("predict.rdaf_gradientForest", "data.frame")
  out
}

## Score one replicate's models on one environment.
## With `rot` (align = "predictions"), the forests were fitted to the
## replicate's own axes, and their predictions are rotated onto the full
## ordination's axes here: c (Y - ymean) A, as procrustes() rotates the
## replicate's sample scores.
.rdaf_oj_predict_one <- function(rf, curves, newX, rot = NULL) {
  Yp <- list()
  for (j in seq_along(rf)) {
    message("predicting mds ", j)
    Yp[[j]] <- predict(rf[[j]], newX)
  }
  d <- data.frame(do.call(cbind, Yp))
  if (!is.null(rot)) {
    nm <- names(d)
    d <- data.frame(rot$c * sweep(as.matrix(d), 2, rot$ymean) %*% rot$A)
    names(d) <- nm
  }
  message("predicting turnover")
  list(d = d, t = .rdaf_oj_turnover(curves, newX))
}

## A token identifying one run's ensemble, carried by every prediction set it
## produced, so that gen_offset_oj() can tell whether two prediction sets came
## from the same replicates.  tempfile() gives a unique string without
## touching the random number stream.
.rdaf_fit_id <- function()
  paste0("oj.", format(Sys.time(), "%Y%m%d%H%M%S"), ".",
         sub("^file", "", basename(tempfile(pattern = "file"))))

## Drop the environments that fail the novelty rules, rescale the averaged
## turnover curves and put the return value together.  `prep` is what
## .rdaf_prepare_newX() made of this environment, `rules` what
## .rdaf_novelty_rules() made of the limits, `g` the environment's index and
## `ref` the novelty reference (NULL if it could not be built).
.rdaf_oj_assemble <- function(pred.d, pred.t, fit, prep, rules, g, ref, X, label = NULL) {
  nc <- sum(prep$complete)
  nov <- data.frame(sigma = rep(NA_real_, length(prep$complete)), nn = NA_real_)
  if (!is.null(ref)) nov[prep$complete, ] <- .rdaf_novelty_score(ref, prep$raw)
  sig <- rules$sigma[g]; nnm <- if (rules$nn.auto) ref$nn.auto else rules$nn.max[g]
  fail.s <- fail.n <- fail.r <- rep(FALSE, nc)
  if (!prep$is.X) {
    if (is.finite(sig)) fail.s <- nov$sigma[prep$complete] > sig
    if (is.finite(nnm)) fail.n <- nov$nn[prep$complete] > nnm
    if (rules$use.range)
      fail.r <- !.rdaf_within_range(prep$raw, X, rules$extra[g], rules$extra.npred[g])
  }
  keep <- !(fail.s | fail.n | fail.r)
  goodrows <- prep$complete
  goodrows[prep$complete] <- keep
  if (!prep$is.X && (is.finite(sig) || is.finite(nnm) || rules$use.range)) {
    why <- c(if (is.finite(sig)) paste0(sum(fail.s), " beyond sigma = ", sig),
             if (is.finite(nnm)) paste0(sum(fail.n), " beyond nn.max = ", signif(nnm, 3),
                                         if (rules$nn.auto) " (auto)" else ""),
             if (rules$use.range) paste0(sum(fail.r), " beyond the range allowed by extra = ",
                                         rules$extra[g]))
    nn <- sum(!keep)
    message(if (!is.null(label)) paste0(label, ": ") else "", nn, " of ", length(goodrows),
            " environments (", round(100 * nn / length(goodrows), 1), "%) are not predicted: ",
            paste(why, collapse = ", "),
            if (length(why) > 1) " (some fail more than one)" else "",
            if (sum(!prep$complete)) paste0("; ", sum(!prep$complete), " more have missing predictor values") else "")
  }
  pred.d <- pred.d[keep, , drop = FALSE]
  rownames(pred.d) <- NULL   # numbered 1..n, as in earlier versions
  pred.t <- pred.t[keep, , drop = FALSE]
  importances <- fit$median.importance
  for (m in colnames(pred.t))
    pred.t[, m] <- decostand(pred.t[, m], method = "range") * importances[m]
  limits <- c(sigma = sig, nn.max = nnm, extra = rules$extra[g], extra.npred = rules$extra.npred[g])
  list(sum.importances = fit$sum.importances, predictions.direct = pred.d,
       predictions.turnover = pred.t, median.importance = importances,
       all.importances = fit$all.importances, goodrows = goodrows,
       novelty = nov, limits = limits,
       failed.reps = fit$failed.reps, ensemble.id = fit$ensemble.id)
}

## Novelty reference for a fit, with a note if some sampled environments are
## themselves beyond sigma (a sign of a heavy-tailed sample, not an error).
## When no distance test is in use (range rule only) a failure to build the
## reference is not fatal: novelty is then reported as NA.
.rdaf_oj_novelty_ref <- function(X, importance, rules, nn.k) {
  needed <- any(is.finite(rules$sigma)) || rules$nn.auto || any(is.finite(rules$nn.max))
  ref <- tryCatch(.rdaf_novelty_ref(X, importance, nn.k),
                  error = function(e) if (needed) stop(e) else NULL)
  if (is.null(ref)) return(NULL)
  s <- min(rules$sigma)
  if (is.finite(s)) {
    own <- .rdaf_novelty_score(ref, X)$sigma
    if (any(own > s))
      message(sum(own > s), " of the sampled environments are themselves more than sigma = ", s,
              " from the centre (max ", round(max(own), 2),
              "); environments like them elsewhere will not be predicted. Consider a larger sigma.")
  }
  ref
}

## Run the jackknife.  `newXs` is a list of environments already filtered by
## .rdaf_filter_newX(); the result holds, for each of them, the direct and
## turnover predictions averaged over the successful replicates, plus the
## importances, and, with keep.models, every replicate's fitted models.  The random number stream is consumed exactly as in earlier
## versions of ordinationJackknife().
.rdaf_oj_run=function(Y,X,newXs,oob=0.2,covariates=NULL,nreps=25,top.pcs=15,rescale2npcs=FALSE,mtry=NULL,ntrees=1500,sites=NULL,site.repeats="genetic.median",explicit=FALSE,block.holdout=1/3,coords=NULL,auto.sites=TRUE,ncores=1,keep.models=FALSE,align="predictions") {
  ncores=.rdaf_check_ncores(ncores,nreps)
  # resolve and validate the site.repeats setting up front, once only
  .res=.rdaf_resolve_sites(X,sites,site.repeats,coords,auto.sites,explicit)
  sites=.res$sites; site.repeats=.res$site.repeats
  srep=.rdaf_check_site_repeats(sites,nrow(X),site.repeats,block.holdout)
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  if(rescale2npcs==TRUE){rescale2npcs=top.pcs } else {rescale2npcs=NULL }
  # setting mtry to N/3 or 2 (note: the default is N/3 or 1)
  if (is.null(mtry)){ mt=min(max(floor(ncol(X)/3),2),ncol(X)) } else { mt=mtry }
  failed.reps=0;v.order=NULL
  # site handling for the direct-prediction forests, as in predict_rf()
  fit.sites=if(srep$mode=="blocked.resampling") srep$factor else NULL
  imps=c();replicate=c();impsum=c();n.models=0;models=list()
  ng=length(newXs); sum.d=vector("list",ng); sum.t=vector("list",ng)

  ords.full=.rdaf_ord_full(Y,covariates)
  sc.full=scores(ords.full,scaling=1,display="sites",choices=c(1:length(ords.full$CA$eig)))

  # one replicate: fit, score every environment, return the predictions and
  # importances; the models go out of scope here.  It may run in a worker
  # process (ncores > 1), so it only reads from this frame.
  one.rep=function(i){
    message("\nreplicate ",i)
    ib.keep=sample(1:nrow(Y),round(nrow(Y)*(1-oob)))
    oo=.rdaf_ord_rep(Y,ib.keep,covariates); ords0=oo$ords0; ords=oo$ords
    # align the replicate's ordination with the full-data one, so that gPC k
    # means the same thing in every replicate and predictions can be averaged.
    #  "predictions" (default): model the replicate's own, unrotated axes, and
    #     rotate only their predictions, onto the full top.pcs axes, before
    #     averaging (turnover curves are in predictor units: no rotation);
    #  "top.pcs": rotate the replicate's own top.pcs axes onto the full
    #     top.pcs axes, and model the rotated axes;
    #  "all": rotate over all axes, which puts the in-bag samples back almost
    #     exactly where the full ordination has them (versions before 2.11).
    k=min(top.pcs,ncol(ords),ncol(sc.full))
    rot=NULL
    if(align=="all") {
      orr=data.frame(procrustes(sc.full,ords,scale = T)$Yrot)
    } else {
      pr=procrustes(sc.full[,1:k,drop=FALSE],ords[,1:k,drop=FALSE],scale = T)
      if(align=="top.pcs") {
        orr=data.frame(pr$Yrot)
      } else {
        orr=data.frame(ords[,1:k,drop=FALSE])
        rot=list(A=pr$rotation,c=pr$scale,ymean=colMeans(ords[,1:k,drop=FALSE]))
      }
    }
    names(orr)[1:top.pcs]=colnames(sc.full)[1:top.pcs]
    gf1=makeGF_simple(orr[,1:top.pcs,drop=FALSE],X,ntrees=ntrees,mtry=mt,sites=sites,site.repeats=site.repeats,block.holdout=block.holdout,auto.sites=FALSE)
    if(is.null(gf1)) {
      message("   ... nothing is predictable. Moving to next rep")
      return(list(failed=TRUE))
    }
    # direct-prediction forests, fitted exactly as predict_rf() fits them
    Yf=orr[,1:top.pcs,drop=FALSE]; Xf=X
    if(srep$mode=="genetic.median"){
      coll=.rdaf_collapse_sites(X,Yf,srep$factor)
      Xf=coll$X; Yf=coll$Y
    }
    rf=list()
    for(j in 1:ncol(Yf)){
      pc=Yf[,j]
      rf[[j]]=rdaf_randomForest(x=Xf,y=pc,sites=fit.sites,site.repeats="blocked.resampling",block.holdout=block.holdout,auto.sites=FALSE,ntree=ntrees,mtry=mt)
    }
    # variable order is taken from the first successful replicate, so every
    # replicate reports it and the caller keeps the first
    vnames=names(importance_RDAforest(gf1,ords0))
    ii=importance_RDAforest(gf1,ords0,rescale2npcs=rescale2npcs)
    curves=.rdaf_oj_curves(gf1,colnames(X))
    preds=lapply(newXs,function(nx) .rdaf_oj_predict_one(rf,curves,nx,rot))
    out=list(failed=FALSE,preds=preds,vnames=vnames,ii=ii)
    # keep only what prediction reads (see .rdaf_oj_strip)
    if(keep.models) out$models=list(replicate=i,rf=.rdaf_oj_strip(rf),curves=curves,rot=rot)
    out
  }
  # gather the replicates in order, as they come back, summing predictions
  collect=function(i,r){
    if(r$failed) { failed.reps<<-failed.reps+1; return(invisible()) }
    if(is.null(v.order)) { v.order<<-r$vnames }
    for(g in seq_len(ng)){
      p=r$preds[[g]]
      if(n.models==0){ sum.d[[g]]<<-p$d; sum.t[[g]]<<-p$t }
      else { sum.d[[g]]<<-sum.d[[g]]+p$d; sum.t[[g]]<<-sum.t[[g]]+p$t }
    }
    if(keep.models) models[[length(models)+1]]<<-r$models
    n.models<<-n.models+1
    ii=r$ii[v.order]
    imps<<-c(imps,ii)
    replicate<<-c(replicate,rep(i,length(v.order)))
    impsum<<-c(impsum,sum(ii))
  }
  # replicates are dispatched ncores at a time and summed as they arrive, so
  # memory stays bounded by one batch
  .rdaf_run_reps(nreps,one.rep,collect,ncores,batch=ncores)
  if(!n.models) { stop("every replicate failed: nothing is predictable") }

  # computing median importances of variables
  dimps=data.frame(imps)
  dimps$replicate=replicate
  dimps$variable=names(imps)
  names(dimps)[1]="importance"
  meds=dimps%>%
    group_by(variable)%>%
    summarise(median(importance))
  meds=as.data.frame(meds)
  importances=meds$`median(importance)`
  names(importances)=meds$variable

  # releveling variables according to median importance
  varorder=meds$variable[order(meds[,2],decreasing=T)]
  importances=importances[varorder]
  dimps$variable=factor(dimps$variable,levels=rev(varorder))
  out=list(pred=lapply(seq_len(ng),function(g) list(d=sum.d[[g]]/n.models,t=sum.t[[g]]/n.models)),
           n.models=n.models,ensemble.id=.rdaf_fit_id(),
           sum.importances=impsum,median.importance=importances,
           all.importances=dimps,failed.reps=failed.reps)
  if(keep.models){
    # everything ojPredict() needs to score further environments exactly as
    # this run scored its own
    out$models=structure(list(reps=models,X=X,n.models=n.models,
                              ensemble.id=out$ensemble.id,
                              sum.importances=impsum,median.importance=importances,
                              all.importances=dimps,failed.reps=failed.reps),
                         class="rdaf_oj_models")
  }
  out
}


## Check and normalise newX (one environment, a list of them, or NULL), as
## ordinationJackknife() and ojPredict() take it.
## `reserved` is a name an environment may not have.
.rdaf_parse_newX <- function(newX, reserved = NULL) {
  multi <- is.list(newX) && !is.data.frame(newX)
  grids <- if (multi) newX else list(newX)
  ng <- length(grids)
  if (multi) {
    if (!ng) stop("newX is an empty list", call. = FALSE)
    nm <- names(grids)
    if (is.null(nm)) nm <- rep("", ng)
    nm[is.na(nm) | nm == ""] <- paste0("newX", which(is.na(nm) | nm == ""))
    if (anyDuplicated(nm)) stop("the environments in newX must have distinct names", call. = FALSE)
    if (!is.null(reserved) && reserved %in% nm)
      stop("an environment in newX may not be called '", reserved,
           "': that name holds the fitted models", call. = FALSE)
    names(grids) <- nm
    for (g in seq_len(ng))
      if (!is.null(grids[[g]]) && !is.data.frame(grids[[g]]))
        stop("every element of newX must be a data frame of predictors (or NULL, for the predictors in X)",
             call. = FALSE)
  } else if (!is.null(newX) && !is.data.frame(newX)) {
    stop("newX must be a data frame of predictors, or a list of them", call. = FALSE)
  }
  list(multi = multi, grids = grids)
}

#' Score new environments with the models kept by ordinationJackknife
#'
#' \code{\link{ordinationJackknife}} with \code{keep.models = TRUE} returns
#' the fitted models of every replicate. \code{ojPredict} scores further
#' environments with them, without refitting: the predictions are exactly what
#' \code{ordinationJackknife} would have returned had those environments been
#' in its \code{newX}, and they carry the same \code{ensemble.id}, so they can
#' be compared with the original run's predictions in
#' \code{\link{gen_offset_oj}}.
#'
#' Only what prediction reads is kept: each replicate's random forests without
#' their training-only parts, and its gradient forest as the turnover curve of
#' every predictor. For the wolves example at the defaults (25 replicates, 15
#' principal components, 1500 trees) that is about 1.3 GB.
#'
#' @param models the \code{$models} element of an \code{ordinationJackknife}
#'   result made with \code{keep.models = TRUE}, or that result itself.
#' @param newX new matrix of predictors to score, or a named list of them, as
#'   in \code{\link{ordinationJackknife}}. If omitted, the predictors the
#'   models were fitted on are scored.
#' @param sigma,nn.max,nn.k,extra,extra.npred the novelty rules, as in
#'   \code{\link{ordinationJackknife}}: which environments are too novel to
#'   predict. Each may be one value, or one per environment when \code{newX}
#'   is a list (except \code{nn.k}; \code{nn.max} may also be \code{"auto"}). Giving \code{extra} or \code{extra.npred}
#'   switches to the range rule of earlier versions.
#' @param ncores number of CPU cores to predict on (default 1). Replicates are
#'   scored that many at a time; the result is identical to \code{ncores = 1},
#'   and no random numbers are used. With socket clusters (Windows) each
#'   batch's models are copied to the workers.
#' @return As \code{\link{ordinationJackknife}}: a result for one environment,
#'   or a named list of them.
#' @seealso \code{\link{ordinationJackknife}}, \code{\link{gen_offset_oj}}
#' @examples
#' \donttest{
#' set.seed(1)
#' n <- 60
#' X <- data.frame(temp = rnorm(n), depth = runif(n), noise = rnorm(n))
#' D <- dist(data.frame(a = 2 * X$temp + rnorm(n), b = X$depth + rnorm(n)))
#' now <- ordinationJackknife(D, X, nreps = 3, top.pcs = 2, ntrees = 100,
#'                            auto.sites = FALSE, keep.models = TRUE)
#' ## a warmer world, scored later through the same forests
#' future <- X; future$temp <- future$temp + 0.5
#' then <- ojPredict(now, future)
#' summary(then$novelty)
#' ## or the range rule of earlier versions
#' then2 <- ojPredict(now, future, extra = 0.2, extra.npred = 1)
#' }
#' @import vegan
#' @export
ojPredict=function(models,newX=NULL,sigma=4,nn.max=3,nn.k=5,extra=NULL,extra.npred=NULL,ncores=1) {
  if(!inherits(models,"rdaf_oj_models")) {
    if(is.list(models) && inherits(models$models,"rdaf_oj_models")) models=models$models
    else stop("models must come from ordinationJackknife(..., keep.models = TRUE): pass its result, or its $models")
  }
  X=models$X
  pg=.rdaf_parse_newX(newX)
  rules=.rdaf_novelty_rules(length(pg$grids),ncol(X),sigma,nn.max,extra,extra.npred,
                            !missing(sigma),!missing(nn.max))
  n=length(models$reps)
  ncores=.rdaf_check_ncores(ncores,n)
  flts=lapply(seq_along(pg$grids),function(g) .rdaf_prepare_newX(pg$grids[[g]],X))
  newXs=lapply(flts,function(f) f$newX)
  ng=length(newXs)
  acc=new.env(parent=emptyenv()); acc$n=0; acc$d=vector("list",ng); acc$t=vector("list",ng)
  # replicates are summed in order whichever way they were computed, so the
  # result does not depend on ncores
  collect=function(ps){
    for(g in seq_len(ng)){
      p=ps[[g]]
      if(acc$n==0){ acc$d[[g]]=p$d; acc$t[[g]]=p$t } else { acc$d[[g]]=acc$d[[g]]+p$d; acc$t[[g]]=acc$t[[g]]+p$t }
    }
    acc$n=acc$n+1
  }
  if(ncores<=1){
    for(i in seq_len(n)){
      message("\nreplicate ",i," of ",n)
      collect(.rdaf_oj_predict_task(models$reps[[i]],newXs))
    }
  } else {
    .rdaf_predict_reps(models$reps,newXs,ncores,collect)
  }
  ref=.rdaf_oj_novelty_ref(X,models$median.importance,rules,nn.k)
  outs=lapply(seq_len(ng),function(g) .rdaf_oj_assemble(acc$d[[g]]/n,acc$t[[g]]/n,models,flts[[g]],rules,g,ref,X,
                                                         if(pg$multi) names(pg$grids)[g] else NULL))
  if(!pg$multi) return(outs[[1]])
  names(outs)=names(pg$grids)
  outs
}

#' Print the models kept by ordinationJackknife
#'
#' @param x models from \code{ordinationJackknife(..., keep.models = TRUE)}.
#' @param ... not used.
#' @return \code{x}, invisibly.
#' @method print rdaf_oj_models
#' @export
print.rdaf_oj_models=function(x,...) {
  cat("ordinationJackknife models:",length(x$reps),"replicates,",
      length(x$reps[[1]]$rf),"principal components,",ncol(x$X),"predictors (",
      paste(colnames(x$X),collapse=", "),")\n")
  cat("ensemble.id:",x$ensemble.id,"\n")
  cat("size:",format(utils::object.size(x),units="auto"),"\n")
  cat("score further environments with ojPredict()\n")
  invisible(x)
}
