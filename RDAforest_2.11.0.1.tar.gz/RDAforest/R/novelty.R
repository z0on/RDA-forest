## ---------------------------------------------------------------------------
## Environmental novelty: how far an environment lies from the environments the
## model was built on, as an importance-weighted Mahalanobis distance expressed
## in standard deviations.
##
## A plain Mahalanobis distance cannot be weighted by rescaling the predictors:
## it is unchanged by any rescaling (that is its point).  So the predictors are
## first decorrelated, and the weights applied afterwards.  The decorrelation
## is the symmetric ("Mahalanobis" or ZCA) whitening u = R^(-1/2) z, where z
## are the standardised predictors and R their correlation matrix: of all the
## ways to make the predictors uncorrelated it is the one that changes them
## least, so component j of u still stands for predictor j and can carry its
## importance.  (Weighting principal components instead does not work: when
## eigenvalues are close, the components are an arbitrary rotation.)  Then
##     Q = sum_j w_j u_j^2        (w = importances scaled to average 1).
## With equal importances Q is the ordinary squared Mahalanobis distance; a
## predictor of no importance that is uncorrelated with the others drops out;
## novel combinations (warm AND wet where the samples were warm-dry or
## cool-wet) are caught as well as novel values, because whitening turns an
## unusual combination into large u.
##
## Q is then turned into "sigma", the number of standard deviations a single
## normal variable would have to lie from its mean to be as unusual.  Under
## multivariate normality u is standard normal, so Q is a weighted sum of
## chi-square(1) variables, approximated (Satterthwaite) by c * chi-square(nu)
## with c = sum(w^2) / sum(w) and nu = sum(w)^2 / sum(w^2), the effective
## number of predictors.  (With collinear predictors the eigenvalues of
## W^(1/2) P W^(1/2), P the projection onto the axes kept, replace w.)  With
## one predictor carrying all the importance sigma is simply its |z|; with p
## equally important ones sigma = 4 needs a squared Mahalanobis distance of
## qchisq(1 - 6.3e-5, p), which keeps ordinary samples from being flagged just
## because there are many predictors.
##
## The centre-based distance cannot see that the samples are lopsided: if all
## samples lie at the cool end of a temperature gradient, a place hotter than
## any of them may be only moderately far from the centre.  So there is a
## second test, in the same importance-weighted whitened space: the mean
## distance to the nn.k nearest distinct sampled environments, divided by the
## median of the same quantity among the sampled environments themselves
## (each leaving itself out) - "how many times farther from the samples than
## the samples typically are from each other".  It flags places beyond the
## edge of the sampled cloud on its thin side, and gaps inside it.
## ---------------------------------------------------------------------------

## Reference for novelty: the distinct sampled environments and the weights.
.rdaf_novelty_ref <- function(X, importance = NULL, nn.k = 5) {
  X <- as.data.frame(X)
  vars <- colnames(X)
  R <- unique(as.matrix(X))
  if (nrow(R) < 3)
    stop("at least three distinct sampled environments are needed to measure novelty")
  mu <- colMeans(R)
  s <- apply(R, 2, stats::sd)
  if (any(s == 0))
    stop("predictor(s) with no variation among the sampled environments: ",
         paste(vars[s == 0], collapse = ", "))
  e <- eigen(stats::cor(R), symmetric = TRUE)
  ## axes the samples do not span (collinear predictors, or fewer distinct
  ## environments than predictors) cannot be measured along: leave them out
  k <- e$values > max(e$values) * 1e-8
  A <- e$vectors[, k, drop = FALSE]
  lam <- e$values[k]
  if (is.null(importance)) {
    w <- stats::setNames(rep(1, length(vars)), vars)
  } else {
    if (is.list(importance) && !is.null(importance$median.importance))
      importance <- importance$median.importance
    if (!is.numeric(importance) || is.null(names(importance)))
      stop("importance must be a named numeric vector (for example the median.importance of an ordinationJackknife result)")
    miss <- setdiff(vars, names(importance))
    if (length(miss))
      stop("importance has no value for: ", paste(miss, collapse = ", "))
    w <- importance[vars]
  }
  w[!is.finite(w) | w < 0] <- 0
  if (sum(w) <= 0) stop("all importances are zero: nothing to weight novelty by")
  w <- w / mean(w)
  ## symmetric inverse square root of the correlation matrix, over the axes kept
  M <- A %*% (t(A) / sqrt(lam))
  ## eigenvalues of the quadratic form, for the chi-square approximation
  sw <- sqrt(w)
  ev <- eigen(sw * tcrossprod(A) * rep(sw, each = length(sw)), symmetric = TRUE,
              only.values = TRUE)$values
  ev <- ev[ev > max(ev) * 1e-10]
  ref <- list(vars = vars, mu = mu, s = s, M = M, w = w,
              c = sum(ev^2) / sum(ev), nu = sum(ev)^2 / sum(ev^2), n.env = nrow(R))
  ## the sampled environments in the weighted whitened space, and their
  ## typical spacing (mean distance to the k nearest others)
  if (!is.numeric(nn.k) || length(nn.k) != 1 || is.na(nn.k) || nn.k < 1)
    stop("nn.k must be a positive whole number")
  ref$k <- as.integer(min(round(nn.k), nrow(R) - 1))
  ref$S <- .rdaf_novelty_coords(ref, R)
  D <- as.matrix(stats::dist(ref$S)); diag(D) <- Inf
  ref$own.nn <- .rdaf_knn_mean(D, ref$k)
  ref$spacing <- stats::median(ref$own.nn)
  if (!(ref$spacing > 0)) stop("the sampled environments are too few or too alike to measure spacing")
  ## data-driven limit for nn (nn.max = "auto"): the upper whisker of the
  ## sampled environments' own nn values, Q3 + 1.5 IQR, as in the area of
  ## applicability of Meyer & Pebesma (2021)
  own <- ref$own.nn / ref$spacing
  ref$nn.auto <- unname(stats::quantile(own, 0.75) + 1.5 * stats::IQR(own))
  ref
}

## Coordinates in the importance-weighted whitened space, where the plain
## Euclidean distance is the weighted distance used throughout.
.rdaf_novelty_coords <- function(ref, M) {
  Z <- scale(as.matrix(M[, ref$vars, drop = FALSE]), ref$mu, ref$s)
  sweep(Z %*% ref$M, 2, sqrt(ref$w), "*")
}

## Mean of the k smallest entries in each row of a distance matrix.
.rdaf_knn_mean <- function(D, k) {
  if (k == 1) return(apply(D, 1, min))
  apply(D, 1, function(d) mean(sort.int(d, partial = seq_len(k))[seq_len(k)]))
}

## nn novelty of the rows of V (weighted whitened coordinates), in chunks so
## that a large grid never needs its whole distance matrix at once.
.rdaf_nn_novelty <- function(ref, V, chunk = 5000) {
  out <- numeric(nrow(V))
  s2 <- rowSums(ref$S^2)
  for (st in seq(1, nrow(V), by = chunk)) {
    i <- st:min(st + chunk - 1, nrow(V))
    Vi <- V[i, , drop = FALSE]
    D <- sqrt(pmax(outer(rowSums(Vi^2), s2, "+") - 2 * tcrossprod(Vi, ref$S), 0))
    out[i] <- .rdaf_knn_mean(D, ref$k)
  }
  out / ref$spacing
}

## Both novelty measures for every row of newX: a data frame with columns
## sigma (distance from the centre, in SDs) and nn (distance to the nearest
## samples, in units of their typical spacing).
.rdaf_novelty_score <- function(ref, newX) {
  miss <- setdiff(ref$vars, colnames(newX))
  if (length(miss))
    stop("newX lacks predictor(s) used by the model: ", paste(miss, collapse = ", "))
  V <- .rdaf_novelty_coords(ref, newX)
  Q <- rowSums(V^2)
  ## on the log scale, so that very remote environments still get a finite sigma
  lp <- stats::pchisq(Q / ref$c, ref$nu, lower.tail = FALSE, log.p = TRUE)
  sig <- stats::qnorm(lp - log(2), lower.tail = FALSE, log.p = TRUE)
  sig[Q == 0] <- 0
  nn <- rep(NA_real_, nrow(V))
  ok <- stats::complete.cases(V)
  if (any(ok)) nn[ok] <- .rdaf_nn_novelty(ref, V[ok, , drop = FALSE])
  data.frame(sigma = sig, nn = nn)
}

#' Environmental novelty relative to the sampled environments
#'
#' How unusual each environment in \code{newX} is compared with the
#' environments the model was built on (\code{X}), by two importance-weighted
#' distances: from the centre of the sampled environments (\code{sigma}, in
#' standard deviations) and from the nearest sampled environments (\code{nn},
#' in units of their typical spacing). These are what
#' \code{\link{ordinationJackknife}} and \code{\link{ojPredict}} use, through
#' their \code{sigma} and \code{nn.max} arguments, to decide which environments
#' are too novel to predict; \code{envNovelty} returns the values themselves,
#' for mapping.
#'
#' \strong{sigma.} The distance is measured from the centre (mean) of the distinct sampled
#' environments, taking their correlations into account, so an environment is
#' novel either because a predictor takes an unusual value or because the
#' predictors combine in a way the samples never did (warm and wet where the
#' samples were warm-dry or cool-wet). Importance cannot enter by rescaling
#' the predictors, because the Mahalanobis distance is unchanged by rescaling.
#' Instead the standardised predictors are decorrelated by symmetric
#' (Mahalanobis, or ZCA) whitening, which keeps each whitened component tied
#' to its own predictor, and the squared components are summed with the
#' importances as weights. With equal importances this is the ordinary
#' Mahalanobis distance; a predictor of no importance that is uncorrelated
#' with the others does not count at all.
#'
#' The squared distance is converted to \code{sigma}, the number of standard
#' deviations a single normally distributed variable would have to lie from
#' its mean to be equally unusual, using a chi-square approximation with the
#' effective number of predictors as degrees of freedom. So \code{sigma = 4}
#' means "as unusual as a 4-SD value of one variable" (two-sided probability
#' 6e-5) whatever the number of predictors. With one dominant predictor it is
#' simply that predictor's distance from its mean in standard deviations.
#'
#' \strong{nn.} Distance from the centre cannot tell whether the samples are
#' lopsided: if they all lie at the cool end of a temperature gradient, a place
#' hotter than any of them may still be moderately close to the centre. So the
#' second measure is the mean distance, in the same weighted and whitened
#' space, from an environment to its \code{nn.k} nearest distinct sampled
#' environments, divided by the median of that quantity among the sampled
#' environments themselves (each leaving itself out). \code{nn = 3} means
#' three times farther from the samples than the samples typically are from
#' one another. It is large beyond the edge of the sampled cloud, on any side,
#' and in gaps within it. Averaging over several neighbours keeps a single
#' isolated sample from vouching for a whole region. The same kind of measure
#' (distance to the nearest training sample in importance-weighted predictor
#' space, relative to the spacing of the training samples) defines the "area
#' of applicability" of Meyer & Pebesma (2021); the difference here is that
#' the predictors are also decorrelated. Their data-driven limit, the upper
#' whisker (third quartile plus 1.5 interquartile ranges) of the sampled
#' environments' own \code{nn} values, is available as \code{nn.max = "auto"}
#' in \code{\link{ordinationJackknife}}. The sampled environments' own values
#' are computed leaving each out; an environment in \code{newX} identical to a
#' sampled one counts that sample among its neighbours.
#'
#' @param X data frame of the predictors the model was built on (one row per
#'   sample).
#' @param newX data frame of environments to assess; must contain the columns
#'   of \code{X}. Defaults to \code{X} itself.
#' @param importance named vector of predictor importances, or an
#'   \code{ordinationJackknife} result (its \code{median.importance} is used).
#'   \code{NULL} (the default) weights all predictors equally.
#' @param nn.k number of nearest sampled environments to average over for
#'   \code{nn} (default 5; at most the number of distinct sampled
#'   environments minus one).
#' @return A data frame with columns \code{sigma} and \code{nn}, one row per
#'   row of \code{newX}, with attributes \code{nu} (effective number of
#'   predictors), \code{weights} (importances scaled to average 1) and
#'   \code{spacing} (the typical spacing of the sampled environments, the
#'   unit of \code{nn}) and \code{nn.auto} (the limit \code{nn.max = "auto"}
#'   would use).
#' @references Meyer H, Pebesma E (2021) Predicting into unknown space?
#'   Estimating the area of applicability of spatial prediction models.
#'   Methods in Ecology and Evolution 12: 1620-1633.
#' @seealso \code{\link{ordinationJackknife}}, \code{\link{ojPredict}}
#' @examples
#' set.seed(1)
#' X <- data.frame(temp = rnorm(100), prec = rnorm(100))
#' X$prec <- X$prec + X$temp          # correlated in the samples
#' newX <- data.frame(temp = c(0, 3, 2), prec = c(0, 3, -2))
#' ## the third is unremarkable in each predictor, but warm-and-dry is a
#' ## combination the samples never showed: large sigma and nn
#' envNovelty(X, newX)
#' envNovelty(X, newX, importance = c(temp = 0.9, prec = 0.1))
#' @export
envNovelty <- function(X, newX = X, importance = NULL, nn.k = 5) {
  ref <- .rdaf_novelty_ref(X, importance, nn.k)
  out <- .rdaf_novelty_score(ref, as.data.frame(newX))
  attr(out, "nu") <- ref$nu
  attr(out, "weights") <- ref$w
  attr(out, "spacing") <- ref$spacing
  attr(out, "nn.auto") <- ref$nn.auto
  out
}

## One positive number, or one per environment (Inf = no limit).
.rdaf_check_limit <- function(x, ng, name) {
  if (!is.numeric(x) || !length(x) %in% c(1, ng) || any(is.na(x)) || any(x <= 0))
    stop(name, " must be a positive number (Inf for no limit), or one per environment in newX",
         if (name == "nn.max") ', or "auto"' else "",
         call. = FALSE)
  rep_len(x, ng)
}

## The novelty rules, as ordinationJackknife() and ojPredict() take them.
## extra / extra.npred (the range rule of earlier versions) are used when either
## is given; the distance tests then default to off, but apply as well if
## sigma or nn.max is named too.
.rdaf_novelty_rules <- function(ng, np, sigma, nn.max, extra, extra.npred,
                                sigma.named, nn.named) {
  use.range <- !is.null(extra) || !is.null(extra.npred)
  if (use.range) {
    if (is.null(extra)) extra <- 0
    if (is.null(extra.npred)) extra.npred <- np
    if (!is.numeric(extra) || !length(extra) %in% c(1, ng) || any(is.na(extra)) || any(extra < 0))
      stop("extra must be a number of 0 or more, or one per environment in newX", call. = FALSE)
    if (!length(extra.npred) %in% c(1, ng))
      stop("extra.npred must have one value, or one per environment in newX", call. = FALSE)
    extra <- rep_len(extra, ng); extra.npred <- rep_len(extra.npred, ng)
    for (g in seq_len(ng)) extra.npred[g] <- .rdaf_check_extra_npred(extra.npred[g], np)
    if (!sigma.named) sigma <- Inf
    if (!nn.named) nn.max <- Inf
  } else {
    extra <- rep(NA_real_, ng); extra.npred <- rep(NA_real_, ng)
  }
  nn.auto <- is.character(nn.max) && length(nn.max) == 1 && nn.max == "auto"
  list(sigma = .rdaf_check_limit(sigma, ng, "sigma"),
       nn.max = if (nn.auto) rep(NA_real_, ng) else .rdaf_check_limit(nn.max, ng, "nn.max"),
       nn.auto = nn.auto,
       extra = extra, extra.npred = extra.npred, use.range = use.range)
}

## Validate extra.npred against the number of predictors.
.rdaf_check_extra_npred <- function(extra.npred, np) {
  if (!is.numeric(extra.npred) || length(extra.npred) != 1 || is.na(extra.npred))
    stop("extra.npred must be a single number", call. = FALSE)
  extra.npred <- round(extra.npred)
  if (extra.npred < 0 || extra.npred > np)
    stop("extra.npred must be between 0 and the number of predictors (", np, ")", call. = FALSE)
  extra.npred
}

## The range rule of earlier versions: TRUE for rows whose every predictor is
## within its sampled range widened by extra * span.  extra applies to the
## first extra.npred predictors of X; the rest may extend without limit.
.rdaf_within_range <- function(newX, X, extra, extra.npred) {
  ranges <- apply(X, 2, range)
  spans <- ranges[2, ] - ranges[1, ]
  pad <- rep(Inf, ncol(X))
  if (extra.npred > 0) pad[seq_len(extra.npred)] <- spans[seq_len(extra.npred)] * extra
  ok <- rep(TRUE, nrow(newX))
  for (j in seq_len(ncol(X))) {
    if (!is.finite(pad[j])) next
    v <- newX[, colnames(X)[j]]
    ok <- ok & v >= ranges[1, j] - pad[j] & v <= ranges[2, j] + pad[j]
  }
  ok
}
