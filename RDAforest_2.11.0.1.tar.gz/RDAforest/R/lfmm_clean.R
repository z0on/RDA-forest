## ---------------------------------------------------------------------------
## Removing neutral genetic structure before an RDAforest analysis.
##
## lfmmClean() fits a latent factor mixed model (ridge LFMM, Caye et al. 2019)
## to the principal coordinates of the genetic distances, with the
## environment as explanatory variables, and subtracts the fitted latent
## structure: the genetic variation that is shared across loci but not
## explained by the environment (isolation by distance, barriers, admixture).
## The ridge LFMM estimator below is a line-for-line port of ridgeLFMM_main(),
## compute_P() and compute_B_ridge() from the lfmm package
## (https://github.com/bcm-uga/lfmm, GPL-3, K. Caye and O. Francois), with base
## svd() in place of RSpectra::svds() and Eigen's JacobiSVD.
## ---------------------------------------------------------------------------

## Ridge LFMM: Y = X B' + U V' + E.  Y and X are centred, as lfmm_ridge() does.
.rdaf_lfmm_ridge <- function(Y, X, K, lambda = 1e-5) {
  Y <- scale(as.matrix(Y), scale = FALSE); X <- scale(as.matrix(X), scale = FALSE)
  n <- nrow(Y); d <- ncol(X)
  sx <- svd(X, nu = n)                         # compute_eigen_svd(): Q, singular values
  D1 <- rep(1, n); D1[seq_len(d)] <- sqrt(lambda / (lambda + sx$d))
  sqrtP <- t(sx$u) * D1                        # tcrossprod(diag(D1), Q)
  sqrtPinv <- sweep(sx$u, 2, 1 / D1, "*")      # Q %*% diag(1 / D1)
  if (K > 0) {
    s <- svd(sqrtP %*% Y, nu = K, nv = K)
    U <- sqrtPinv %*% (s$u %*% diag(s$d[seq_len(K)], K, K))
    V <- s$v
    W <- tcrossprod(U, V)
  } else {
    U <- matrix(0, n, 0); V <- matrix(0, ncol(Y), 0); W <- 0
  }
  B <- t(solve(crossprod(X) + diag(lambda, d), crossprod(X, Y - W)))
  list(U = U, V = V, B = B)
}

## Principal coordinates of a distance matrix: the Euclidean embedding whose
## distances reproduce D (exactly when D is Euclidean).  Axes with negative or
## zero eigenvalues are dropped.
.rdaf_pcoa <- function(D) {
  D <- as.matrix(D); n <- nrow(D)
  J <- diag(n) - 1 / n
  G <- -0.5 * J %*% (D^2) %*% J
  e <- eigen((G + t(G)) / 2, symmetric = TRUE)
  keep <- e$values > max(e$values) * 1e-10
  Y <- e$vectors[, keep, drop = FALSE] %*% diag(sqrt(e$values[keep]), sum(keep))
  list(Y = Y, eig = e$values)
}

## Environmental explanatory variables: the leading PCs of the scaled
## predictors, with their squares and pairwise products when quadratic = TRUE.
.rdaf_env_basis <- function(X, npcs = 4, quadratic = TRUE) {
  X <- as.data.frame(X)
  num <- vapply(X, is.numeric, logical(1))
  if (!all(num))
    stop("all columns of X must be numeric (non-numeric: ",
         paste(names(X)[!num], collapse = ", "), ")", call. = FALSE)
  X <- as.matrix(X)
  keep <- apply(X, 2, function(v) stats::var(v) > 0)
  if (!any(keep)) stop("the predictors in X are all constant", call. = FALSE)
  X <- X[, keep, drop = FALSE]
  npcs <- min(npcs, ncol(X), nrow(X) - 1)
  P <- stats::prcomp(X, scale. = TRUE)$x[, seq_len(npcs), drop = FALSE]
  colnames(P) <- paste0("envPC", seq_len(npcs))
  if (!quadratic) return(P)
  sq <- P^2; colnames(sq) <- paste0(colnames(P), "^2")
  out <- cbind(P, sq)
  if (npcs > 1) {
    cb <- utils::combn(npcs, 2)
    ip <- apply(cb, 2, function(j) P[, j[1]] * P[, j[2]])
    ip <- matrix(ip, nrow = nrow(P))
    colnames(ip) <- apply(cb, 2, function(j) paste0(colnames(P)[j], collapse = "*"))
    out <- cbind(out, ip)
  }
  out
}

## Broken-stick choice of K: the number of leading eigenvalues of the residual
## genetic variation (after regression on the environmental terms) that exceed
## the broken-stick expectation, counted until the first one that does not.
.rdaf_K_brokenstick <- function(R, Kmax = 15) {
  ev <- svd(R, nu = 0, nv = 0)$d^2; ev <- ev[ev > max(ev) * 1e-12]
  p <- length(ev); prop <- ev / sum(ev)
  bs <- rev(cumsum(1 / rev(seq_len(p)))) / p
  first.fail <- which(prop <= bs)[1]
  K <- if (is.na(first.fail)) p else first.fail - 1
  list(K = min(K, Kmax), table = data.frame(axis = seq_len(p), proportion = prop, broken.stick = bs))
}

#' Remove neutral genetic structure with a latent factor mixed model
#'
#' Removes from a genetic distance matrix the structure that is shared across
#' loci but not explained by the environment, such as isolation by distance,
#' barriers to dispersal or admixture, before variable selection
#' (\code{\link{mtrySelJack}}) and modelling (\code{\link{ordinationJackknife}}).
#' Without such a correction, any environmental variable that happens to vary
#' across space tends to look important, because neutral structure varies
#' across space too.
#'
#' The procedure:
#' \enumerate{
#'   \item The distance matrix is turned into principal coordinates (all axes
#'   with positive eigenvalues), which reproduce the distances.
#'   \item The environmental predictors are summarised by their first
#'   \code{npcs} principal components; with \code{quadratic = TRUE} their
#'   squares and pairwise products are added (14 columns for four PCs).
#'   \item A ridge latent factor mixed model (LFMM; Caye et al. 2019) is
#'   fitted: principal coordinates = environment + K latent factors + noise.
#'   \item K is chosen by the broken-stick rule on the eigenvalues of the
#'   genetic variation left after regression on the environmental terms,
#'   unless given.
#'   \item The fitted latent structure is subtracted from the principal
#'   coordinates, and the distances are recomputed.
#' }
#' Pass \code{$dist} to \code{mtrySelJack} and \code{ordinationJackknife} in
#' place of the original distance matrix, without \code{covariates}: the
#' spatial structure they would condition on has already been removed.
#'
#' \strong{Why subtract, and why quadratic terms.} In simulations (200
#' samples; isolation by distance with or without a barrier; linear,
#' U-shaped, threshold, plateau and asymmetric responses, additive or
#' interacting), this procedure predicted adaptation at unsampled locations
#' best or near-best in every setting and was never worse than no correction.
#' Subtracting the fitted structure beat conditioning the ordination on the
#' latent factors, which also removes adaptive variation lying along them.
#' With only linear environmental terms, LFMM treats U-shaped and interacting
#' adaptation as unexplained structure and removes it; quadratic terms protect
#' it, and did as well as more flexible spline terms on threshold, plateau and
#' asymmetric responses. Only variation the environmental terms can represent
#' is protected: neutral structure that is itself aligned with an
#' environmental gradient partly stays, and adaptation aligned with neutral
#' structure is partly removed. When the environment varies at the same broad
#' scale as the neutral structure, no correction can fully separate the two.
#'
#' \strong{Choosing K.} Cross-validation of K, usual for LFMM on genotypes,
#' does not work on principal coordinates, whose columns are uncorrelated by
#' construction; the broken-stick rule on the residual eigenvalues chose K
#' close to the true number of neutral axes in simulations. \code{$eigen}
#' holds the residual eigenvalues and their broken-stick expectations for a
#' scree plot. When no residual axis exceeds its expectation, K = 0 and the
#' distances are returned unchanged. This happens when the leading genetic
#' structure is itself explained by the environmental terms, i.e. neutral
#' structure and environment run along the same gradients (in the wolves
#' example the environmental terms explain 59-93\% of the three leading genetic
#' axes); the data then cannot say how much of that structure is adaptive.
#'
#' \strong{Sample size.} Every environmental term protects some genetic
#' variation by chance, about 1/(n-1) of each axis per term, so with the 14
#' default terms the sample should be well above 70. With fewer samples use
#' \code{npcs = 2} or \code{quadratic = FALSE}.
#'
#' @param Y genetic distance matrix between samples (square and symmetric, or a
#'   \code{dist} object), e.g. \code{1 - cor(t(genotypes))}.
#' @param X data frame of numeric environmental predictors, one row per sample:
#'   all candidate predictors, before any selection.
#' @param K number of latent factors. \code{NULL} (default) chooses it by the
#'   broken-stick rule.
#' @param npcs number of environmental principal components used (default 4,
#'   or fewer if \code{X} has fewer columns).
#' @param quadratic whether to add squares and pairwise products of the
#'   environmental PCs (default \code{TRUE}).
#' @param lambda ridge penalty of the LFMM (default \code{1e-5}, as in
#'   \code{lfmm::lfmm_ridge}).
#' @param Kmax largest K the broken-stick rule may choose (default 15).
#' @return An object of class \code{rdaf_lfmm_clean}: \code{dist} - the
#'   cleaned distance matrix, with the row and column names of \code{Y}
#'   (\code{Y} itself, unchanged, when K = 0);
#'   \code{K} - the number of latent factors removed; \code{U}, \code{V} -
#'   latent scores (samples x K) and loadings (axes x K);
#'   \code{prop.removed} - fraction of the total genetic variance subtracted;
#'   \code{eigen} - residual eigenvalue proportions with their broken-stick
#'   expectations; \code{env} - the environmental terms used.
#' @references Caye K, Jumentier B, Lepeule J, Francois O (2019) LFMM 2:
#'   statistical methods for genotype-environment association analysis. Molecular
#'   Biology and Evolution 36: 852-860.
#' @seealso \code{\link{mtrySelJack}}, \code{\link{ordinationJackknife}}
#' @examples
#' \donttest{
#' set.seed(1)
#' n <- 100
#' xy <- cbind(runif(n), runif(n))
#' X <- data.frame(temp = sin(3 * xy[, 1]) + rnorm(n, 0, .2),
#'                 rain = cos(3 * xy[, 2]) + rnorm(n, 0, .2),
#'                 soil = rnorm(n))
#' ## genotypes: adaptation to temp, plus neutral structure along x
#' G <- sapply(1:300, function(l) rnorm(n, (l <= 30) * X$temp + 1.5 * xy[, 1] * rnorm(1), 1))
#' D <- 1 - cor(t(G))
#' cl <- lfmmClean(D, X)
#' cl
#' mm <- mtrySelJack(cl$dist, X, nreps = 5, top.pcs = 3, ntrees = 300, auto.sites = FALSE)
#' }
#' @export
lfmmClean <- function(Y, X, K = NULL, npcs = 4, quadratic = TRUE, lambda = 1e-5, Kmax = 15) {
  Y <- .rdaf_as_distance(Y)
  X <- as.data.frame(X)
  if (nrow(as.matrix(Y)) != nrow(X))
    stop("incompatible input matrices: number of rows in X should be equal that in Y", call. = FALSE)
  if (!is.null(K) && (!is.numeric(K) || length(K) != 1 || K < 0 || K != round(K)))
    stop("K must be NULL or a single whole number, 0 or more", call. = FALSE)
  Dm <- as.matrix(Y)
  pc <- .rdaf_pcoa(Dm)
  Yp <- pc$Y
  E <- .rdaf_env_basis(X, npcs, quadratic)
  Ec <- scale(E, scale = FALSE); Yc <- scale(Yp, scale = FALSE)
  R <- Yc - Ec %*% qr.coef(qr(Ec), Yc)
  bsr <- .rdaf_K_brokenstick(R, Kmax)
  if (is.null(K)) K <- bsr$K
  K <- min(K, ncol(Yp) - 1)
  fit <- .rdaf_lfmm_ridge(Yp, E, K, lambda)
  N <- if (K > 0) tcrossprod(fit$U, fit$V) else matrix(0, nrow(Yp), ncol(Yp))
  if (K > 0) {
    cleaned <- as.matrix(stats::dist(Yp - N))
    dimnames(cleaned) <- dimnames(Dm)
  } else {
    ## nothing to remove: hand back the distances exactly as given
    cleaned <- Dm
    if (is.null(match.call()$K))
      message("No genetic structure beyond what the environmental terms explain was found ",
              "(broken-stick rule: K = 0), so the distances are returned unchanged. This is ",
              "expected when neutral structure runs along the same gradients as the ",
              "environment: then the two cannot be told apart. See $eigen, and ?lfmmClean.")
  }
  structure(list(dist = cleaned, K = K, U = fit$U, V = fit$V,
                 prop.removed = if (K > 0) sum(scale(N, scale = FALSE)^2) / sum(Yc^2) else 0,
                 eigen = bsr$table, env = E, quadratic = quadratic, lambda = lambda,
                 K.chosen = is.null(match.call()$K)),
            class = "rdaf_lfmm_clean")
}

#' @method print rdaf_lfmm_clean
#' @export
print.rdaf_lfmm_clean <- function(x, ...) {
  cat("Neutral structure removed by LFMM\n")
  cat("  latent factors (K):   ", x$K, if (isTRUE(x$K.chosen)) " (broken-stick rule)" else " (given)", "\n", sep = "")
  cat("  environmental terms:  ", ncol(x$env), " (", if (x$quadratic) "PCs, squares and pairwise products" else "PCs", ")\n", sep = "")
  cat(sprintf("  genetic variance removed: %.1f%%\n", 100 * x$prop.removed))
  cat("  cleaned distances in $dist: pass them to mtrySelJack() and ordinationJackknife()\n")
  invisible(x)
}
