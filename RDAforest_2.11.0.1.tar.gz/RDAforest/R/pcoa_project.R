## Base-R principal coordinates with out-of-bag projection (Gower 1968).
## The same algorithm, mapped onto capscale's axes, is .rdaf_project_ord().

#' Principal coordinates of a subset of samples, with all samples projected
#'
#' A self-contained (base R) principal coordinates analysis of the distances
#' among the \code{inbag} samples, with every sample of \code{D}, in-bag or
#' not, placed on its axes by Gower's (1968) add-a-point formula. In-bag
#' samples land exactly on their own coordinates; out-of-bag samples land
#' where the same geometry puts them (exactly, for Euclidean distances, when
#' they lie in the space the in-bag samples span; otherwise their projection
#' onto it). Optionally the ordination is conditioned on covariates, like
#' \code{capscale(D ~ Condition(Z))}: the in-bag regression of the
#' coordinates on the covariates is subtracted from every sample using its
#' own covariate values, and the residuals are rotated to their in-bag
#' principal axes.
#'
#' The coordinates are in the units of the distances: with all axes kept and
#' Euclidean distances, \code{dist(scores)} reproduces \code{D}. Up to axis
#' signs and one constant they equal \code{capscale}'s \code{scaling = 1}
#' site scores; \code{\link{projectOrdination}} returns them on
#' \code{capscale}'s own axes and units instead.
#'
#' Do not use \code{predict(ord, D, type = "sp")} on a \code{capscale}
#' ordination for this: it projects the distances themselves rather than the
#' double-centred squared distances, which stretches and shrinks axes
#' unequally.
#'
#' @param D distance matrix among all samples (square and symmetric), or a
#'   \code{dist} object.
#' @param inbag which samples build the ordination: indices, row names, or a
#'   logical vector.
#' @param covariates optional matrix or data frame, one row per sample of
#'   \code{D}, to condition the ordination on; \code{NA} rows (covariates
#'   unknown) are projected without adjustment.
#' @param tol relative tolerance for dropping null and negative eigenvalues.
#' @return A list: \code{scores} (all samples on all axes), \code{eig}
#'   (variance of each axis among the in-bag samples), \code{inbag} (indices)
#'   and \code{negative.eig} (sum of the absolute negative eigenvalues of the
#'   in-bag Gower matrix: 0 for Euclidean distances).
#' @references Gower JC (1966) Some distance properties of latent root and
#'   vector methods used in multivariate analysis. Biometrika 53: 325-338.
#'
#'   Gower JC (1968) Adding a point to vector diagrams in multivariate
#'   analysis. Biometrika 55: 582-585.
#' @seealso \code{\link{projectOrdination}}
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(80 * 10), 80) %*% diag(10:1)
#' D <- as.matrix(dist(X))
#' ib <- sample(80, 60)
#' p <- pcoa_project(D, ib)
#' ## every sample, in-bag or not, keeps its distances to all others
#' max(abs(as.matrix(dist(p$scores)) - D))
#' ## the in-bag samples are the classical PCoA of the in-bag distances
#' pc <- cmdscale(D[ib, ib], k = 5)
#' max(abs(abs(p$scores[ib, 1:5]) - abs(pc)))
#' @export
pcoa_project <- function(D, inbag, covariates = NULL, tol = 1e-10) {
  D <- as.matrix(D)
  n <- nrow(D)
  ib <- if (is.logical(inbag)) which(inbag) else
        if (is.character(inbag)) match(inbag, rownames(D)) else as.integer(inbag)
  stopifnot(nrow(D) == ncol(D), length(ib) >= 3, !anyNA(ib))

  ## 1. PCoA of the in-bag samples
  D2   <- D^2
  D2ib <- D2[ib, ib, drop = FALSE]
  rbar <- rowMeans(D2ib)
  gbar <- mean(D2ib)
  G    <- -0.5 * (D2ib - outer(rbar, rbar, "+") + gbar)
  e    <- eigen((G + t(G)) / 2, symmetric = TRUE)
  keep <- e$values > max(e$values) * tol
  U    <- e$vectors[, keep, drop = FALSE]
  L    <- e$values[keep]

  ## 2. add-a-point: inner products of every sample with the in-bag samples
  D2a <- D2[, ib, drop = FALSE]
  Ga  <- -0.5 * (D2a - rowMeans(D2a) - matrix(rbar, n, length(ib), byrow = TRUE) + gbar)
  Y   <- sweep(Ga %*% U, 2, sqrt(L), "/")          # in-bag rows = U sqrt(L)

  ## 3. optional covariates: in-bag regression, applied to every sample
  if (!is.null(covariates)) {
    Z <- as.matrix(covariates)
    stopifnot(nrow(Z) == n)
    B <- qr.coef(qr(cbind(1, Z[ib, , drop = FALSE])), Y[ib, , drop = FALSE])
    B[is.na(B)] <- 0                               # aliased covariates
    known <- stats::complete.cases(Z)
    fit <- matrix(colMeans(Y[ib, , drop = FALSE]), n, ncol(Y), byrow = TRUE)
    fit[known, ] <- cbind(1, Z[known, , drop = FALSE]) %*% B
    Y <- Y - fit
  } else {
    Y <- sweep(Y, 2, colMeans(Y[ib, , drop = FALSE]))
  }

  ## principal axes of the in-bag samples (a rotation: no axis is stretched)
  s <- svd(Y[ib, , drop = FALSE])
  k <- sum(s$d > max(s$d) * sqrt(tol))
  scores <- Y %*% s$v[, seq_len(k), drop = FALSE]
  colnames(scores) <- paste0("PCo", seq_len(k))
  rownames(scores) <- rownames(D)

  list(scores = scores,
       eig = s$d[seq_len(k)]^2 / (length(ib) - 1),
       inbag = ib,
       negative.eig = -sum(e$values[e$values < 0]))
}
