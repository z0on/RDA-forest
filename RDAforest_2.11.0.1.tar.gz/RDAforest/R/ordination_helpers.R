## ---------------------------------------------------------------------------
## Ordinations for the jackknife functions.  Y is always a distance matrix
## (raw data matrices are no longer accepted: pass as.matrix(dist(Y)), which
## gives the same ordination as an RDA of Y), and the ordination is always a
## principal coordinates analysis by capscale(), optionally conditioned on
## covariates.
## ---------------------------------------------------------------------------

## Check that Y is a distance matrix; a `dist` object is converted.  Anything
## else that is square and symmetric is returned exactly as supplied, so that
## results do not change from earlier versions.
.rdaf_as_distance <- function(Y) {
  if (inherits(Y, "dist")) Y <- as.matrix(Y)
  Ym <- tryCatch(as.matrix(Y), error = function(e) NULL)
  ok <- !is.null(Ym) && is.numeric(Ym) && length(dim(Ym)) == 2 &&
    nrow(Ym) == ncol(Ym) && nrow(Ym) > 1 && !anyNA(Ym) &&
    isSymmetric(unname(Ym))
  if (!ok)
    stop("Y must be a distance matrix: square and symmetric, one row and ",
         "column per sample (for example 1-cor(t(genotypes)), or a 'dist' ",
         "object). Raw data matrices are not accepted; for one, pass ",
         "as.matrix(dist(Y)), which gives the same ordination as an RDA of Y.",
         call. = FALSE)
  ## samples are identified by row name downstream, so a matrix without
  ## names, such as 1 - cor(t(genotypes)), gets 1..n
  if (is.null(rownames(Y)) || is.null(colnames(Y))) {
    Y <- as.matrix(Y); dimnames(Y) <- list(seq_len(nrow(Y)), seq_len(ncol(Y)))
  }
  Y
}

## Ordination of all samples.
.rdaf_ord_full <- function(Y, covariates = NULL) {
  if (!is.null(covariates)) capscale(Y ~ 1 + Condition(as.matrix(covariates)))
  else capscale(Y ~ 1)
}

## One jackknife replicate: ordination of the in-bag samples, with all samples
## projected onto it (see .rdaf_project_ord).
.rdaf_ord_rep <- function(Y, ib.keep, covariates = NULL) {
  Y.ib <- Y[ib.keep, ib.keep]
  if (!is.null(covariates)) {
    covars.ib <- covariates[ib.keep, ]
    ords0 <- capscale(Y.ib ~ 1 + Condition(as.matrix(covars.ib)))
  } else {
    ords0 <- capscale(Y.ib ~ 1)
  }
  ords <- .rdaf_project_ord(Y, ib.keep, covariates, ords0)
  list(ords0 = ords0, ords = ords)
}

## Project every sample onto an ordination of a subset of them, so that the
## subset lands exactly on its own scores (scaling 1) and the others land
## where the same geometry puts them.
##
## Versions before 2.11 used predict(ords0, Y, type = "sp"), which treats the
## columns of the distance matrix as species: it projects the distances
## themselves rather than the double-centred squared distances that the
## principal coordinates are made of.  The projected subset then did not
## match its own scores: each axis was stretched or shrunk differently (on
## the wolves by 0.86 to 1.26 over the first eight axes), and with
## covariates the axes also lost up to 7% of their correlation with the true
## scores.
##
## Here: (1) principal coordinates of the subset, from its double-centred
## squared distances (Gower 1966); (2) every sample placed in that space by
## Gower's (1968) add-a-point formula, which puts subset members exactly at
## their own coordinates; (3) with covariates, the subset's regression of the
## coordinates on the covariates is subtracted from every sample, using each
## sample's own covariate values, as capscale's Condition() does for the
## subset; (4) principal axes of the subset's residuals; (5) one orthogonal
## transformation times a constant, fitted on the subset, carries this onto
## capscale's own axes, signs and scaling-1 units.  Step 5 can rotate and
## scale but not stretch individual axes, so the geometry is untouched.
## covariates: one row per sample of Y; rows of new samples with missing
## covariates are projected without adjustment (step 3 skipped).
.rdaf_project_ord <- function(Y, ib, covariates = NULL, ords0) {
  D2 <- as.matrix(Y)^2
  n <- nrow(D2)
  D2ib <- D2[ib, ib, drop = FALSE]
  rbar <- rowMeans(D2ib); gbar <- mean(D2ib)
  G <- -0.5 * (D2ib - outer(rbar, rbar, "+") + gbar)
  e <- eigen((G + t(G)) / 2, symmetric = TRUE)
  k <- e$values > max(e$values) * 1e-10
  U0 <- e$vectors[, k, drop = FALSE]; lam0 <- e$values[k]
  ## add-a-point: inner products of every sample with the subset
  D2a <- D2[, ib, drop = FALSE]
  Ga <- -0.5 * (D2a - rowMeans(D2a) - matrix(rbar, n, length(ib), byrow = TRUE) + gbar)
  Ya <- sweep(Ga %*% U0, 2, sqrt(lam0), "/")
  if (!is.null(covariates)) {
    Z <- as.matrix(covariates)
    if (nrow(Z) != n) stop("covariates must have one row per sample")
    Zi <- cbind(1, Z[ib, , drop = FALSE])
    B <- qr.coef(qr(Zi), Ya[ib, , drop = FALSE]); B[is.na(B)] <- 0
    ok <- stats::complete.cases(Z)
    fit <- matrix(colMeans(Ya[ib, , drop = FALSE]), n, ncol(Ya), byrow = TRUE)
    fit[ok, ] <- cbind(1, Z[ok, , drop = FALSE]) %*% B
    R <- Ya - fit
  } else {
    R <- sweep(Ya, 2, colMeans(Ya[ib, , drop = FALSE]))
  }
  sv <- svd(R[ib, , drop = FALSE])
  own <- scores(ords0, scaling = 1, display = "sites", choices = seq_along(ords0$CA$eig))
  r <- min(ncol(own), sum(sv$d > max(sv$d) * 1e-6))
  own <- own[, seq_len(r), drop = FALSE]
  S <- R %*% sv$v[, seq_len(r), drop = FALSE]
  Sib <- S[ib, , drop = FALSE]
  Tm <- qr.coef(qr(Sib), own)
  out <- S %*% Tm
  dimnames(out) <- list(rownames(as.matrix(Y)), colnames(own))
  ## the subset must land on its own scores
  err <- max(abs(out[ib, , drop = FALSE] - own)) / max(abs(own))
  if (!is.finite(err) || err > 1e-6)
    warning("projected ordination deviates from the subset's own scores by ", signif(err, 2),
            " (relative)", call. = FALSE)
  out
}

## ---------------------------------------------------------------------------
## mtrySelJack helpers
## ---------------------------------------------------------------------------

## The two mtry values mtrySelJack compares.  The general defaults coincide
## (3 and 3) for five or fewer predictors, which makes the test a coin toss,
## so small predictor sets get 1 vs 2 (three predictors) or 1 vs 3 (four or
## five).  Fewer than three predictors cannot be tested at all.
.rdaf_mtry_pair <- function(np, mintry = NULL, maxtry = NULL) {
  if (np < 3)
    stop("mtrySelJack needs at least 3 predictors: the test compares ",
         "importances at two different mtry values, and with ", np,
         " there is no meaningful pair.", call. = FALSE)
  if (np <= 5) {
    dmin <- 1; dmax <- if (np == 3) 2 else 3
  } else {
    dmin <- max(3, round(np / 5)); dmax <- max(min(np - 2, 6), round(2 * np / 5) + 1)
  }
  if (is.null(mintry)) mintry <- dmin
  if (is.null(maxtry)) maxtry <- dmax
  if (mintry < 1 || maxtry > np || mintry >= maxtry)
    stop("need 1 <= mintry < maxtry <= the number of predictors (", np,
         "); got mintry = ", mintry, ", maxtry = ", maxtry, call. = FALSE)
  c(mintry, maxtry)
}

## Correlations among the numeric predictors, kept in the mtrySelJack() result
## so that Reselect() can redo the report without the data.
.rdaf_predictor_cor <- function(X) {
  num <- names(X)[vapply(X, is.numeric, logical(1))]
  if (length(num) < 2) return(NULL)
  suppressWarnings(stats::cor(X[, num, drop = FALSE], use = "pairwise.complete.obs"))
}

## Dropped predictors that correlate with a retained one at |r| >= report.cor,
## reported in a message and returned as a data frame.  `cmat` is the
## correlation matrix from .rdaf_predictor_cor().
.rdaf_dropped_pairs <- function(cmat, goodvars, importances, prop.positive,
                                ic, pp.cutoff, report.cor = 0.7) {
  empty <- data.frame(dropped = character(0), kept = character(0),
                      r = numeric(0), importance = numeric(0),
                      prop.positive = numeric(0), reason = character(0),
                      stringsAsFactors = FALSE)
  if (is.null(report.cor) || is.na(report.cor) || is.null(cmat)) return(empty)
  num <- colnames(cmat)
  dropped <- setdiff(intersect(names(importances), num), goodvars)
  kept <- intersect(goodvars, num)
  if (!length(dropped) || !length(kept)) return(empty)
  cm <- cmat[dropped, kept, drop = FALSE]
  hit <- which(!is.na(cm) & abs(cm) >= report.cor, arr.ind = TRUE)
  if (!nrow(hit)) return(empty)
  d <- dropped[hit[, 1]]
  imp <- unname(importances[d]); pp <- unname(prop.positive[d])
  reason <- ifelse(imp < ic & pp < pp.cutoff, "mtry test and low importance",
            ifelse(pp < pp.cutoff, "mtry test", "low importance"))
  out <- data.frame(dropped = d, kept = kept[hit[, 2]], r = cm[hit],
                    importance = imp, prop.positive = pp, reason = reason,
                    stringsAsFactors = FALSE)
  out <- out[order(-abs(out$r), out$dropped), ]
  rownames(out) <- NULL
  message("\nDropped predictors correlated with retained ones (|r| >= ",
          report.cor, "):\n",
          paste(vapply(unique(out$dropped), function(d) {
            o <- out[out$dropped == d, ]
            sprintf("  %s (%s) ~ %s", d, o$reason[1],
                    paste(sprintf("%s %.2f", o$kept, o$r), collapse = ", "))
          }, character(1)), collapse = "\n"),
          "\nThe mtry test treats such predictors as proxies of the retained ",
          "ones. Two predictors that are both real drivers but correlated can ",
          "lose to each other the same way, so reconsider any that are ",
          "plausibly drivers in their own right. Details in $dropped.pairs.")
  out
}

#' Project samples onto an ordination built from a subset of them
#'
#' Builds the principal coordinates ordination that the jackknife functions
#' use (\code{capscale}, optionally conditioned on covariates) from the samples
#' in \code{model.rows}, and places every sample of \code{Y} on it. Samples of
#' the model land exactly on their own scores (\code{scaling = 1}); the others
#' land where the same geometry puts them, by Gower's (1968) add-a-point
#' formula. This is how \code{\link{ordinationJackknife}} and
#' \code{\link{mtrySelJack}} project their out-of-bag samples, and it can be
#' used to place new individuals in the space of an
#' \code{ordinationJackknife} model built without them (see the "lone wolf"
#' in the wolves example).
#'
#' Do not use \code{predict(ord, Y, type = "sp")} for this: it treats the
#' columns of the distance matrix as species and projects the distances
#' themselves rather than the double-centred squared distances the principal
#' coordinates are made of, which stretches and shrinks axes unequally.
#'
#' With covariates, each sample's position is adjusted for its own covariate
#' values using the regression fitted on the model samples, as
#' \code{Condition()} does for the model samples themselves. Samples whose
#' covariates are unknown (\code{NA}, or not supplied) are projected without
#' that adjustment, so their scores still carry whatever the covariates
#' would have removed.
#'
#' @param Y distance matrix among all samples (model and new), square and
#'   symmetric, or a \code{dist} object.
#' @param model.rows which samples the ordination is built from: indices,
#'   row names, or a logical vector.
#' @param covariates optional covariates to condition the ordination on: one
#'   row per sample of \code{Y} (\code{NA} rows for samples whose covariates
#'   are unknown), or one row per model sample.
#' @return A list: \code{ordination}, the \code{capscale} fit to the model
#'   samples; \code{scores}, scaling-1 scores of every sample of \code{Y} on
#'   all its axes, in the same units and orientation as
#'   \code{scores(ordination, scaling = 1, display = "sites")}.
#' @references Gower JC (1968) Adding a point to vector diagrams in
#'   multivariate analysis. Biometrika 55: 582-585.
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(50 * 10), 50)
#' D <- as.matrix(dist(X))
#' p <- projectOrdination(D, model.rows = 1:40)
#' ## all 50 samples, on the axes of the ordination of the first 40;
#' ## with every axis kept the projected samples reproduce D exactly
#' k <- sum(D * as.matrix(dist(p$scores))) / sum(as.matrix(dist(p$scores))^2)
#' max(abs(k * as.matrix(dist(p$scores)) - D))
#' @import vegan
#' @export
projectOrdination <- function(Y, model.rows, covariates = NULL) {
  Y <- .rdaf_as_distance(Y)
  n <- nrow(Y)
  ib <- if (is.logical(model.rows)) which(model.rows)
        else if (is.character(model.rows)) match(model.rows, rownames(Y))
        else as.integer(model.rows)
  if (anyNA(ib) || length(ib) < 3 || any(ib < 1 | ib > n) || anyDuplicated(ib))
    stop("model.rows must pick at least three distinct samples of Y")
  Z <- NULL
  if (!is.null(covariates)) {
    covariates <- as.matrix(covariates)
    if (nrow(covariates) == n) {
      Z <- covariates
    } else if (nrow(covariates) == length(ib)) {
      Z <- matrix(NA_real_, n, ncol(covariates), dimnames = list(NULL, colnames(covariates)))
      Z[ib, ] <- covariates
    } else stop("covariates must have one row per sample of Y, or one per model sample")
    if (anyNA(Z[ib, ])) stop("covariates of the model samples may not be missing")
    unadj <- setdiff(which(!stats::complete.cases(Z)), ib)
    if (length(unadj))
      message(length(unadj), " sample(s) without covariates projected without covariate adjustment")
  }
  Yib <- Y[ib, ib]
  ord <- if (is.null(Z)) capscale(Yib ~ 1) else capscale(Yib ~ 1 + Condition(Z[ib, , drop = FALSE]))
  list(ordination = ord, scores = .rdaf_project_ord(Y, ib, Z, ord))
}
