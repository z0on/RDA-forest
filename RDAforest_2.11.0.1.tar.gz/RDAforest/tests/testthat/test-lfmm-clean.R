## lfmmClean(): removing neutral structure with ridge LFMM.

lc_sim <- function(n = 120, seed = 1) {
  set.seed(seed)
  xy <- cbind(stats::runif(n), stats::runif(n))
  X <- data.frame(temp = sin(3 * xy[, 1]) + stats::rnorm(n, 0, .3),
                  rain = cos(3 * xy[, 2]) + stats::rnorm(n, 0, .3),
                  soil = stats::rnorm(n), elev = stats::rnorm(n))
  S <- cbind(xy[, 1] - .5, (xy[, 2] > .5) - .5)            # neutral structure: a cline and a barrier
  G <- sapply(1:400, function(l) {
    adapt <- if (l <= 40) X$temp else 0
    stats::rnorm(n, adapt + 2 * S %*% stats::rnorm(2), 1)
  })
  rownames(G) <- paste0("ind", 1:n)
  list(X = X, S = S, D = 1 - cor(t(G)), xy = xy)
}

test_that("the ridge LFMM port recovers known latent factors and effects", {
  set.seed(2)
  n <- 150; p <- 600; K <- 3
  U <- matrix(stats::rnorm(n * K), n, K)
  X <- matrix(0.6 * U[, 1] + stats::rnorm(n, 0, 0.8), n, 1)     # environment confounded with U1
  V <- matrix(stats::rnorm(p * K), p, K); B <- matrix(0, p, 1); B[1:40] <- stats::rnorm(40, 0, 1.5)
  Y <- X %*% t(B) + U %*% t(V) + matrix(stats::rnorm(n * p), n, p)
  m <- RDAforest:::.rdaf_lfmm_ridge(Y, X, K)
  expect_gt(min(stats::cancor(m$U, U)$cor), 0.99)
  expect_gt(stats::cor(m$B[, 1], B[, 1]), 0.95)
  ## naive regression is misled by the confounding; LFMM is not
  expect_lt(stats::cor(stats::coef(stats::lm(Y ~ X))[2, ], B[, 1]), 0.8)
})

test_that("lfmmClean returns a cleaned distance matrix that removes the neutral structure", {
  d <- lc_sim()
  cl <- lfmmClean(d$D, d$X)
  expect_s3_class(cl, "rdaf_lfmm_clean")
  expect_true(cl$K >= 1)
  expect_equal(dim(cl$dist), dim(d$D))
  expect_identical(dimnames(cl$dist), dimnames(d$D))
  expect_true(isSymmetric(cl$dist))
  expect_equal(unname(diag(cl$dist)), rep(0, nrow(d$D)))
  expect_equal(ncol(cl$env), 4 + 4 + 6)                        # PCs, squares, products
  expect_true(cl$prop.removed > 0 && cl$prop.removed < 1)
  expect_named(cl$eigen, c("axis", "proportion", "broken.stick"))
  ## neutral structure explains much less of the cleaned ordination than of the original
  r2 <- function(D) { sc <- vegan::scores(vegan::capscale(D ~ 1), display = "sites", choices = 1:3)
    mean(apply(sc, 2, function(s) summary(stats::lm(s ~ d$S))$r.squared)) }
  expect_lt(r2(cl$dist), r2(d$D) / 2)
  expect_output(print(cl), "latent factors")
})

test_that("K can be given; K = 0 returns the distances unchanged", {
  d <- lc_sim()
  c2 <- lfmmClean(d$D, d$X, K = 2)
  expect_equal(c2$K, 2); expect_equal(ncol(c2$U), 2)
  c0 <- lfmmClean(d$D, d$X, K = 0)
  expect_equal(c0$prop.removed, 0)
  expect_identical(c0$dist, d$D)
  ## data whose structure the environment explains entirely: the rule finds K = 0, and says so
  set.seed(5); n <- 100; X <- data.frame(a = stats::rnorm(n), b = stats::rnorm(n), c = stats::rnorm(n))
  G <- sapply(1:300, function(l) stats::rnorm(n, X$a * stats::rnorm(1) + X$b * stats::rnorm(1), 1)); rownames(G) <- 1:n
  expect_message(cz <- lfmmClean(dist(G), X), "K = 0")
  expect_equal(cz$K, 0)
  expect_error(lfmmClean(d$D, d$X, K = -1), "whole number")
  expect_error(lfmmClean(d$D, d$X, K = 1.5), "whole number")
})

test_that("options and input checks", {
  d <- lc_sim()
  expect_equal(ncol(lfmmClean(d$D, d$X, quadratic = FALSE)$env), 4)
  expect_equal(ncol(lfmmClean(d$D, d$X[, 1:2])$env), 2 + 2 + 1)   # npcs capped at ncol(X)
  expect_equal(ncol(lfmmClean(d$D, d$X[, 1, drop = FALSE])$env), 2)
  expect_equal(lfmmClean(stats::as.dist(d$D), d$X)$K, lfmmClean(d$D, d$X)$K)
  expect_error(lfmmClean(matrix(stats::rnorm(120 * 5), 120, 5), d$X), "distance matrix")
  expect_error(lfmmClean(d$D, d$X[1:50, ]), "incompatible")
  expect_error(lfmmClean(d$D, data.frame(d$X, f = "a")), "numeric")
})

test_that("the cleaned distances feed mtrySelJack and ordinationJackknife", {
  d <- lc_sim()
  cl <- suppressMessages(lfmmClean(d$D, d$X))
  set.seed(3)
  mm <- suppressMessages(mtrySelJack(cl$dist, d$X, nreps = 3, top.pcs = 2, ntrees = 80, auto.sites = FALSE))
  expect_true("temp" %in% names(mm$importances))
  set.seed(4)
  oj <- suppressMessages(ordinationJackknife(cl$dist, d$X, nreps = 2, top.pcs = 2, ntrees = 60, auto.sites = FALSE))
  expect_equal(nrow(oj$predictions.direct), nrow(d$X))
})
