## Environmental novelty (envNovelty) and the novelty rules of
## ordinationJackknife() / ojPredict(): sigma, nn.max, and the range rule
## (extra / extra.npred).

nov_sim <- function(n = 80, seed = 3) {
  set.seed(seed)
  X <- data.frame(temp = stats::rnorm(n), depth = stats::runif(n), noise = stats::rnorm(n))
  Y <- data.frame(a = 2 * X$temp + stats::rnorm(n, 0, 0.5), b = X$depth + stats::rnorm(n, 0, 0.5),
                  c = stats::rnorm(n))
  list(X = X, D = as.matrix(dist(Y)), n = n)
}
q <- function(e) suppressMessages(e)
run_n <- function(d, newX, seed = 1, ...) { set.seed(seed)
  q(ordinationJackknife(d$D, d$X, newX = newX, nreps = 2, top.pcs = 2, ntrees = 60,
                        auto.sites = FALSE, ...)) }

## ---- sigma ------------------------------------------------------------------

test_that("equal weights give the ordinary Mahalanobis distance, as sigma", {
  d <- nov_sim()
  nx <- rbind(d$X[1:5, ], data.frame(temp = c(3, -4), depth = c(0.5, 1.5), noise = c(0, 2)))
  s <- envNovelty(d$X, nx)
  expect_named(s, c("sigma", "nn"))
  Q <- stats::mahalanobis(nx, colMeans(d$X), stats::cov(d$X))
  expect_equal(s$sigma, stats::qnorm(stats::pchisq(Q, 3, lower.tail = FALSE) / 2, lower.tail = FALSE))
  expect_equal(attr(s, "nu"), 3)
  ## the centre is not novel at all
  expect_equal(envNovelty(d$X, as.data.frame(t(colMeans(d$X))))$sigma, 0)
})

test_that("with one predictor, sigma is its distance from the mean in SDs", {
  set.seed(4); X <- data.frame(a = stats::rnorm(50))
  nx <- data.frame(a = c(-3, 0.2, 5))
  expect_equal(envNovelty(X, nx)$sigma, abs(nx$a - mean(X$a)) / stats::sd(X$a))
})

test_that("importance weighting: a far value on an unimportant predictor counts for little", {
  set.seed(5)
  X <- data.frame(a = stats::rnorm(200), b = stats::rnorm(200))
  nx <- data.frame(a = 0, b = 5)
  eq <- envNovelty(X, nx)
  lo <- envNovelty(X, nx, importance = c(a = 0.9, b = 0.1))
  hi <- envNovelty(X, nx, importance = c(a = 0.1, b = 0.9))
  expect_lt(lo$sigma, eq$sigma)
  expect_gt(hi$sigma, lo$sigma)
  expect_lt(lo$nn, eq$nn)
  expect_gt(hi$nn, lo$nn)
  expect_lt(attr(lo, "nu"), 2)
  ## weights only matter relative to each other
  expect_equal(lo, envNovelty(X, nx, importance = c(a = 9, b = 1)))
  ## an ordinationJackknife-like result is accepted as importance
  expect_equal(lo, envNovelty(X, nx, importance = list(median.importance = c(b = 0.1, a = 0.9))))
})

test_that("novel combinations are caught even when each value is ordinary", {
  set.seed(6)
  a <- stats::rnorm(300); X <- data.frame(a = a, b = a + stats::rnorm(300, 0, 0.3))
  s <- envNovelty(X, data.frame(a = c(1.5, 1.5), b = c(1.5, -1.5)))
  expect_lt(s$sigma[1], 2)     # along the samples' ridge
  expect_gt(s$sigma[2], 4)     # against it
  expect_gt(s$nn[2], 3 * s$nn[1])
})

## ---- nn ---------------------------------------------------------------------

test_that("nn is the k-nearest distance in units of the samples' own spacing", {
  set.seed(7)
  X <- data.frame(a = stats::rnorm(60), b = stats::rnorm(60))
  nx <- data.frame(a = c(0, 3, -1), b = c(0, -2, 4))
  s <- envNovelty(X, nx, nn.k = 3)
  ## by hand, with equal weights: whitened coordinates, then plain distances
  R <- stats::cor(X); e <- eigen(R); M <- e$vectors %*% diag(1 / sqrt(e$values)) %*% t(e$vectors)
  mu <- colMeans(X); sd <- apply(X, 2, stats::sd)
  S <- scale(as.matrix(X), mu, sd) %*% M; V <- scale(as.matrix(nx), mu, sd) %*% M
  knn <- function(d, k) mean(sort(d)[1:k])
  DS <- as.matrix(dist(S)); diag(DS) <- Inf
  spacing <- stats::median(apply(DS, 1, knn, k = 3))
  byhand <- apply(V, 1, function(v) knn(sqrt(colSums((t(S) - v)^2)), 3)) / spacing
  expect_equal(s$nn, byhand)
  expect_equal(attr(s, "spacing"), spacing)
})

test_that("nn sees lopsided sampling and gaps that sigma does not", {
  set.seed(8)
  ## samples bunched at the low end of a, with a long tail upwards, plus a gap in b
  a <- c(stats::rexp(150), 6)
  b <- c(stats::runif(75, 0, 1), stats::runif(75, 3, 4), 2)
  X <- data.frame(a = a, b = b)
  nx <- data.frame(a = c(0.5, 0.5, 4.5), b = c(0.5, 2, 2))
  s <- envNovelty(X, nx)
  expect_lt(s$nn[1], 1.5)                # among the samples
  expect_gt(s$nn[2], s$nn[1] * 2)        # in the gap between the two groups
  expect_lt(s$sigma[2], 2)               # ... which sits right at the centre
  expect_gt(s$nn[3], 3)                  # out along the thin tail
  expect_lt(s$sigma[3], 4)
})

test_that("bad input to envNovelty is refused", {
  d <- nov_sim()
  expect_error(envNovelty(d$X, d$X[, 1:2]), "lacks predictor")
  expect_error(envNovelty(d$X, d$X, importance = c(temp = 1)), "no value for")
  expect_error(envNovelty(d$X, d$X, importance = 1:3), "named numeric")
  expect_error(envNovelty(cbind(d$X, k = 1)), "no variation")
  expect_error(envNovelty(d$X, nn.k = 0), "nn.k")
})

## ---- the rules in ordinationJackknife ---------------------------------------

test_that("ordinationJackknife drops environments failing either test and reports novelty", {
  d <- nov_sim()
  nx <- rbind(d$X[1:10, ], data.frame(temp = c(8, 0, NA), depth = c(0.5, 0.5, 0.5), noise = c(0, 9, 0)))
  set.seed(1)
  msgs <- capture_messages(o <- ordinationJackknife(d$D, d$X, newX = nx, nreps = 2, top.pcs = 2, ntrees = 60,
                                                    auto.sites = FALSE))
  expect_true(any(grepl("beyond sigma = 4", msgs)))
  expect_true(any(grepl("beyond nn.max = 3", msgs)))
  expect_equal(nrow(o$novelty), nrow(nx))
  expect_true(all(is.na(o$novelty[13, ])))
  expect_false(o$goodrows[13])
  expect_equal(o$goodrows, !is.na(o$novelty$sigma) & o$novelty$sigma <= 4 & o$novelty$nn <= 3)
  expect_false(o$goodrows[11])                           # temp far beyond
  expect_equal(nrow(o$predictions.direct), sum(o$goodrows))
  expect_equal(unname(o$limits[c("sigma", "nn.max")]), c(4, 3))
  ## the novelty is what envNovelty gives with the run's importances
  e <- envNovelty(d$X, nx[1:12, ], o$median.importance)
  expect_equal(o$novelty$sigma[1:12], e$sigma)
  expect_equal(o$novelty$nn[1:12], e$nn)
  expect_true(is.na(envNovelty(d$X, nx[13, ])$nn))
  ## each test can be switched off; with both off every complete row is
  ## predicted, by the same forests
  a <- run_n(d, nx, sigma = Inf, nn.max = Inf)
  expect_equal(a$goodrows, !is.na(a$novelty$sigma))
  expect_equal(unname(as.matrix(a$predictions.direct[o$goodrows[a$goodrows], ])),
               unname(as.matrix(o$predictions.direct)))
  s <- run_n(d, nx, nn.max = Inf)
  expect_equal(s$goodrows, !is.na(s$novelty$sigma) & s$novelty$sigma <= 4)
  n <- run_n(d, nx, sigma = Inf)
  expect_equal(n$goodrows, !is.na(n$novelty$nn) & n$novelty$nn <= 3)
  ## nn.max = "auto": the upper whisker of the samples' own nn values
  au <- run_n(d, nx, nn.max = "auto")
  thr <- attr(envNovelty(d$X, nx, o$median.importance), "nn.auto")
  expect_equal(unname(au$limits["nn.max"]), thr)
  expect_equal(au$goodrows, !is.na(au$novelty$sigma) & au$novelty$sigma <= 4 & au$novelty$nn <= thr)
  expect_error(run_n(d, nx, nn.max = "high"), "auto")
})

test_that("environments predicted beyond the sampled range are clamped to it", {
  d <- nov_sim()
  edge <- d$X[which.max(d$X$temp), ]
  beyond <- edge; beyond$temp <- beyond$temp + 0.3
  o <- run_n(d, rbind(edge, beyond, d$X[1, ]), seed = 2, sigma = Inf, nn.max = Inf)
  expect_equal(unlist(o$predictions.direct[1, ]), unlist(o$predictions.direct[2, ]), ignore_attr = TRUE)
  expect_equal(unlist(o$predictions.turnover[1, ]), unlist(o$predictions.turnover[2, ]), ignore_attr = TRUE)
})

test_that("extra / extra.npred select the range rule; the distance tests then default to off", {
  d <- nov_sim()
  nx <- rbind(d$X[1:10, ], data.frame(temp = c(8, 0), depth = c(0.5, 0.5), noise = c(0, 9)))
  r <- run_n(d, nx, extra = 0.2)
  rng <- apply(d$X, 2, range); pad <- 0.2 * (rng[2, ] - rng[1, ])
  inside <- apply(nx, 1, function(x) all(x >= rng[1, ] - pad & x <= rng[2, ] + pad))
  expect_equal(unname(r$goodrows), unname(inside))
  expect_equal(unname(r$limits), c(Inf, Inf, 0.2, 3))
  ## extra.npred alone: extra = 0 for the first predictors, the rest free
  r2 <- run_n(d, nx, extra.npred = 1)
  expect_equal(unname(r2$goodrows), unname(nx$temp >= rng[1, 1] & nx$temp <= rng[2, 1]))
  ## novelty is still reported
  expect_false(anyNA(r$novelty))
  ## naming a distance test as well applies it too
  r3 <- run_n(d, nx, extra = 10, sigma = 4)
  expect_equal(unname(r3$goodrows), unname(r3$novelty$sigma <= 4))
  ## per-environment values
  l <- run_n(d, list(a = nx, b = nx), extra = c(0.2, 10))
  expect_equal(l$a$goodrows, r$goodrows)
  expect_true(all(l$b$goodrows))
  expect_error(run_n(d, nx, extra = -1), "0 or more")
  expect_error(run_n(d, list(nx, nx), extra = c(0, 0, 0)), "one per environment")
})
