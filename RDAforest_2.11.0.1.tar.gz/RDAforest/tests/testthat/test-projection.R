## Projection of out-of-bag samples onto a replicate's ordination.

proj_sim <- function(n = 60, p = 12, seed = 1) {
  set.seed(seed)
  X <- matrix(stats::rnorm(n * p), n)
  X[, 1] <- X[, 1] * 3; X[, 2] <- X[, 2] * 2           # unequal axes, so stretching would show
  D <- as.matrix(dist(X)); dimnames(D) <- list(seq_len(n), seq_len(n))
  list(D = D, cov = data.frame(a = X[, 1] + stats::rnorm(n), b = stats::rnorm(n)), n = n)
}

test_that("in-bag samples land exactly on their own scores", {
  d <- proj_sim(); ib <- sample(d$n, 45)
  for (cv in list(NULL, d$cov)) {
    o <- RDAforest:::.rdaf_ord_rep(d$D, ib, cv)
    own <- vegan::scores(o$ords0, scaling = 1, display = "sites", choices = seq_len(ncol(o$ords)))
    expect_equal(as.vector(o$ords[ib, ]), as.vector(own), tolerance = 1e-8)
    expect_equal(nrow(o$ords), d$n)
  }
})

test_that("with Euclidean distances, all samples keep their true geometry", {
  d <- proj_sim(); ib <- sample(d$n, 45)
  P <- RDAforest:::.rdaf_ord_rep(d$D, ib)$ords
  dp <- as.matrix(dist(P)); k <- sum(dp * d$D) / sum(dp^2)
  expect_lt(max(abs(k * dp - d$D)) / max(d$D), 1e-8)
  ## predict(type = "sp") did not
  o0 <- vegan::capscale(d$D[ib, ib] ~ 1)
  Q <- suppressWarnings(predict(o0, d$D, type = "sp", scaling = "sites"))
  dq <- as.matrix(dist(Q)); kq <- sum(dq * d$D) / sum(dq^2)
  expect_gt(max(abs(kq * dq - d$D)) / max(d$D), 0.05)
})

test_that("covariates are removed from out-of-bag samples using their own values", {
  d <- proj_sim(seed = 2)
  ## the full-data partial ordination, and the same data projected from all samples
  full <- vegan::capscale(d$D ~ 1 + Condition(as.matrix(d$cov)))
  sf <- vegan::scores(full, scaling = 1, display = "sites", choices = 1:8)
  p <- projectOrdination(d$D, seq_len(d$n), d$cov)
  expect_equal(as.vector(p$scores[, 1:8]), as.vector(sf), tolerance = 1e-8)
  ## an out-of-bag sample at an in-bag sample's position (duplicate) with the same
  ## covariates lands on the same spot
  D2 <- rbind(cbind(d$D, d$D[, 1]), c(d$D[1, ], 0)); dimnames(D2) <- list(1:(d$n + 1), 1:(d$n + 1))
  q <- projectOrdination(D2, seq_len(d$n), rbind(d$cov, d$cov[1, ]))
  expect_equal(unname(q$scores[d$n + 1, ]), unname(q$scores[1, ]), tolerance = 1e-8)
  ## without its covariates it is projected unadjusted, with a message
  expect_message(r <- projectOrdination(D2, seq_len(d$n), d$cov), "without covariate adjustment")
  expect_false(isTRUE(all.equal(unname(r$scores[d$n + 1, ]), unname(r$scores[1, ]))))
  expect_error(projectOrdination(d$D, 1:2), "at least three")
  expect_error(projectOrdination(d$D, 1:10, d$cov[1:5, ]), "one row per")
})

test_that("pcoa_project: exact geometry, classical PCoA in-bag, capscale up to a constant", {
  d <- proj_sim(seed = 3); ib <- sample(d$n, 45)
  p <- pcoa_project(d$D, ib)
  expect_lt(max(abs(as.matrix(dist(p$scores)) - d$D)), 1e-9)
  pc <- stats::cmdscale(d$D[ib, ib], k = 5)
  expect_equal(abs(unname(p$scores[ib, 1:5])), abs(unname(pc)), tolerance = 1e-8)
  expect_equal(p$negative.eig, 0, tolerance = 1e-8)
  ## with covariates, all samples in-bag: capscale(D ~ Condition(Z)) up to one constant
  pz <- pcoa_project(d$D, seq_len(d$n), d$cov)
  cz <- vegan::scores(vegan::capscale(d$D ~ 1 + Condition(as.matrix(d$cov))), scaling = 1,
                      display = "sites", choices = 1:5)
  r <- abs(as.matrix(cz)) / abs(pz$scores[, 1:5])
  expect_lt(stats::sd(as.vector(r)) / mean(r), 1e-8)
  ## agrees with projectOrdination up to an orthogonal map times a constant
  q <- projectOrdination(d$D, ib, d$cov)$scores
  p2 <- pcoa_project(d$D, ib, d$cov)$scores[, seq_len(ncol(q))]
  dq <- as.matrix(dist(q)); dp <- as.matrix(dist(p2))
  expect_lt(stats::sd(dq[upper.tri(dq)] / dp[upper.tri(dp)]), 1e-8)
  ## non-Euclidean distances: negative eigenvalues reported
  b <- as.matrix(vegan::vegdist(matrix(stats::rpois(40 * 15, 3), 40)))
  expect_gt(pcoa_project(b, 1:30)$negative.eig, 0)
})
