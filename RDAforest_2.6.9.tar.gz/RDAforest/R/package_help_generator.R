#' Gradient forest analysis of large response matrices, based on ordination scores
#'
#' Adopts gradient forest approach to large multivariate response datasets, such as genotypes or gene expression, by analyzing the shape of the datasets as described by principal components. Has two novel procedures: selection of important variables based on `mtry` criterion (`mtrySelection`), and two versions of bootstrapping (`ordinationJackknife` and `spatialBootstrap`)
#'
#'
#'@author Mikhail Matz
#'
#'@name RDAforest
NULL
