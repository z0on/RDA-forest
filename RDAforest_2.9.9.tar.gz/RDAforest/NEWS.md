# RDAforest 2.9.9

Changes since 2.8.1.

## `ordinationJackknife()`: several environments in one run

`newX` may now be a named list of environments, for example
`newX = list(present = envc, future = envf)`, with `extra` and `extra.npred`
given once or once per environment (`extra = c(0.1, 0.2)`). Each replicate
fits its models, scores every environment, and lets the models go, so all
environments are scored through the same replicates while the ensemble is
never held in memory. The result is a list of ordinary results under the same
names (`res$present`, `res$future`); unnamed elements are called `newX1`,
`newX2`, ..., and a `NULL` element stands for `X`. With a single data frame,
or with `newX` omitted (which scores `X`), the result is exactly as before,
bit for bit.

This matters for genetic offsets. An offset is the difference between two
prediction sets, and if the two come from separate runs that difference also
carries the sampling noise of two independent sets of forests; on the wolves
that noise was 20-50% of the offset itself. Scoring both environments in one
run removes it at no extra cost: fitting dominates the running time, so two
environments take about as long as one.

## Keeping the models: `keep.models` and `ojPredict()`

`keep.models = TRUE` (default `FALSE`) also returns the fitted models of every
replicate in `$models` (once, next to the environments, when `newX` is a
list), and the new `ojPredict()` scores further environments with them,
without refitting:

```r
res <- ordinationJackknife(Y, X, newX = envc, extra = 0.1, keep.models = TRUE)
fut <- ojPredict(res, newX = envf, extra = 0.2, ncores = 4)
gen_offset_oj(res, fut, envc[, 1:2], envf[, 1:2])
```

`ojPredict()` returns exactly what `ordinationJackknife()` would have returned
had those environments been in its `newX`, with the same `ensemble.id`, so its
predictions can be set against the original run's in `gen_offset_oj()`. Like
`ordinationJackknife()`, it takes one environment, a named list of them, or
none (which scores `X`), with `extra` and `extra.npred` once or per
environment, and `ncores`: on the wolves, scoring the future grid through 25
replicates took 42 s on two cores instead of 74 s, with identical results.

Only what prediction reads is kept: each replicate's random forests without
their training-only parts (node sums of squares and improvements, out-of-bag
predictions, the response), and its gradient forest as the turnover curve of
every predictor. For the wolves at the defaults that is 1.2 GB, against about
2.7 GB for the full models; a message reports the size above a gigabyte.
Predictions are identical whether models are kept or not.

Every result carries `ensemble.id`, a token of the run it came from, and
`gen_offset_oj()` warns when its two arguments come from different runs.
Objects without a token pass unchecked.

## Parallel replicates: `ncores`

`mtrySelJack()` and `ordinationJackknife()` take `ncores` (default 1). The
replicates are independent, so with `ncores > 1` they run that many at a
time; on two cores a wolves `mtrySelJack()` run went from 52 s to 30 s, and the
gain grows with the number of cores up to `nreps`.

* Forking on Linux and macOS, socket clusters on Windows;
  `options(RDAforest.parallel = "psock")` forces sockets where forking
  misbehaves.
* Reproducibility: with `ncores = 1` nothing changes. With `ncores > 1` each
  replicate draws from its own L'Ecuyer-CMRG stream derived from the
  session's stream, so `set.seed()` still fixes the result, and the result is
  identical for any number of cores above one, and between forking and
  sockets; it differs from the `ncores = 1` result only by the luck of the
  draw. The session's own generator is left as it was.
* Memory: each worker needs its own memory for fitting, roughly 0.8 GB for the
  wolves at the defaults, so choose `ncores` by RAM as well as by processor
  count. A worker that runs out is killed by the operating system, and the
  function stops with "a worker was probably killed, most often for lack of
  memory. Try fewer cores." `ordinationJackknife()` dispatches `ncores`
  replicates at a time and sums their predictions as they return, so beyond
  the workers its memory stays flat.

## `mtrySelJack()`

**Few predictors.** The test compares importances at two `mtry` values. With
five or fewer predictors the default values coincided (3 and 3), so the test
compared a forest with itself and its outcome was a coin toss: in simulations
with four predictors, true drivers were kept only about half the time at
`prop.positive.cutoff = 0.5`. The defaults are now:

| predictors | mintry | maxtry |
|---|---|---|
| fewer than 3 | error | |
| 3 | 1 | 2 |
| 4 or 5 | 1 | 3 |
| 6 or more | unchanged | unchanged |

Explicit values are honoured but must satisfy 1 <= `mintry` < `maxtry` <=
number of predictors. The values used are returned in `$mtry`.

**Dropped predictors correlated with retained ones.** The test treats a
predictor that loses importance at higher `mtry` as a proxy of a correlated,
more important one. Two predictors that are both real drivers but correlated
compete the same way, and one of them can be dropped (in simulations: 10-20%
of the time at r = 0.8, 25-40% at r = 0.9). Every dropped predictor that
correlates with a retained one at |r| >= `report.cor` (default 0.7) is now
listed in a message and returned in `$dropped.pairs` (`dropped`, `kept`,
`r`, `importance`, `prop.positive`, `reason`). `report.cor = NULL` switches
this off. Selection itself is unchanged. The predictor correlations and the
threshold are returned too (`$cor.X`, `$report.cor`).

**`Reselect()`** now recomputes and reports `dropped.pairs` for the new
selection (it used to leave the old list, which could then name as dropped a
predictor that was now kept). It takes `report.cor` (by default the value used
in `mtrySelJack()`), and `X =` for objects made by earlier versions, which do
not store the correlations. It also applies the importance cutoff exactly as
`mtrySelJack()` does (`>=`; it was `>`) and returns `goodvars` in the same
order, so that with the original cutoffs it reproduces the original selection
exactly.

## Distance matrices only

`mtrySelJack()` and `ordinationJackknife()` now accept only a distance matrix
as `Y` (square and symmetric, or a `dist` object). Raw data matrices are
refused with an error suggesting `as.matrix(dist(Y))`, which gives the same
ordination as an RDA of `Y`. This also removes a failure: a raw matrix
together with `covariates` stopped with vegan's "no 'wa' scores available
(yet) in partial RDA". Results for distance input are unchanged.

# RDAforest 2.8.1

## `extra.npred` in `ordinationJackknife()`

`extra` says how far a predictor in `newX` may reach beyond the range the model
was fitted on before its row is dropped. It now applies only to the first
`extra.npred` predictors, counted in the order they were supplied in `X`; the
rest may extend without limit, so no row is ever dropped on their account.

```r
ordinationJackknife(Y, X, newX = rasters, extra = 0.1, extra.npred = 2)
```

With five predictors, that lets predictors 1 and 2 reach a tenth of their span
past the modelled range and no further, while predictors 3 to 5 are
unrestricted. Useful when some predictors should be extrapolated cautiously
(climate, say) while others legitimately cover ground the samples did not
(coordinates, depth).

The default is `extra.npred = ncol(X)` which, with `extra = 0`, is exactly the
old behaviour: no extension anywhere.

## Fixes

- Automatic site detection no longer overrides an explicitly named
  `site.repeats`. Detection supplies the *sites*; the mode is whatever the
  caller asked for, and only a caller who left `site.repeats` alone gets the
  `"genetic.median"` default. Affected `rdaf_randomForest()`,
  `rdaf_gradientForest()`, `makeGF()`, `makeGF_simple()`, `predict_rf()`,
  `mtrySelJack()` and `ordinationJackknife()`. When a mode is named, the
  message now says which one was used instead of naming the genetic median.

# RDAforest 2.8.0

## `site.repeats`: three ways to handle repeated samples within a site

The `oob.blocks` / `oob.block.holdout` pair introduced in 2.7.0 is replaced by
`sites` plus `site.repeats`. Pass the site membership of each sample as `sites`,
and choose what is done about the repeats:

| `site.repeats` | what it does | rows fitted |
|---|---|---|
| `"genetic.median"` (default) | collapses each site to one synthetic individual at the geometric median of its members | one per site |
| `"blocked.resampling"` | keeps every individual, withholds whole sites from each tree | all |
| `"direct.use"` | ignores the site structure: the ordinary random forest | all |

`sites = NULL` (the default) means no repeated sampling and leaves everything as
it was, so code that does not use the option is unaffected.

### `"genetic.median"`

Each site is replaced by a single **"false individual"**: not one of the real
samples, but the point with the smallest sum of Euclidean distances to all of
them, found by **Weiszfeld's iteration** in the space of *all* the principal
coordinates being analysed. The iteration starts at the centroid and repeatedly
replaces the estimate by the mean of the points weighted by the reciprocal of
their distances to it, until it stops moving; if it lands exactly on a data
point that point is returned.

This is not the medoid (which is a real sample, and so carries that individual's
own noise) and not the centroid (which minimises *squared* distances and is
pulled around by outliers). The forest is then fitted to one row per site, so
there is no repeated sampling left to exploit.

New exported helpers: `geometric_median()` for a single set of points,
`genetic_medians()` for the per-site collapse, and `detect_sites()` for the
automatic check described below.

### `"blocked.resampling"`

What `oob.blocks` did in 2.7.0. Each tree withholds a random `block.holdout`
fraction of whole sites (default `1/3`), then draws its training sample from the
rows of the sites that remain, in exactly the ordinary way: with replacement by
default, honouring `replace` and `sampsize` (the latter scaled to the size of
the pool). The out-of-bag set is the withheld sites and nothing else.

### `"direct.use"`

The ordinary random forest, bit for bit: what RDAforest did before 2.7.0.

## Automatic detection

`sites` no longer has to be supplied. Left `NULL`, RDAforest inspects the
predictors before fitting. Coordinate columns are recognised by name
(`lon`/`lat`, `x`/`y`, `easting`/`northing` and similar) or given with `coords`;
with no coordinates identified, a site is a set of rows whose predictor values
are identical throughout.

- **No shared locations** — the individuals are used directly, silently.
- **Shared location, same environment** — treated as repeated sampling and
  handled according to `site.repeats`. With `site.repeats` left at its default
  the message is *"Data appear to contain multiple samples per site. Such
  samples will be represented as their genetic median; see option site.repeats
  for alternatives."*; naming a mode overrides the default, and the message then
  says which mode was used. Detection supplies the sites, never the mode.
- **Shared location, different environment** — *"some samples share a spatial
  location but have different environmental entries, check"* is warned, and the
  individuals are used directly, leaving the decision to you.

Telling the second case from the third needs the coordinates to be
identifiable. With no recognisable column names and no `coords`, a site can only
be a set of identical rows, so a sample that shares a location but differs in
one environmental value counts as a site of its own and nothing is warned about.

`detect_sites()` runs the check on its own and returns what it found.
`auto.sites = FALSE` switches it off; passing `sites` overrides it. The check
runs once per top-level call, so a jackknife does not repeat the message on
every replicate.

## Why it matters

In a simulation of 40 sites with 10 individuals each, two of four site-level
predictors truly driving the genetics at R² = 0.6:

| `site.repeats` | false importance (noise/real) | cross-validation R² |
|---|---|---|
| `"direct.use"` | 0.57 | 0.76 |
| `"blocked.resampling"` | 0.03 | 0.35 |
| `"genetic.median"` | 0.03 | 0.41 |

Under `"direct.use"` a predictor that merely tags an unusual site looks like a
driver, and R² overstates a relationship whose truth is 0.6. The two honest
settings agree with each other and now *understate* it, because they are working
from 40 effective observations rather than 400.

## Where the option lives

`rdaf_randomForest()`, `rdaf_gradientForest()`, `makeGF()`, `makeGF_simple()`,
`predict_rf()`, `predict_gf()`, `mtrySelJack()` and `ordinationJackknife()`.

`site_repeats_summary()` reports what a given setting implies (how many sites,
how many rows will be fitted, and for blocked resampling how large the eligible
pool is per tree) before you commit to a long run. It replaces
`oob_blocks_summary()`.

`spatial_blocks()` no longer fails when a re-split lands on a block too small to
halve (`hclust` needs at least two objects), which could happen with a small
`min.size` and many blocks.

As before, the `oob` argument of `ordinationJackknife()` and `mtrySelJack()`,
which governs how many samples are withheld when the ordination is rebuilt in
each replicate, remains a plain random draw over rows. `site.repeats` governs
the random forest fitting only.

## Deprecations

`oob.blocks` and `oob.block.holdout` are still accepted by `rdaf_randomForest()`
and `rdaf_gradientForest()`, with a warning; they map to `sites` with
`site.repeats = "blocked.resampling"` and to `block.holdout`. They will be
removed in a future version. `oob_blocks_summary()` is gone; use
`site_repeats_summary()`.

# RDAforest 2.7.0

## Blocked out-of-bag sampling

Random forest fitting can now hold out **whole pre-specified blocks of samples**
rather than whichever individual rows the bootstrap happens to miss.

Pass a categorical vector, one entry per sample, as `oob.blocks`.
`oob.block.holdout` sets the fraction of blocks withheld from each tree
(default `1/3`, rounded to a whole number of blocks).

**Blocking changes only which samples are eligible; nothing else.** Each tree
first withholds a random fraction of the blocks, then draws its training sample
from the rows of the blocks that remain, in exactly the ordinary way: with
replacement by default, so about 1 − 1/e of the eligible rows are drawn, and
honouring `replace` and `sampsize` (the latter scaled to the size of the pool).
The out-of-bag set is the withheld blocks and nothing else — a retained row that
the draw happened to miss is not scored, because its block-mates are in the
training sample.

```r
# 12 geographic blocks of at least 4 samples each
blocks <- spatial_blocks(latlon, nblocks = 12, min.size = 4)
oob_blocks_summary(blocks)

oj <- ordinationJackknife(Y = cordist, X = env, newX = envc,
                          covariates = latlon.gcd, nreps = 25,
                          oob.blocks = blocks)
```

Why it matters: when samples come in groups (several individuals per site,
siblings, sequencing batches, repeated years), a row the bootstrap missed almost
always has a near-duplicate of itself in the training set. Out-of-bag R-squared
and variable importance are then optimistic, and predictors that merely tag the
group look important. Blocked sampling scores every tree on groups it has never
seen.

The option is available on `rdaf_randomForest()`, `rdaf_gradientForest()`,
`makeGF()`, `makeGF_simple()`, `predict_rf()`, `predict_gf()`, `mtrySelJack()`
and `ordinationJackknife()`. It defaults to `NULL`, which is the ordinary
bootstrap, so existing scripts are unaffected.

Note: the `oob` argument of `ordinationJackknife()` and `mtrySelJack()`, which
governs how many samples are withheld when the **ordination** is rebuilt in each
replicate, is still a plain random draw over rows. `oob.blocks` changes the
random forest fitting only.

### New functions

* `spatial_blocks()` builds a blocking vector by clustering samples on great
  circle distances (Ward's method), merging and re-splitting until every block
  holds at least `min.size` samples.
* `oob_blocks_summary()` reports what a blocking scheme implies: number of
  blocks, block sizes, blocks withheld per tree, and the resulting range of
  eligible-pool sizes.

## The package is now self-contained

`extendedForest` and `gradientForest` are no longer dependencies. The functions
RDAforest used from them are incorporated into the package, together with the
C and Fortran random forest engine, which is what made blocked sampling
possible.

Incorporated functions are renamed with an `rdaf_` prefix so that RDAforest can
be loaded alongside the original packages without masking anything:

| was | is now |
| --- | --- |
| `extendedForest::randomForest()` | `rdaf_randomForest()` |
| `extendedForest::getTree()` | `rdaf_getTree()` |
| `extendedForest::varUsed()`, `treesize()` | `rdaf_varUsed()`, `rdaf_treesize()` |
| `gradientForest::gradientForest()` | `rdaf_gradientForest()` |
| `gradientForest::cumimp()` | `rdaf_cumimp()` |
| `importance()` (both packages) | `rdaf_importance()` |

Fitted objects have class `rdaf_randomForest` / `rdaf_gradientForest`, and
`print()`, `plot()`, `predict()` and `density()` dispatch on them as before.

Everything else is unchanged. With the same random seed and no `oob.blocks`,
the incorporated code reproduces `extendedForest` and `gradientForest` exactly:
the package's test suite asserts `identical()` on the forest structure, MSE,
R-squared, out-of-bag predictions, in-bag matrix, importances, `cumimp()` curves
and `predict()` output.

The parts of `gradientForest` that RDAforest never used — the
`combinedGradientForest` family — were not carried over.

### Consequences for installation

RDAforest now contains compiled code, so installing from source needs a C
compiler: Rtools on Windows, the Xcode command line tools on macOS,
`r-base-dev` on Linux.

**No Fortran compiler is required.** The classification tree builder that
`extendedForest` inherits from Breiman and Cutler (`rfsub.f`: `buildtree`,
`findbestsplit`, `movedata` and their helpers) has been translated to C in
`src/rfsub.c`, and `gfortran` is no longer part of the build. The translation
is deliberately literal, keeping the original column-major layout, control flow
and — critically — the exact order in which random numbers are drawn, including
two tie-breaking quirks that look like bugs but shift every subsequent draw.
The test suite pins this down: with the same seed, classification forests are
`identical()` to the Fortran ones across fourteen configurations covering
multiple classes, `mtry`, `nodesize`, sampling with and without replacement,
class weights and cutoffs, stratified sampling, proximity, local importance,
conditional permutation, categorical predictors (both the exhaustive and the
sampled-split branches) and a deliberately tie-heavy dataset.

### If you call the old functions directly

Scripts that only use RDAforest's own functions need no changes. A script that
called `gradientForest()` or `randomForest()` directly should either add the
`rdaf_` prefix, or keep loading the original packages, which still works.

## Documentation

Every incorporated function now has its own help page, and the new blocked
sampling option is documented on each function that accepts it.
`?RDAforest` gives an overview.
