## ordinationJackknife(): one environment, several, or none.

oj_sim <- function(n = 60, seed = 1) {
  set.seed(seed)
  X <- data.frame(temp = stats::rnorm(n), depth = stats::runif(n), noise = stats::rnorm(n))
  Y <- data.frame(a = 2 * X$temp + stats::rnorm(n, 0, 0.5), b = X$depth + stats::rnorm(n, 0, 0.5),
                  c = stats::rnorm(n))
  warm <- X; warm$temp <- warm$temp + 0.3
  list(X = X, D = as.matrix(dist(Y)), warm = warm, n = n)
}
q <- function(e) suppressMessages(e)
K <- c("sum.importances", "predictions.direct", "predictions.turnover", "median.importance",
       "all.importances", "goodrows", "failed.reps")
run <- function(d, seed, ...) { set.seed(seed)
  q(ordinationJackknife(d$D, d$X, nreps = 3, top.pcs = 2, ntrees = 60, auto.sites = FALSE, ...)) }

test_that("without newX, the predictors in X are scored", {
  d <- oj_sim()
  a <- run(d, 1)
  expect_equal(nrow(a$predictions.direct), d$n)
  expect_equal(nrow(a$predictions.turnover), d$n)
  expect_identical(a$goodrows, seq_len(d$n))
  expect_named(a, c(K[1:6], "failed.reps", "ensemble.id"), ignore.order = TRUE)
  ## and it is exactly what newX = X gives
  b <- run(d, 1, newX = d$X)
  expect_identical(a$predictions.direct, b$predictions.direct)
  expect_identical(a$predictions.turnover, b$predictions.turnover)
})

test_that("a list of environments gives what separate runs with the same seed give", {
  d <- oj_sim()
  m <- run(d, 2, newX = list(now = d$X, warm = d$warm), extra = c(0, 0.5), extra.npred = c(3, 1))
  s1 <- run(d, 2, newX = d$X, extra = 0)
  s2 <- run(d, 2, newX = d$warm, extra = 0.5, extra.npred = 1)
  expect_named(m, c("now", "warm"))
  for (k in K) {
    expect_identical(m$now[[k]], s1[[k]], info = k)
    expect_identical(m$warm[[k]], s2[[k]], info = k)
  }
  ## one run, one token; separate runs, different tokens
  expect_identical(m$now$ensemble.id, m$warm$ensemble.id)
  expect_false(identical(s1$ensemble.id, s2$ensemble.id))
})

test_that("list elements may be unnamed or NULL (NULL stands for X)", {
  d <- oj_sim()
  m <- run(d, 3, newX = list(NULL, d$warm), extra = 0.5)
  expect_named(m, c("newX1", "newX2"))
  expect_identical(m$newX1$predictions.direct, run(d, 3)$predictions.direct)
})

test_that("gen_offset_oj: silent within one run, warns across runs", {
  d <- oj_sim(n = 40)
  xy <- data.frame(x = seq_len(40), y = seq_len(40))
  m <- run(d, 4, newX = list(now = d$X, warm = d$warm), extra = 1)
  expect_no_warning(gen_offset_oj(m$now, m$warm, xy, xy))
  other <- run(d, 5, newX = d$warm, extra = 1)
  expect_warning(gen_offset_oj(m$now, other, xy, xy), "different ordinationJackknife\\(\\) runs")
  o <- suppressWarnings(gen_offset_oj(m$now, other, xy, xy))
  expect_true("offset" %in% names(o))
  a <- m$now; a$ensemble.id <- NULL; b <- other; b$ensemble.id <- NULL
  expect_no_warning(gen_offset_oj(a, b, xy, xy))
  ## and a token does not disturb the random number stream
  set.seed(61); x1 <- runif(3); id <- RDAforest:::.rdaf_fit_id(); x2 <- runif(3)
  set.seed(61); expect_equal(c(x1, x2), runif(6))
})

test_that("site handling runs in every mode", {
  set.seed(47)
  sites <- factor(rep(paste0("s", 1:12), each = 5))
  idx <- as.integer(sites); n <- length(idx)
  E <- scale(matrix(stats::rnorm(36), 12, 3)); colnames(E) <- c("driver", "n1", "n2")
  X <- as.data.frame(E[idx, , drop = FALSE])
  D <- as.matrix(dist(data.frame(a = E[idx, 1] + stats::rnorm(n, 0, 0.5),
                                 b = E[idx, 2] + stats::rnorm(n, 0, 0.5), c = stats::rnorm(n))))
  for (m in c("genetic.median", "blocked.resampling", "direct.use")) {
    set.seed(48)
    a <- q(ordinationJackknife(D, X, nreps = 2, top.pcs = 2, ntrees = 60, sites = sites,
                               site.repeats = m, newX = list(X, X)))
    expect_equal(nrow(a$newX1$predictions.direct), n, info = m)
    expect_identical(a$newX1$predictions.direct, a$newX2$predictions.direct, info = m)
  }
  ## auto-detection decides once and says so once
  set.seed(50)
  msgs <- capture_messages(ordinationJackknife(D, X, nreps = 2, top.pcs = 2, ntrees = 60,
                                               newX = list(X, X)))
  expect_equal(sum(grepl("multiple samples per site", msgs)), 1L)
  set.seed(51)
  msgs2 <- capture_messages(ordinationJackknife(D, X, nreps = 2, top.pcs = 2, ntrees = 60,
                                                site.repeats = "blocked.resampling"))
  expect_equal(sum(grepl("blocked.resampling", msgs2)), 1L)
})

test_that("bad input is refused before fitting", {
  d <- oj_sim()
  expect_error(ordinationJackknife(d$D, d$X, newX = list()), "empty")
  expect_error(ordinationJackknife(d$D, d$X, newX = list(a = d$X, a = d$warm)), "distinct names")
  expect_error(ordinationJackknife(d$D, d$X, newX = list(a = d$X, b = 1:3)), "data frame")
  expect_error(ordinationJackknife(d$D, d$X, newX = 1:3), "data frame")
  expect_error(ordinationJackknife(d$D, d$X, newX = list(d$X, d$warm), extra = c(0, 0.1, 0.2)),
               "one per environment")
  expect_error(ordinationJackknife(d$D, d$X, extra.npred = 99), "between 0 and")
  expect_error(ordinationJackknife(d$D, d$X, ncores = 0), "1 or more")
  expect_error(q(ordinationJackknife(d$D[1:10, 1:10], d$X, nreps = 2, auto.sites = FALSE)),
               "incompatible input matrices")
  expect_false(exists("ojFit", envir = asNamespace("RDAforest")))
})

test_that("turnover curves predict exactly as the gradient forest does", {
  d <- oj_sim()
  set.seed(70)
  Y <- data.frame(a = d$X$temp + stats::rnorm(d$n), b = d$X$depth + stats::rnorm(d$n))
  g <- q(makeGF_simple(Y, d$X, ntrees = 100, auto.sites = FALSE))
  cis <- RDAforest:::.rdaf_oj_curves(g, names(d$X))
  nx <- rbind(d$X, d$X[1:5, ] + 3, d$X[6:10, ] - 3)
  expect_identical(RDAforest:::.rdaf_oj_turnover(cis, nx), predict(g, nx))
})

test_that("keep.models returns compact models; predictions unchanged", {
  d <- oj_sim()
  a <- run(d, 8, newX = d$warm, extra = 0.5)
  b <- run(d, 8, newX = d$warm, extra = 0.5, keep.models = TRUE)
  expect_null(a$models)
  for (k in K) expect_identical(a[[k]], b[[k]], info = k)
  m <- b$models
  expect_s3_class(m, "rdaf_oj_models")
  expect_length(m$reps, 3L)
  expect_identical(m$ensemble.id, b$ensemble.id)
  r1 <- m$reps[[1]]
  expect_named(r1, c("replicate", "rf", "curves"))
  expect_length(r1$rf, 2L)                                   # one forest per PC
  expect_s3_class(r1$rf[[1]], "rdaf_randomForest")
  ## only what prediction reads
  expect_null(r1$rf[[1]]$forest$nodeSS)
  expect_null(r1$rf[[1]]$predicted)
  expect_null(r1$rf[[1]]$y)
  expect_named(r1$curves, names(d$X))
  expect_named(r1$curves$temp, c("x", "y"))
  expect_output(print(m), "3 replicates")
  ## with a list, once, next to the environments
  l <- run(d, 8, newX = list(now = d$X, warm = d$warm), extra = 0.5, keep.models = TRUE)
  expect_named(l, c("now", "warm", "models"))
  expect_identical(l$warm$predictions.direct, a$predictions.direct)
  expect_error(ordinationJackknife(d$D, d$X, newX = list(models = d$X), keep.models = TRUE), "may not be called 'models'")
  expect_error(ordinationJackknife(d$D, d$X, keep.models = NA), "TRUE or FALSE")
})

test_that("ojPredict scores new environments exactly as the run would have", {
  d <- oj_sim()
  b <- run(d, 10, newX = d$X, keep.models = TRUE)
  ## the run's own environment, again
  again <- q(ojPredict(b, d$X))
  for (k in K) expect_identical(again[[k]], b[[k]], info = k)
  expect_identical(again$ensemble.id, b$ensemble.id)
  ## a new one: what a run with it in newX (same seed) gives
  w <- q(ojPredict(b$models, d$warm, extra = 0.5, extra.npred = 1))
  ref <- run(d, 10, newX = d$warm, extra = 0.5, extra.npred = 1)
  for (k in K) expect_identical(w[[k]], ref[[k]], info = k)
  ## no newX: the predictors in X
  expect_identical(q(ojPredict(b))$predictions.direct, run(d, 10)$predictions.direct)
  ## a list, with per-environment extra
  l <- q(ojPredict(b, list(now = d$X, warm = d$warm), extra = c(0, 0.5), extra.npred = c(3, 1)))
  expect_named(l, c("now", "warm"))
  expect_identical(l$warm$predictions.direct, w$predictions.direct)
  ## comparable with the original run in gen_offset_oj
  xy <- data.frame(x = seq_len(d$n), y = seq_len(d$n))
  expect_no_warning(gen_offset_oj(b, w, xy, xy))
  ## refused
  expect_error(ojPredict(list(a = 1)), "keep.models = TRUE")
  expect_error(ojPredict(run(d, 10)), "keep.models = TRUE")
  expect_error(ojPredict(b, d$X, extra.npred = 99), "between 0 and")
})

test_that("ojPredict in parallel equals serial and leaves the RNG alone", {
  skip_on_os("windows")
  d <- oj_sim()
  b <- run(d, 11, keep.models = TRUE)
  s1 <- q(ojPredict(b, list(d$X, d$warm), extra = 0.5))
  set.seed(1); r0 <- runif(1); set.seed(1)
  p2 <- q(ojPredict(b, list(d$X, d$warm), extra = 0.5, ncores = 2))
  expect_identical(runif(1), r0)
  expect_identical(p2, s1)
  old <- options(RDAforest.parallel = "psock"); on.exit(options(old))
  expect_identical(q(ojPredict(b, list(d$X, d$warm), extra = 0.5, ncores = 2)), s1)
})

test_that("keep.models in parallel brings the same models back", {
  skip_on_os("windows")
  d <- oj_sim()
  a <- run(d, 9, keep.models = TRUE, ncores = 2)
  b <- run(d, 9, keep.models = TRUE, ncores = 3)
  expect_length(a$models$reps, 3L)
  expect_identical(a$models$reps[[3]]$rf[[2]]$forest$xbestsplit, b$models$reps[[3]]$rf[[2]]$forest$xbestsplit)
  expect_identical(q(ojPredict(a, d$warm))$predictions.direct, q(ojPredict(b, d$warm))$predictions.direct)
})
