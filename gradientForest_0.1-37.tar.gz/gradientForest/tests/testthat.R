library(testthat)
library(gradientForest)

test_check("gradientForest")
