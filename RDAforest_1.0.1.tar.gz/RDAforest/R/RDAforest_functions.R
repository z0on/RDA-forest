#' Dummify predictors
#'
#' Turns a dataframe containing numerical and categorical predictors into fully numerical
#'
#' @param X matrix of predictor variables
#' @param lastlevel whether to include all levels of a factor, or omit the last one (for lm designs)
#' @return a dataframe with 0,1 values and column names `factor1_level1`,`factor1_level2` etc (for one original column `factor1` with multiple levels). Originally numerical predictors are left unchanged.
#' @export
dummify=function(X,lastlevel=TRUE){
  Xd=list()
  for (ci in 1:ncol(X)) {
    if(is.factor(X[,ci]) | is.integer(X[,ci]) | is.character(X[,ci])) {
      co=as.factor(X[,ci])
      dum=data.frame(model.matrix(~0+co))
      if(lastlevel==FALSE) { dum=dum[,-ncol(dum)] }
      colnames(dum)=paste(colnames(X)[ci],colnames(dum),sep="_")
      colnames(dum)=sub("_co","_",colnames(dum))
      colnames(dum)=sub("^co","",colnames(dum))
      colnames(dum)=sub("_model.+","",colnames(dum))
      Xd[[ci]]=dum

    }  else {
      Xd[[ci]]=data.frame(X[,ci])
      names(Xd[[ci]])=colnames(X)[ci]
    }
  }
  Xdd=data.frame(do.call(cbind,Xd))
  return(Xdd)
}

#' Sum up importances
#' Sums up importances of original factors that were dummified using `dummify()`
#' @param gf gradient forest result object
#' @param metadata original (non-dummified) metadata
#' @param importance.cutoff do not sum up importances below that level
#' @return a dataframe of importances of original factors in `metadata`.
#' @export
sum_up_importances=function(gf,metadata,importance.cutoff=0){
  ii=data.frame(importance(gf))
  names(ii)="importance"
  ii$var=row.names(ii)
  is=c();ii0=ii[ii$importance>=importance.cutoff,]
  for (f in colnames(metadata)) {
    i2=ii0[grep(paste("^",f,"_",sep=""),ii0$var),]
    if (nrow(i2)==0) {i2=ii0[grep(paste("^",f,sep=""),ii0$var),] }
    is=append(is,sum(i2$importance))
  }
  ii2=data.frame(cbind(importance=is,var=colnames(metadata)))
  ii2$importance=as.numeric(ii2$importance)
  ii2$var=factor(ii2$var,levels=ii2$var[order(ii2$importance)])
  return(ii2)
}


#' Run Gradient Forest (ordination version)
#'
#' This function runs gradient forest analysis on a vegan ordination object. It returns a gradientForest object.
#'
#' @import vegan
#' @import gradientForest
#' @import dplyr
#' @import stats
#' @import utils
#' @param ordination ordination object made by \code{vegan::capscale()} or \code{vegan::rda()}
#' @param X matrix of predictor variables
#' @param ntrees number of random forest trees to create during run
#' @param keep principal axes of the ordination to analyze. Default is NULL, which means keeping them all.
#' @param ... additional parameters for the gradientForest() function
#' @export
makeGF=function(ordination,X,ntrees=500,keep=NULL,...) {
  # keep: which PCs to keep in analysis, for example, c(1:25)
  Y=data.frame(scores(ordination,scaling=1,choices=c(1:length(ordination$CA$eig)))$sites)
  # removing constrained axes
  if(length(grep("CAP",colnames(Y)))>0) {Y=Y[,-grep("CAP",colnames(Y))] }
  if(!(is.null(keep))) { Y=Y[,keep] }
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  nSites = dim(Y)[1]
  nSpecs = dim(Y)[2]
  lev = floor(log2(nSites * 0.368/2))
  gf = gradientForest(cbind(X, Y),
                      predictor.vars = colnames(X), response.vars = colnames(Y),
                      ntree = ntrees, transform = NULL, trace=T,
                      maxLevel = lev, corr.threshold = 0.25,...)
  return(gf)
}

#' Run Gradient Forest (simple)
#'
#' This function is a simple wrapper for \code{gradientForest()} function, uses straight-up response matrix \code{Y}.
#'
#' @param Y matrix of response variables
#' @param X matrix of predictor variables
#' @param ntrees number of random forest trees to create during run
#' @param ... additional parameters for the \code{gradientForest()} function
#' @export
makeGF_simple=function(Y,X,ntrees=500,...) {
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  nSites = dim(Y)[1]
  nSpecs = dim(Y)[2]
  lev = floor(log2(nSites * 0.368/2))
  gf = gradientForest(cbind(X, Y),
                      predictor.vars = colnames(X), response.vars = colnames(Y),
                      ntree = ntrees, transform = NULL, trace=T,
                      maxLevel = lev, corr.threshold = 0.25,...)
  return(gf)
}

#' Variable selection
#'
#' Performs variable selection based on \code{mtry} criterion: variables that are not important by themselves but are correlated with actually important ones diminish in raw importance at higher \code{mtry} setting (Strobl et al 2018). The function runs spatial bootstrap on an ordination and selects variables that do not show decrease in importance at higher \code{mtry} in \code{prop.positive.cutoff} or more replicates.
#'
#' @param Y matrix of response variables or a distance matrix
#' @param X matrix of predictor variables
#' @param covariates data frame of covariates to be regressed out during ordination
#' @param nreps number of spatial bootstrap replicates
#' @param prop.positive.cutoff proportion of replicates that must show non-negative importance change at higher \code{mtry} to keep the variable. Default 0.5.
#' @param top.pcs number of top principal components to consider
#' @return A list of three items: \code{goodvars} - variables selected, \code{median.importance} - median importance of each variable, \code{all.importances} - importances inferred across all variables and replicates.
#' @export
mtrySelection=function(Y,X,covariates=NULL,nreps=15,prop.positive.cutoff=0.5,top.pcs=15) {
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  imps=c();delta=list()
  for(i in 1:nreps){
    message("\n\nreplicate ",i)
    rands=rnorm(nrow(Y))
    if(!is.null(covariates)) {
      if(dim(Y)[1]==dim(Y)[2]) {
        ords=capscale(Y~rands+Condition(as.matrix(covariates)))
      } else {
        ords=rda(Y~rands+Condition(as.matrix(covariates)))
      }
    } else {
      if(dim(Y)[1]==dim(Y)[2]) {
        ords=capscale(Y~rands)
      } else {
        ords=rda(Y~rands)
      }
    }
    message("mtry ",round(ncol(X)/4),"...")
    gf00=makeGF(ords,X,ntrees=1500,mtry=round(ncol(X)/4),keep=c(1:top.pcs))
    message("\nmtry ",round(0.375*ncol(X)),"...")
    gf1=makeGF(ords,X,ntrees=1500,mtry=round(0.375*ncol(X)),keep=c(1:top.pcs))
    ii1=importance(gf1,type="Raw")
    ii0=importance(gf00,type="Raw")[names(ii1)]
    if (i==1) {
      v.order=names(ii1)
    }
    delta[[i]]=ii1[v.order]-ii0[v.order]
  }
  # differences in raw importances
  delta=data.frame(do.call(cbind,delta))
  sdd=stack(delta)
  sdd$var=v.order
  sdd$var=factor(sdd$var,levels=rev(v.order))

  # proportion of positive importance changes
  dc=data.frame(apply(delta,1,function(x){return(sum(x>=0)/length(x))}))
  dc$var=v.order
  dc$var=factor(dc$var,levels=rev(v.order))
  names(dc)[1]="prop.positive"

  goodvars=row.names(dc)[dc$prop.positive>=prop.positive.cutoff]
  return(list(goodvars=goodvars,delta=sdd,prop.positive=dc))
}


#' Variable selection (jackknife version)
#'
#' Performs variable selection based on \code{mtry} criterion: variables that are not important by themselves but are correlated with actually important ones diminish in raw importance at higher \code{mtry} setting (Strobl et al 2018). The function runs ordination jackknife and selects variables that do not show decrease in importance at higher \code{mtry} in \code{prop.positive.cutoff} or more replicates.
#'
#' @param Y matrix of response variables or a distance matrix
#' @param X matrix of predictor variables
#' @param oob out-of-bag fraction: the fraction of datapoints to withhold from ordination construction in each replicate
#' @param covariates data frame of covariates to be regressed out during ordination
#' @param nreps number of spatial bootstrap replicates
#' @param prop.positive.cutoff proportion of replicates that must show non-negative importance change at higher \code{mtry} to keep the variable. Default 0.5.
#' @param top.pcs number of top principal components to consider
#' @return A list of three items: \code{goodvars} - variables selected, \code{median.importance} - median importance of each variable, \code{all.importances} - importances inferred across all variables and replicates.
#' @export
mtrySelJack=function(Y,X,covariates=NULL,nreps=15,oob=0.15,prop.positive.cutoff=0.5,top.pcs=15) {
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  imps=c();replicate=c();delta=list()
  for(i in 1:nreps){
    message("\nreplicate ",i)
    ib.keep=sample(1:ncol(Y),round(ncol(Y)*(1-oob)))
    if(!is.null(covariates)) {
      covars.ib=covariates[ib.keep,]
      if(dim(Y)[1]==dim(Y)[2]) {
        Y.ib=Y[ib.keep,ib.keep]
        ords0=capscale(Y.ib~Condition(as.matrix(covars.ib)))
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      } else {
        Y.ib=Y[,ib.keep]
        ords0=rda(Y.ib~Condition(as.matrix(covars.ib)))
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      }
    } else {
      if(dim(Y)[1]==dim(Y)[2]) {
        Y.ib=Y[ib.keep,ib.keep]
        ords0=capscale(Y.ib~1)
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      } else {
        Y.ib=Y[,ib.keep]
        ords0=rda(Y.ib~1)
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      }
    }
    message("mtry ",round(ncol(X)/4),"...")
    gf00=makeGF_simple(ords[,c(1:top.pcs)],X,ntrees=1500,mtry=round(ncol(X)/4))
    message("\nmtry ",round(0.375*ncol(X)),"...")
    gf1=makeGF_simple(ords[,c(1:top.pcs)],X,ntrees=1500,mtry=round(0.375*ncol(X)))
    ii1=importance(gf1,type="Raw")
    ii0=importance(gf00,type="Raw")[names(ii1)]
    if (i==1) {
      v.order=names(ii1)
    }
    delta[[i]]=ii1[v.order]-ii0[v.order]
  }
  # differences in raw importances
  delta=data.frame(do.call(cbind,delta))
  sdd=stack(delta)
  sdd$var=v.order
  sdd$var=factor(sdd$var,levels=rev(v.order))

  # proportion of positive importance changes
  dc=data.frame(apply(delta,1,function(x){return(sum(x>=0)/length(x))}))
  dc$var=v.order
  dc$var=factor(dc$var,levels=rev(v.order))
  names(dc)[1]="prop.positive"

  goodvars=row.names(dc)[dc$prop.positive>=prop.positive.cutoff]
  return(list(goodvars=goodvars,delta=sdd,prop.positive=dc))
}

#' Ordination Jackknife
#'
#' Runs gradient forest on \code{nreps} replicates, each time re-building the ordination based on a fraction of the data, projecting the rest of datapoints.
#'
#' @param Y matrix of response variables or a distance matrix
#' @param X matrix of predictor variables
#' @param oob out-of-bag fraction: the fraction of datapoints to withhold from ordination construction in each replicate
#' @param newX new matrix of predictor variable where associated differences in Y must be predicted. If omitted, predictions will be made on the same data as the model.
#' @param covariates data frame of covariates to be regressed out during ordination
#' @param nreps number of spatial bootstrap replicates
#' @param top.pcs number of top principal components to consider
#' @param mtry \code{mtry} setting. If left unspecified, defaults to \code{N/3} (where \code{N} is the number of predictors in X)
#' @return A list of three items: \code{turnovers} - predicted turnover curves for \code{newX}, \code{median.importance} - median importance of each variable, \code{all.importances} - all observed importances across all replicates. Table with three columns: \code{importance}, \code{variable}, \code{rep}.
#' @export
ordinationJackknife=function(Y,X,oob=0.15,newX=NULL, covariates=NULL,nreps=15,top.pcs=15,mtry=NULL) {
 #   Y=IBS;oob=0.3;X=env[,mm$goodvars];newX=NULL;nreps=3;covariates=covars;top.pcs=5;mtry=NULL
  if(dim(Y)[1]!=dim(X)[1]) { stop("incompatible input matrices: number of rows in X should be equal that in Y")}
  if (is.null(newX)) {
    newX=X
  } else {
    newX=newX[,colnames(newX) %in% colnames(X)]
    # making sure there are no values in newX that are outside the range in X
    ranges=apply(X,2,range)
    for (v in colnames(newX)){
      newX[,v][newX[,v]<ranges[1,v]]=ranges[1,v]
      newX[,v][newX[,v]>ranges[2,v]]=ranges[2,v]
    }
  }
  imps=c();replicate=c()
  for(i in 1:nreps){
    message("\nreplicate ",i)
    ib.keep=sample(1:ncol(Y),round(ncol(Y)*(1-oob)))
    if(!is.null(covariates)) {
      covars.ib=covariates[ib.keep,]
      if(dim(Y)[1]==dim(Y)[2]) {
        Y.ib=Y[ib.keep,ib.keep]
        ords0=capscale(Y.ib~Condition(as.matrix(covars.ib)))
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      } else {
        Y.ib=Y[,ib.keep]
        ords0=rda(Y.ib~Condition(as.matrix(covars.ib)))
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      }
    } else {
      if(dim(Y)[1]==dim(Y)[2]) {
        Y.ib=Y[ib.keep,ib.keep]
        ords0=capscale(Y.ib~1)
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      } else {
        Y.ib=Y[,ib.keep]
        ords0=rda(Y.ib~1)
        suppressWarnings({ords=predict(ords0,Y,type='sp',scaling="sites")})
      }
    }
    gf1=makeGF_simple(ords[,c(1:top.pcs)],X,ntrees=1500,mtry=mtry)
    if (i==1) {
      turnovers=predict(gf1,newX)
      v.order=names(importance(gf1))
    } else {
      turnovers=turnovers+predict(gf1,newX)
    }
    imps=c(imps,importance(gf1)[v.order])
    replicate=c(replicate,rep(i,length(importance(gf1))))
  }
  turnovers=turnovers/nreps
  # computing median importances of variables
  dimps=data.frame(imps)
  dimps$replicate=replicate
  dimps$variable=names(imps)
  names(dimps)[1]="importance"
  meds=dimps%>%
    group_by(variable)%>%
    summarise(median(importance))
  meds=as.data.frame(meds)
  importances=meds$`median(importance)`
  names(importances)=meds$variable
  # releveling variables according to median importance
  varorder=meds$variable[order(meds[,2],decreasing=T)]
  turnovers=turnovers[,varorder[varorder %in% colnames(turnovers)]]
  importances=importances[varorder]
  dimps$variable=factor(dimps$variable,levels=rev(varorder))
  return(list(turnovers=turnovers,median.importance=importances,all.importances=dimps))
}


#' Spatial Bootstrap
#'
#' Runs gradient forest on \code{nreps} replicates, each time rotating the cloud of datapoints in a random direction and reforming principal axes to be orthogonal to that direction.
#'
#' @param Y matrix of response variables or a distance matrix
#' @param X matrix of predictor variables
#' @param newX new matrix of predictor variable where associated differences in Y must be predicted. If omitted, predictions will be made on the same data as the model.
#' @param covariates data frame of covariates to be regressed out during ordination
#' @param nreps number of spatial bootstrap replicates
#' @param top.pcs number of top principal components to consider
#' @param mtry \code{mtry} setting. If left unspecified, defaults to \code{N/3} (where \code{N} is the number of predictors in X)
#' @return A list of three items: \code{turnovers} - predicted turnover curves for \code{newX}, \code{median.importance} - median importance of each variable, \code{all.importances} - all observed importances across all replicates. Table with three columns: \code{importance}, \code{variable}, \code{rep}.
#' @export
spatialBootstrap=function(Y,X,newX=NULL, covariates=NULL,nreps=25,top.pcs=25,mtry=NULL) {
  #  Y=IBS;X=env[,goodvars];newX=rasters;nreps=3;cov
  if (is.null(newX)) {
    newX=X
  } else {
    newX=newX[,colnames(newX) %in% colnames(X)]
    # making sure there are no values in newX that are outside the range in X
    ranges=apply(X,2,range)
    for (v in colnames(newX)){
      newX[,v][newX[,v]<ranges[1,v]]=ranges[1,v]
      newX[,v][newX[,v]>ranges[2,v]]=ranges[2,v]
    }
  }
  imps=c();replicate=c()
  for(i in 1:nreps){
    message("\nreplicate ",i)
    rands=rnorm(nrow(Y))
    if(!is.null(covariates)) {
      if(dim(Y)[1]==dim(Y)[2]) {
        ords=capscale(Y~rands+Condition(as.matrix(covariates)))
      } else {
        ords=rda(Y~rands+Condition(as.matrix(covariates)))
      }
    } else {
      if(dim(Y)[1]==dim(Y)[2]) {
        ords=capscale(Y~rands)
      } else {
        ords=rda(Y~rands)
      }
    }
    gf1=makeGF(ords,X,ntrees=1500,mtry=mtry,keep=c(1:top.pcs))
    if (i==1) {
      turnovers=predict(gf1,newX)
      v.order=names(importance(gf1))
    } else {
      turnovers=turnovers+predict(gf1,newX)
    }
    imps=c(imps,importance(gf1)[v.order])
    replicate=c(replicate,rep(i,length(importance(gf1))))
  }
  turnovers=turnovers/nreps
  # computing median importances of variables
  dimps=data.frame(imps)
  dimps$variable=names(imps)
  names(dimps)[1]="importance"
  meds=dimps%>%
    group_by(variable)%>%
    summarise(median(importance))
  meds=as.data.frame(meds)
  importances=meds$`median(importance)`
  names(importances)=meds$variable
  # releveling variables according to median importance
  varorder=meds$variable[order(meds[,2],decreasing=T)]
  turnovers=turnovers[,varorder[varorder %in% colnames(turnovers)]]
  importances=importances[varorder]
  dimps$variable=factor(dimps$variable,levels=rev(varorder))
  return(list(turnovers=turnovers,median.importance=importances,all.importances=dimps))
}

